# CubeSandbox Startup Profiler

本结果分支收录 [arm64-950 三轮 c100n100 脱敏测试数据与报告](arm64-950/README.md)。工具代码保持基于 `912b1ba`；实测原始日志与配置未纳入仓库，发布范围与限制见目录说明。

分析 **CubeSandbox v0.7.1 Template 启动时延**的独立工具。关联 Cubelet、CubeMaster、Shim 日志与 Prometheus 快照，输出阶段分布、覆盖率、逐实例明细和离线时间轴。保留同步、并行、嵌套与异步的计时语义，不把缺失阶段补成零，也不把所有阶段简单相加。

工具主线提供工具、源码口径文档与合成样例；本结果分支额外收录经用户授权发布的脱敏实测数据，不携带内网部署信息或配置凭据。

## 100 并发采集：运行一个命令

在能读取 CubeSandbox 日志的 **Linux 节点**上，准备 Python 3.9+、Node.js 18+ 和已编译的 `cube-bench`。首次复制配置，只需填写一次：

```sh
git clone https://gitcode.com/yuncongyue/cubesandbox-startup-profiler.git
cd cubesandbox-startup-profiler
cp examples/capture100.config.json capture100.local.json
chmod 600 capture100.local.json
```

编辑仓库根目录的 `capture100.local.json`，将占位值替换为你的实际配置：

```json
{
  "benchmark_binary": "/path/to/cube-bench",
  "api_url": "https://sandbox.example.com",
  "template_id": "YOUR_TEMPLATE_ID",
  "api_key": "YOUR_API_KEY",
  "warmup": 3,
  "log_root": "/data/log",
  "metrics_url": "http://127.0.0.1:9998/v1/metrics",
  "cubemastercli": {
    "binary": "/path/to/cubemastercli",
    "address": "127.0.0.1",
    "port": 8089,
    "exclusive_template": false
  }
}
```

| 字段 | 如何填写 |
| --- | --- |
| `benchmark_binary` | 已编译的 `cube-bench` 可执行文件路径，建议使用绝对路径；需有执行权限。无需 Go 或源码。 |
| `api_url` | 创建沙箱所使用的 CubeAPI 基础地址，例如 `https://sandbox.example.com`；不是 metrics 地址。 |
| `template_id` | 已创建且可用的模板 ID。若需 2 vCPU、2 GiB 内存、1 GiB 可写层，请预先构建对应模板。 |
| `api_key` | 与该 API 对应的访问密钥，可直接填入本地配置。也可留空并设置 `E2B_API_KEY`；环境变量优先。 |
| `warmup` | 独立预热的创建次数，非负整数，默认 `3`；设为 `0` 禁用。旧配置未填写时也默认 `3`。正式 cube-bench 固定使用 `-w 0`。 |
| `log_root` | 运行采集脚本的 Linux 节点上，CubeSandbox 日志根目录，常见为 `/data/log`；需有读取权限。 |
| `metrics_url` | 可留空 `""` 禁用。Cubelet 默认一般为 `http://127.0.0.1:9998/v1/metrics`；`127.0.0.1` 指运行采集脚本的本机，非远端 API 主机。若 Cubelet 不在本机或端口配置不同，请按实际地址填写。 |
| `cubemastercli.binary` | 可选：已编译的原版 `cubemastercli` 路径；需有执行权限，无需 Go。填写后在压测前后查询实例清单。若不使用 CLI 采集，删除整个 `cubemastercli` 字段。 |
| `cubemastercli.address` | CubeMaster 的主机名或 IP，不带 `http://`、端口或路径；不是 CubeAPI 地址。示例 `127.0.0.1` 表示本机。 |
| `cubemastercli.port` | CubeMaster HTTP 端口，示例为 `8089`；按部署实际值填写。 |
| `cubemastercli.exclusive_template` | 默认 `false`，只保存候选实例。只有确认本轮期间没有其他使用者或任务用同一模板创建实例，才改为 `true`，允许依据前后快照及校验条件推定本轮实例集合；它不会锁定模板。 |

配置中的路径和地址都是占位示例。CLI 必须连接本轮 CubeAPI 使用的 CubeMaster。详见[实例归属与 CLI 采集](docs/CAPTURE100.md#实例归属与-cli-采集)。

配置完成后，每轮直接运行：

```sh
python3 capture_100.py
```

默认始终读取仓库根目录的 `capture100.local.json`，不会重复询问参数或密钥。缺少配置或凭据时给出错误说明并退出。配置文件已被 Git 忽略，请勿提交或分享其中的密钥。

工具分两步运行用户提供的压测程序：先在独立进程中串行预热（默认 3 次），成功后才开始正式日志与 metrics 采集、获取 CLI 基线，再以 **`c100 n100 w0 create-only`** 执行正式 100 次创建。正式整轮耗时、客户端原始样本和采集范围均与独立预热分开；预热结果另行保存。结束后用浏览器打开终端给出的 `runs/<时间>/analysis/report.html`。

原版 cube-bench 可配合 `cubemastercli` 获取实例集合，无需修改源码或重新编译。确认整个运行期间模板独占并设置 `exclusive_template: true`，且前后健康快照、正式结果和新增恰好 100 个运行实例等校验通过时，工具将基线之后的新增集合标为 **formal（依据独占声明与快照推定）**。预热实例已包含在基线中，不计入正式集合；客户端 `seq` 与实例 ID 仍不能逐条对应。不满足归属条件时保留候选 ID 或 `unknown_phase`，不会为了显示完整报告强行分组。

默认最多发起 103 次创建；设置 `warmup: N` 时最多发起 `100 + N` 次。**工具不自动删除实例，包括预热实例。** 模板由用户预先创建；如需 2 vCPU、2 GiB 内存、1 GiB 可写层，请选择对应模板。

两次调用均添加 `-no-tui` 并通过 `-o` 保存 JSON（`N` 来自配置；为 0 时跳过第一条）：

```sh
cube-bench -c 1 -n N -w 0 -m create-only -no-tui \
  -t <template_id> -o <run_dir>/warmup/benchmark.raw.json
cube-bench -c 100 -n 100 -w 0 -m create-only -no-tui \
  -t <template_id> -o <run_dir>/capture/startup-latency/benchmark.raw.json
```

独立预热用于预先使用服务端缓存和资源，**不会复用正式进程的 HTTP 客户端连接**，因此与旧版单进程 `-w 3` 不是完全相同的性能实验。预热失败立即停止，不启动正式采集；终端实时显示错误，详情保留在 `warmup/command.log` 与 `warmup/warmup-manifest.json`。

启动时终端会打印 JSON 的绝对路径。文件包含正式请求原始时延和汇总结果；分析目录也保留一份 `analysis/benchmark-inputs/benchmark.raw.json`。终端继续显示进度与错误，JSON 保存到文件。

运行时终端会实时显示 cube-bench 输出，并打印退出码和日志绝对路径。失败时先查看终端报错；原始输出保存在 `runs/<时间>/capture/evidence/command.log`，结果校验明细在 `capture/startup-latency/runner-validation.json`。终端遮蔽当前已知的 API key，原始日志保留原文。详见[运行失败如何排查](docs/CAPTURE100.md#运行失败如何排查)。

工具自动记录二进制 SHA-256，无需手工填写；哈希用于检查文件一致性，不证明版本。二进制需兼容官方 v0.7.1 的压测参数与 JSON 输出。源码构建增强输出仍是可选模式，仅该模式需要 Go；使用 CLI 获取实例集合不需要此模式。

查看[一键采集说明](docs/CAPTURE100.md)，了解配置修改、运行前检查和日志覆盖。

## 只分析已有数据

需要 Python 3.9+、Node.js 18+。离线分析不访问部署、不启动压测；输入保持不变，结果写入新目录。

```sh
python3 profiler.py doctor
python3 profiler.py analyze examples/synthetic-capture --output /tmp/cubesandbox-example
```

输出目录必须尚不存在。样例是**合成数据**，用于熟悉工具，不是性能测试结果。首先打开输出中的 `report.html` 查看整轮耗时、单次启动时延和阶段汇总；`REPORT.md` 提供同内容文本报告。`timeline.html` 用于逐实例时间轴，`analysis.json` 和 `stage-latency.csv` 保留完整分阶段统计。

```sh
open /tmp/cubesandbox-example/report.html  # macOS；其他系统用浏览器打开此文件
```

分析自己的采集数据：

```sh
python3 profiler.py analyze /path/to/capture --output /path/to/new-analysis
```

- [快速上手：输入、输出与数据解释](docs/QUICKSTART.md)
- [兼容性与测量限制](docs/COMPATIBILITY.md)
- [启动阶段口径：简版条状图与整体关系图](scripts/STAGES.md#各阶段整体关系)
- [底层脚本与采集说明](scripts/README.md)

需要其他并发规模、自定义 runner 或日志映射时，使用[高级采集器](scripts/README.md#采集日志与-metrics)。工具不会部署 CubeSandbox 或生成模板。

## 解读结果

HTML 报告先展示阶段关系，再展示耗时：整体示意与可折叠层级表达包含、顺序、并行等待和后台异步。每行保留平均值、P95 与实例覆盖；传播值和派生值单独归区，完整原始表可展开查看。图形不按时延比例绘制，不把父子或并行阶段相加。

整轮耗时来自 runner 的明确计时，官方 cube-bench 使用 `summary.total_time_s`（秒，排除预热）。外部命令窗口、采集窗口另列；计时缺失时不会用单次延迟的总和或最大值替代。`run-summary.json` 保留数值和来源，`benchmark-inputs/` 保留已提供的客户端结果原始文件。本入口的预热在独立进程中完成，报告单独显示其耗时，详见[计时与预热口径](docs/QUICKSTART.md#整轮耗时与-warmup)。

阶段分布描述实际观测到的记录。Cubelet 短成功阶段可能不写日志，缺失不代表零时延；父子阶段和并行阶段不能直接相加。时间轴仅绘制有起止证据的区间，不用异步日志写出时间倒推执行时间。

归属未知的实例保留 `unknown_phase`；旧采集中的混合样本不会因更改配置自动成为正式样本。分析命令完成不等于正式测试有效。客户端请求统计与组件阶段可能属于不同样本集合，不能强行逐条对应。具体分组策略与需要保留的证据见快速上手。

原始日志及分析产物可能含实例 ID、路径、环境变量或凭据。本工具不是脱敏器，分享数据前应检查内容。

## 开发验证

```sh
make test
```

测试仅使用合成数据，不连接部署。来源与许可见 [NOTICE.md](NOTICE.md)。
