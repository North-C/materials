# Synthetic offline example

`synthetic-capture/` is hand-written, artificial data. It is **not** a cluster
capture or performance claim. Two owned IDs and one foreign log ID demonstrate
attribution for an arbitrary two-request workload.

```sh
python3 profiler.py doctor
python3 profiler.py analyze examples/synthetic-capture --output /tmp/cubesandbox-example
python3 profiler.py analyze examples/synthetic-capture --phase-map examples/synthetic-phase-map.json --output /tmp/cubesandbox-declared-example
```

Choose new output paths if those directories already exist. Without a map,
`classification_status` is `unverified`, both owned IDs stay in `unknown_phase`,
and `formal` has zero instances. With the explicit synthetic map, status is
`declared` and formal has two instances. **Declared does not mean independently
verified**: the caller is responsible for the map's provenance and run ownership.
Both commands print that distinction on stderr. No phase is inferred from the
order of log timestamps or an assumed number of warmup requests.

The Cubelet service mean is 25 ms; the foreign 9,999 ms record is excluded. The
same-instance service-minus-cubebox residual mean is 7.5 ms. The two-request
manifest matches the raw configuration. That match verifies configuration
consistency only, never execution or performance. Missing precision and metrics
evidence remains absent.

Open `report.html` or `REPORT.md` first. The synthetic formal run is 50 ms,
while individual request mean/max are 35/40 ms. The independent command window
is 2,000 ms and capture window is 10,000 ms. These deliberately different values
demonstrate timing scope, not real performance. `run-summary.json` preserves
the values and sources; `benchmark-inputs/` preserves supplied client files
byte-for-byte.

Open `timeline.html`, or inspect `analysis.json`, `stage-latency.csv`,
`phase-classification.json`, and `analysis-manifest.json` in the output directory.
No input files are changed, no sandbox is created, and no network is contacted.
If an ID is claimed by multiple original phases, it remains excluded;
`analysis-manifest.json` records `conflicting_ownership_ids`. An explicit map
cannot rescue a conflicting ID or add an ID absent from original ownership.
