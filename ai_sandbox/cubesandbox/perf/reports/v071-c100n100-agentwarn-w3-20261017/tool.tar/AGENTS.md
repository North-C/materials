# Repository guidance

- This repository analyzes CubeSandbox startup evidence. Preserve missing data, coverage, phase ownership and independent clocks; never invent timings or promote unknown samples to formal.
- Offline analysis must not deploy services, start benchmarks, delete sandboxes, contact the target host, or modify input evidence.
- Keep this repository generic. Do not commit deployment reports, host identities, credentials, real captures, private paths, or environment-specific fixtures.
- Run `make test` after changing parsers or the CLI. Use synthetic examples for smoke tests; they are not performance results.
- Do not add Signed-off-by tags. Commits authored by an agent must include `Autonomously-by: AGENT_NAME:MODEL_VERSION` (or `Assisted-by` for human-authored work).
