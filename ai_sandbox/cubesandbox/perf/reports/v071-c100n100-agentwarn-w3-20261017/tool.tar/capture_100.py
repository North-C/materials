#!/usr/bin/env python3
"""Warm up separately, then capture a c100/n100/w0 Template startup run."""
import argparse
from datetime import datetime, timezone
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import uuid
from urllib.parse import urlsplit

from profiler import doctor
from scripts.capture import sha256
from scripts.cube_bench_runner import prepare_benchmark
from scripts.cubemaster_inventory import validate_options
from scripts.prewarmup import run_warmup, write_private

ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = ROOT / "capture100.local.json"
OWNERSHIP_HINTS = json.loads((ROOT / "scripts/ownership_diagnostics.json").read_text())
LOG_PATHS = {
    "cubelet_req": "Cubelet/Cubelet-req.log",
    "cubelet_stat": "Cubelet/Cubelet-stat.log",
    "shim_req": "CubeShim/cube-shim-req.log",
    "shim_stat": "CubeShim/cube-shim-stat.log",
    "master": "CubeMaster/cubemaster-req.log",
    "master_stat": "CubeMaster/cubemaster-stat.log",
    "vmm": "CubeVmm/vmm.log",
}


def prompt(label, default=""):
    value = input(label + (f" [{default}]" if default else "") + ": ").strip()
    return value or default


def configure(path, binary_override=None):
    if not sys.stdin.isatty():
        raise ValueError("首次配置需要交互终端；也可复制 examples/capture100.config.json 后使用 --config。")
    previous = json.loads(path.read_text()) if path.exists() else {}
    value = {
        "benchmark_binary": str(binary_override) if binary_override else prompt("已编译的 cube-bench 路径", previous.get("benchmark_binary", "")),
        "api_url": prompt("CubeAPI 地址（例如 https://sandbox.example.com）", previous.get("api_url", "")),
        "template_id": prompt("已构建的 Template ID", previous.get("template_id", "")),
        "log_root": prompt("本机日志根目录", previous.get("log_root", "/data/log")),
        "metrics_url": prompt("metrics 地址（留空禁用）"),
        "warmup": previous.get("warmup", 3),
    }
    # Keep explicit per-file overrides when updating the common options.
    if "logs" in previous:
        value["logs"] = previous["logs"]
    if "cubemastercli" in previous:
        value["cubemastercli"] = previous["cubemastercli"]
    if "api_key" in previous:
        value["api_key"] = previous["api_key"]
    validate_config(value)
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise ValueError("配置文件不能是符号链接。")
    fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as stream:
        os.fchmod(stream.fileno(), 0o600)
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")
    print(f"配置已保存：{path}；请在文件中填写 api_key，或设置 E2B_API_KEY。")
    return value


def endpoint(value, label, optional=False):
    if optional and not value:
        return
    if not isinstance(value, str):
        raise ValueError(f"{label} 必须是 HTTP(S) 地址。")
    parsed = urlsplit(value)
    if (parsed.scheme not in ("http", "https") or not parsed.hostname or parsed.username
            or parsed.password or parsed.query or parsed.fragment):
        raise ValueError(f"{label} 必须是无凭据、查询参数或片段的 HTTP(S) 地址。")


def validate_config(config):
    if not isinstance(config, dict):
        raise ValueError("配置必须为 JSON 对象。")
    allowed = {"source", "benchmark_binary", "api_url", "api_key", "template_id", "log_root", "logs", "metrics_url", "cubemastercli", "warmup"}
    if set(config) - allowed:
        raise ValueError("配置含未知字段，请参照 examples/capture100.config.json。")
    if "api_key" in config and not isinstance(config["api_key"], str):
        raise ValueError("api_key 必须是字符串，也可留空并设置 E2B_API_KEY。")
    if type(config.get("warmup", 3)) is not int or config.get("warmup", 3) < 0:
        raise ValueError("warmup 必须是非负整数；默认 3，设为 0 禁用独立预热。")
    if ("source" in config) == ("benchmark_binary" in config):
        raise ValueError("请提供 benchmark_binary 路径；源码构建模式使用 source，二者选其一。")
    for key in ("benchmark_binary" if "benchmark_binary" in config else "source", "template_id", "log_root"):
        if not isinstance(config.get(key), str) or not config[key].strip():
            raise ValueError(f"配置缺少 {key}。")
    if "cubemastercli" in config:
        validate_options(config["cubemastercli"])
    endpoint(config.get("api_url"), "api_url")
    endpoint(config.get("metrics_url"), "metrics_url", optional=True)
    logs = config.get("logs", {})
    if not isinstance(logs, dict) or set(logs) - (set(LOG_PATHS) | {"api"}):
        raise ValueError("logs 必须为已知日志类型到绝对路径的映射。")
    for name, value in logs.items():
        if not isinstance(value, str) or not Path(value).is_absolute():
            raise ValueError(f"logs.{name} 必须是绝对路径。")


def log_files(config):
    root = Path(config["log_root"]).expanduser().resolve()
    paths = {name: root / relative for name, relative in LOG_PATHS.items()}
    paths.update({name: Path(value) for name, value in config.get("logs", {}).items()})
    return paths


def check_local(config):
    validate_config(config)
    if platform.system() != "Linux":
        raise ValueError("在线采集入口须在有日志读取权限的 Linux 节点运行。离线分析可在其他系统运行。")
    if doctor()["status"] != "ok":
        raise ValueError("需要 Python 3.9+、Node.js 18+。")
    if "benchmark_binary" in config:
        source = Path(config["benchmark_binary"]).expanduser().resolve()
        if not source.is_file():
            raise ValueError(f"cube-bench 文件不存在或不是普通文件：{source}")
        if not os.access(source, os.X_OK):
            raise ValueError(f"cube-bench 没有执行权限：{source}；请检查文件权限。")
    else:
        if not shutil.which("go"):
            raise ValueError("仅源码构建模式需要 Go；已有二进制请使用 --benchmark-binary。")
        source = Path(config["source"]).expanduser().resolve()
        bench = source / "examples/cube-bench" if (source / "examples/cube-bench").is_dir() else source
        if not all((bench / name).is_file() for name in ("main.go", "runner.go", "go.mod")):
            raise ValueError("source 中没有 examples/cube-bench 源码。")
    if "cubemastercli" in config:
        cli = Path(config["cubemastercli"]["binary"]).expanduser().resolve()
        if not cli.is_file() or not os.access(cli, os.X_OK):
            raise ValueError(f"cubemastercli 文件不存在或没有执行权限：{cli}")
        if not config["cubemastercli"].get("exclusive_template", False):
            print("归属提示：" + OWNERSHIP_HINTS["inventory_template_exclusivity_not_asserted"])
    elif "benchmark_binary" in config:
        print("归属提示：未配置 cubemastercli；若 cube-bench 原始 JSON 不含 sandbox_id，将只能展示客户端时延，无法关联组件阶段。请按 docs/CAPTURE100.md 配置 CLI 采集。")
    paths = log_files(config)
    readable = []
    for name, path in paths.items():
        try:
            with path.open("rb"):
                pass
            readable.append(name)
        except OSError:
            print(f"提示：{name} 日志不可读，将保留缺失状态。")
    if not readable:
        raise ValueError("未找到可读组件日志；请设置 log_root 或 logs 中的独立路径。")
    print("本地检查通过；可读日志：" + ", ".join(readable))
    return source


def capture_command(config, run, binary):
    capture = run / "capture"
    command = [sys.executable, str(ROOT / "scripts/capture.py"),
               "--output", str(capture), "--owned-ids", str(capture / "ownership-input.json"),
               "--benchmark-binary", str(binary), "--benchmark-sha256", sha256(binary),
               "--concurrency", "100", "--requests", "100", "--warmup", "0",
               "--template-id", config["template_id"], "--stream-output"]
    for name, path in log_files(config).items():
        command.extend(["--log", f"{name}={path}"])
    if "api" not in config.get("logs", {}):
        command.extend(["--api-log-dir", str(Path(config["log_root"]).expanduser().resolve() / "CubeAPI")])
    if config.get("metrics_url"):
        command.extend(["--metrics-url", config["metrics_url"]])
    command.extend(["--", sys.executable, str(ROOT / "scripts/cube_bench_runner.py")])
    return command


def execute(config, source, output_root, api_key):
    output_root.mkdir(parents=True, exist_ok=True)
    run = output_root / (datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ-") + uuid.uuid4().hex[:8])
    run.mkdir(mode=0o700)
    print(f"本轮输出：{run}", flush=True)
    if "benchmark_binary" in config:
        binary = source
        print("使用已有 cube-bench；无需 Go，不重新编译。", flush=True)
        with (run / "binary-info.json").open("x") as stream:
            os.chmod(stream.name, 0o600)
            json.dump({"mode": "prebuilt", "sha256": sha256(binary),
                       "version_verified": False, "built_by_profiler": False}, stream, indent=2)
    else:
        print("准备 cube-bench 源码副本并构建；构建不计入测试耗时。", flush=True)
        binary = prepare_benchmark(source, run / "benchmark")
    env = os.environ.copy()
    env.update(E2B_API_URL=config["api_url"].rstrip("/"), E2B_API_KEY=api_key, PYTHONUNBUFFERED="1",
               CUBE_CAPTURE_WARMUP="0")
    # Do not let an inherited runner-only variable enable an unconfigured collector.
    env.pop("CUBE_CAPTURE_CUBEMASTERCLI", None)
    if "cubemastercli" in config:
        options = dict(config["cubemastercli"])
        options["binary"] = str(Path(options["binary"]).expanduser().resolve())
        env["CUBE_CAPTURE_CUBEMASTERCLI"] = json.dumps(options)
        print("通过 cubemastercli 保存测试前后实例清单；不修改 cube-bench，不自动删除实例。", flush=True)
    warmup_code, prewarmup = run_warmup(binary, config["template_id"], config.get("warmup", 3), run / "warmup", env)
    if warmup_code:
        print(f"独立预热未通过，未启动正式测试。请查看：{run / 'warmup/command.log'} 和 {run / 'warmup/warmup-manifest.json'}", file=sys.stderr, flush=True)
        return warmup_code
    capture = run / "capture"
    command_log = capture / "evidence/command.log"
    validation_file = capture / "startup-latency/runner-validation.json"
    print(f"cube-bench：{binary}\n实时输出同时保存到：{command_log}", flush=True)
    print("开始正式采集：100 并发上限 / 100 次正式创建 / cube-bench -w 0；预热和正式实例均保留。", flush=True)
    result = subprocess.run(capture_command(config, run, binary), env=env)
    print(f"采集命令退出码：{result.returncode}", flush=True)
    if result.returncode:
        print(f"压测执行或结果校验失败（退出码 {result.returncode}）。\n命令日志：{command_log}\n校验明细（若已生成）：{validation_file}", file=sys.stderr, flush=True)
    if not (capture / "capture-manifest.json").is_file():
        print(f"采集未完成，未生成 capture-manifest.json；请检查上方错误和本轮目录：{run}", file=sys.stderr, flush=True)
        return result.returncode or 1
    # Keep separate pre-capture evidence with the capture for portable offline
    # reporting. Never merge warmup rows into formal benchmark.raw.json.
    inputs = capture / "startup-latency"
    inputs.mkdir(exist_ok=True, mode=0o700)
    write_private(inputs / "prewarmup.json", prewarmup)
    warmup_raw = run / "warmup/benchmark.raw.json"
    if warmup_raw.is_file():
        shutil.copyfile(warmup_raw, inputs / "prewarmup.raw.json")
        (inputs / "prewarmup.raw.json").chmod(0o600)
    analysis = run / "analysis"
    command = [sys.executable, str(ROOT / "profiler.py"), "analyze", str(capture), "--output", str(analysis)]
    # This is a runner declaration from response IDs, not independent service verification.
    # Use the collector-normalized set so rejected ownership cannot be resurrected.
    owned = json.loads((capture / "owned-sandbox-ids.json").read_text())
    if owned.get("formal") or owned.get("warmup"):
        command.extend(["--phase-map", str(capture / "owned-sandbox-ids.json")])
    if validation_file.is_file():
        validation = json.loads(validation_file.read_text())
        print(f"cube-bench 退出码：{validation.get('benchmark_exit_code', '未知')}；结果校验：{validation.get('status', '未知')}", flush=True)
        if validation.get("problems"):
            problems = "; ".join(str(p) for p in validation["problems"])
            print("校验问题：" + problems.replace(api_key, "[REDACTED]"), file=sys.stderr, flush=True)
        for warning in validation.get("warnings", []):
            print("提示：" + str(warning).replace(api_key, "[REDACTED]"), flush=True)
        inventory = validation.get("inventory") or {}
        if inventory:
            print(f"CLI 归属：{'已采用' if inventory.get('accepted') else '未采用'}；新增候选 {len(inventory.get('candidate_ids', []))}；预期 {inventory.get('expected_count', '未知')}", flush=True)
        for problem in dict.fromkeys([*validation.get("problems", []), *inventory.get("errors", [])]):
            hint = OWNERSHIP_HINTS.get(problem, "查看 runner-validation.json 和 capture/evidence/cubemastercli/ 中的原始校验记录。")
            print((f"归属/校验诊断 [{problem}]：{hint}").replace(api_key, "[REDACTED]"), file=sys.stderr, flush=True)
    print("正在根据已保留的数据生成报告。", flush=True)
    report = subprocess.run(command)
    if report.returncode == 0:
        print(f"报告：{analysis / 'report.html'}\n原始采集：{capture}")
    else:
        print(f"报告生成失败（退出码 {report.returncode}），原始数据仍保存在：{capture}", file=sys.stderr, flush=True)
    return result.returncode or report.returncode


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--benchmark-binary", type=Path, help="使用已有 cube-bench，无需 Go；覆盖本轮配置")
    parser.add_argument("--configure", action="store_true", help="重新填写配置，然后运行")
    parser.add_argument("--check", action="store_true", help="仅检查本地配置与依赖，不构建、不连接部署、不压测")
    parser.add_argument("--output-root", type=Path, default=ROOT / "runs")
    args = parser.parse_args(argv)
    try:
        if not args.config.exists() and not args.configure:
            print(f"配置文件不存在：{args.config}\n请复制 examples/capture100.config.json 到该路径，填写配置后重新运行。", file=sys.stderr)
            return 2
        config = configure(args.config, args.benchmark_binary) if args.configure else json.loads(args.config.read_text())
        if args.benchmark_binary:
            config.pop("source", None)
            config["benchmark_binary"] = str(args.benchmark_binary)
        source = check_local(config)
        if args.check:
            return 0
        api_key = os.environ.get("E2B_API_KEY") or config.get("api_key", "")
        if not api_key.strip() or api_key == "YOUR_API_KEY":
            raise ValueError("请在本地配置填写 api_key，或设置 E2B_API_KEY；默认运行不会交互询问。")
        return execute(config, source, args.output_root.expanduser().resolve(), api_key)
    except KeyboardInterrupt:
        print("已中断；已创建实例不会自动删除。", file=sys.stderr)
        return 130
    except (OSError, ValueError, subprocess.CalledProcessError) as exc:
        # Show actionable setup errors without dumping subprocess argv/environment.
        if isinstance(exc, OSError):
            message = f"运行失败：{type(exc).__name__}，errno={exc.errno}，{exc.strerror}"
            if exc.filename:
                message += f"；文件：{exc.filename}"
        elif isinstance(exc, subprocess.CalledProcessError):
            message = f"构建或子命令失败，退出码 {exc.returncode}；请查看上方输出。"
        else:
            message = str(exc)
        print(message, file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
