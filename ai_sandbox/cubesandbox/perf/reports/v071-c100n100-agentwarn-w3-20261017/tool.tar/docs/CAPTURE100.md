# 100 并发 Template 启动采集

在能读取 CubeSandbox 日志的 Linux 节点上执行。准备 Python 3.9+、Node.js 18+、已编译的 `cube-bench`，以及已经可用的 API 和模板。直接提供二进制路径即可，无需安装 Go 或提供源码。

## 开始采集

在本工具仓库根目录复制配置，然后编辑其中的占位值：

```sh
cp examples/capture100.config.json capture100.local.json
chmod 600 capture100.local.json
```

配置样例：

```json
{
  "benchmark_binary": "/path/to/cube-bench",
  "api_url": "https://sandbox.example.com",
  "template_id": "YOUR_TEMPLATE_ID",
  "api_key": "YOUR_API_KEY",
  "warmup": 3,
  "log_root": "/data/log",
  "metrics_url": "http://127.0.0.1:9998/v1/metrics",
  "cubemastercli": {
    "binary": "/path/to/cubemastercli",
    "address": "127.0.0.1",
    "port": 8089,
    "exclusive_template": false
  }
}
```

| 字段 | 如何填写 |
| --- | --- |
| `benchmark_binary` | 已编译的 `cube-bench` 可执行文件路径，建议使用绝对路径；需有执行权限。无需 Go 或源码。 |
| `api_url` | 创建沙箱所使用的 CubeAPI 基础地址，例如 `https://sandbox.example.com`；不是 metrics 地址。 |
| `template_id` | 已创建且可用的模板 ID。若需 2 vCPU、2 GiB 内存、1 GiB 可写层，请预先构建对应模板。 |
| `api_key` | 与该 API 对应的访问密钥，可直接填入本地配置。也可留空并设置 `E2B_API_KEY`；环境变量优先。 |
| `warmup` | 独立预热的创建次数，非负整数，默认 `3`；设为 `0` 禁用。旧配置未填写时也默认 `3`。正式 cube-bench 固定使用 `-w 0`。 |
| `log_root` | 运行采集脚本的 Linux 节点上，CubeSandbox 日志根目录，常见为 `/data/log`；需有读取权限。 |
| `metrics_url` | 可留空 `""` 禁用。Cubelet 默认一般为 `http://127.0.0.1:9998/v1/metrics`；`127.0.0.1` 指运行采集脚本的本机，非远端 API 主机。若 Cubelet 不在本机或端口配置不同，请按实际地址填写。 |
| `cubemastercli.binary` | 可选：已编译的原版 `cubemastercli` 路径；需有执行权限，无需 Go。填写后在压测前后查询实例清单。若不使用 CLI 采集，删除整个 `cubemastercli` 字段。 |
| `cubemastercli.address` | CubeMaster 的主机名或 IP，不带 `http://`、端口或路径；不是 CubeAPI 地址。示例 `127.0.0.1` 表示本机。 |
| `cubemastercli.port` | CubeMaster HTTP 端口，示例为 `8089`；按部署实际值填写。 |
| `cubemastercli.exclusive_template` | 默认 `false`，只保存候选实例。只有确认本轮期间没有其他使用者或任务用同一模板创建实例，才改为 `true`，允许依据前后快照及校验条件推定本轮实例集合；它不会锁定模板。 |

配置中的路径和地址都是占位示例。CLI 必须连接本轮 CubeAPI 使用的 CubeMaster。详见[实例归属与 CLI 采集](#实例归属与-cli-采集)。

填写一次后，每轮直接运行：

```sh
python3 capture_100.py
```

默认读取仓库根目录的 `capture100.local.json`，不交互询问参数或密钥。缺少配置时提示复制样例并退出；缺少密钥时也直接报错。密钥优先使用 `E2B_API_KEY`，否则使用配置中的 `api_key`。本地配置已加入 Git 忽略规则，勿提交或分享；`chmod 600` 将读取权限限制为当前用户。

工具直接运行二进制，不构建。所选程序必须支持官方 v0.7.1 的 `-c`、`-n`、`-w 0`、`-m create-only` 模式、`-o` JSON 输出及 `-no-tui` 等接口。工具自动计算并记录 SHA-256，无需自行填写；它检查文件一致性，不证明程序或服务的版本。

本入口固定运行：

| 参数 | 值与含义 |
| --- | --- |
| 并发 | `100`，并发上限；不代表 100 个请求在完全相同的时刻发出 |
| 正式请求数 | `100` 次创建尝试 |
| 预热 | 配置 `warmup`，默认 `3`，可设 `0`；先用独立进程串行创建，成功后开始正式采集与测试 |
| 模式 | `create-only`，创建后不自动删除 |
| 终端界面 | 固定添加 `-no-tui`，关闭交互式 TUI，保留进度与错误输出 |
| JSON 输出 | 两次调用均添加 `-o`；预热保存至 `warmup/benchmark.raw.json`，正式保存至 `capture/startup-latency/benchmark.raw.json`，启动时打印完整路径 |

模板的 CPU、内存和可写层由所选模板决定，工具不修改或验证其资源规格。如需 2 vCPU、2 GiB 内存、1 GiB 可写层，应预先构建并选择对应模板。

**运行会创建真实实例，默认最多发起 103 次创建（3 次独立预热 + 100 次正式请求）；配置 `warmup: N` 时最多发起 `100 + N` 次。** 请按自己的环境安排测试容量；结束后自行清理属于本轮的实例，包括预热实例。创建失败也会保留结果，不补发请求以凑足成功数。

## 预热与正式采集边界

填写 `warmup: N` 后，入口按以下顺序执行，无需手动运行两次：

1. 运行已有二进制 `cube-bench -c 1 -n N -w 0 -m create-only -no-tui -t <template_id> -o <run_dir>/warmup/benchmark.raw.json`。`N=0` 时跳过此步骤。
2. 检查预热退出码和原始结果。失败则停止，保留预热日志与错误，不启动正式采集。
3. 开始正式日志和 metrics 采集，获取 `cubemastercli` 基线；预热创建的实例保留在基线中。
4. 运行 `cube-bench -c 100 -n 100 -w 0 -m create-only -no-tui -t <template_id> -o <run_dir>/capture/startup-latency/benchmark.raw.json`，随后获取 CLI 清单、完成采集与分析。

两次均使用用户提供的二进制，无需修改 cube-bench 源码。配置中的 `warmup` 表示独立预热次数；正式 capture manifest 和正式原始结果中的 `warmup` 均为 `0`。预热元数据另存 `capture/startup-latency/prewarmup.json`，报告单独显示预热耗时。

独立预热会先使用服务端缓存和资源，但进程结束后不会将 HTTP 客户端连接传给正式进程。因此，这个方案与过去同一进程内的 `-w 3` 不完全等价，比较历史性能结果时应记录预热方式变化。预热实例不会自动删除；应与正式实例一起由用户在测试后清理。

## 查看结果

每次运行写入新的目录：

```text
runs/<时间>/
  binary-info.json          # 预编译模式：二进制 SHA-256 等使用记录
  benchmark/                # 仅源码模式：源码副本、build-info.json 与构建产物
  warmup/                   # 独立预热证据（0 次时仅保存 skipped 清单）
    benchmark.raw.json      # 预热请求原始时延与汇总；不是正式样本
    command.log             # 预热实时输出；遮蔽已知 API key 明文
    warmup-manifest.json     # 预热执行、校验状态及错误
  capture/                  # 正式日志增量、metrics、配置、原始压测结果与实例归属
    startup-latency/
      prewarmup.json        # 独立预热元数据，与正式 benchmark 分开
      prewarmup.raw.json    # 预热原始 JSON 副本（启用预热时）
  analysis/
    report.html             # 浏览器打开，从这里看结果
    REPORT.md               # 文本报告
    run-summary.json        # 整轮耗时及证据来源
    benchmark-inputs/       # 客户端结果原始文件
    stage-latency.csv       # 阶段统计
    timeline.html           # 逐实例时间轴
    ...
```

打开终端打印的 `analysis/report.html`。可以将整份 `analysis` 目录复制到自己的电脑后离线查看，不需要 Web 服务。文件详情见[输出说明](QUICKSTART.md#4-查看输出)。

正式测试整轮耗时取自正式 cube-bench 的 `summary.total_time_s`，排除独立预热。正式原始结果的 `raw` 保存 100 次正式请求。独立预热进程的 `raw` 则保存其预热请求，存放在 `warmup/benchmark.raw.json`；虽然这是 cube-bench 自身的正式请求字段，在本工具中它们属于独立预热，不混入正式报告统计。

普通官方 v0.7.1 二进制不导出实例 ID。配置 CLI 并满足下述条件后，可以推定正式 100 个实例的集合并分析服务端阶段，但仍不能把客户端 `raw` 中每条请求与实例逐条对应。若二进制明确导出 ID，优先使用该证据。正式外部命令窗口与正式采集窗口单独展示，包含各自的外围操作，不能替代正式整轮耗时；独立预热耗时另列。`analysis/benchmark-inputs/prewarmup.json` 与 `prewarmup.raw.json` 保留对应元数据与原始结果，复制完整 analysis 目录即可复核。

## 实例归属与 CLI 采集

旧版采集脚本通过 `GET /sandboxes` 与日志中的 `InstanceId` 获取实例，并非通过 `cubemastercli`。新入口补充 CLI 快照，继续使用原版 `cube-bench`，无需修改压测程序。

配置 `cubemastercli` 后，工具在独立预热成功之后、正式压测之后各执行一次 `cubemastercli list --all --wide`，通过所配置的 CubeMaster 查询健康节点的实例快照。第一份是正式采集的基线，包含预热实例及原有实例；正式压测固定为 `c100 n100 w0 create-only`。

v0.7.1 的 `list --all` 只遍历健康节点；`NODES_SCANNED N/N` 仅表明报告已遍历的节点数，CubeMaster 可能吞掉单节点 RPC 失败，因此它不能独立证明清单完整。下面的归属结论依赖用户对模板独占的声明，属于推定，不是独立的归属验证。

CLI 给出的是服务端实例清单，不能把实例 ID 与客户端 `raw` 中的每条样本一一对应。独立预热时延来自单独进程的 JSON，不依赖 CLI 恢复。为防止把共享环境中的他人实例计入本轮，工具按以下条件处理：

- 默认 `exclusive_template: false`：保存匹配模板的新增候选 ID，不认定它们属于本轮。
- 用户确认模板在整个采集期间独占并设置 `exclusive_template: true` 后，还必须满足：前后快照通过解析与节点遍历校验、前后节点数不变且旧 ID 未消失、正式压测后该模板新增实例恰好 100 个且均为 running、正式 cube-bench 配置为 `w0`、退出码为 0 且 100 个正式结果均成功有效。满足这些条件时，才依据用户的独占声明与快照推定正式实例集合；这些检查不能消除 CLI 隐藏节点查询失败的限制。
- 满足这些条件时，基线之后的新增 100 个实例可作为 `formal` 群体统计服务端阶段；基线中的预热和原有实例被排除。这是依据声明与快照的群体归属推定，仍不是客户端 `seq` 到实例 ID 的逐条映射。
- 已有原始结果明确导出的 ID 与阶段归属优先，CLI 不覆盖它们。检测到失败、超时、缺失节点或清单不完整时会留下限制说明，不按创建时间取前三个当作预热，也不凑数补 ID。

`exclusive_template: true` 只是用户对测试环境的声明，工具不会对模板加锁，也不能根据推定的集合自动删除实例。如需客户端请求与实例逐条对应，仍需原始结果中的明确实例 ID；可选的源码增强模式用于提供这类证据，不是普通 CLI 采集的前提。旧采集中混合预热与正式的 `unknown_phase` 不会因为修改新配置自动变成 `formal`。

证据保存于：

```text
capture/evidence/cubemastercli/
  before.stdout    # 压测前 CLI 标准输出
  before.stderr    # 压测前 CLI 错误输出
  before.json      # 压测前解析结果及快照校验
  after.stdout     # 压测后 CLI 标准输出
  after.stderr     # 压测后 CLI 错误输出
  after.json       # 压测后解析结果及快照校验
  ownership.json   # 候选 ID、归属依据及限制
```

`analysis/inventory-evidence/` 保留全部 CLI 证据，复制分析目录即可一并核查。`analysis/run-summary.json` 的 `inventory` 与 `runner_validation` capability 信息记录实例集合来源和仍缺失的能力，例如客户端逐条映射。

正式压测前清单失败时，工具直接退出，不运行正式 cube-bench；已完成的独立预热实例仍可能存在。压测后清单失败时，已产生的 benchmark 原始结果与报告仍保留，但工具以非零退出码提示采集未完整完成。未配置 `cubemastercli` 时保持原来的采集方式。无论使用哪种方式，工具都不自动删除实例。

## 运行失败如何排查

`capture_100.py` 默认实时显示 cube-bench 的标准输出和错误输出，同时保存日志。启动时会打印本轮目录、二进制路径及日志路径；结束后分别显示采集命令退出码、cube-bench 退出码和结果校验状态。即使 cube-bench 返回 0，失败请求或无效结果也可能让校验失败，工具会给出原因。

预热失败时查看 `runs/<时间>/warmup/command.log` 和 `warmup/warmup-manifest.json`；此时没有正式采集结果是预期行为。预热命令日志与终端都会遮蔽已知 API key 的明文匹配；原始 JSON 仍需在分享前检查。

若已有正式测试失败记录，无需重跑压测即可查看（将 `<时间>` 替换为本轮目录）：

```sh
tail -n 80 runs/<时间>/capture/evidence/command.log
cat runs/<时间>/capture/startup-latency/runner-validation.json
```

运行期间也可用 `tail -f` 跟踪 `command.log`。该文件最多保留 4 MiB，超出时在采集清单中记录截断；终端实时输出继续显示。终端会遮蔽当前 `E2B_API_KEY` 的明文匹配，原始日志保留原文且采用私有文件权限，分享前仍需检查敏感内容。

- `Exec format error`：检查二进制的操作系统、CPU 架构和可执行格式。
- `Permission denied`：检查二进制执行权限及所在挂载点是否允许执行。
- 文件存在却提示 `No such file or directory`：还需检查脚本解释器或动态加载器是否存在。
- HTTP 401/403、连接失败、模板错误：依据 cube-bench 原始错误检查对应 API、凭据或模板。
- `formal_sandbox_ids_absent`（或 `formal_sandboxes_ids_absent`）：正式样本没有实例 ID，不等于创建失败。CLI 可在独立预热后的基线上推定正式实例集合，但不能恢复客户端逐条映射；检查 `capture/evidence/cubemastercli/ownership.json` 了解是否满足归属条件。
- CLI 快照失败：查看 `capture/evidence/cubemastercli/before.stderr` 或 `after.stderr`，确认 CLI 路径、CubeMaster 地址及节点响应。
- 压测失败后仍可能生成报告：报告用于保留已有证据，不表示压测成功；最终退出码仍为非零。

### 报告提示“缺少可靠的实例 ID 归属”

这表示客户端结果可能正常，但工具没有足够证据将组件日志中的实例归属到本轮。它和“已有实例 ID，但日志没有阶段数值”是两个不同问题。先查看报告顶部的“实例归属与校验诊断”，其中显示原始原因码、候选/预期数量及处理建议；终端也会打印相同的 CLI 拒绝原因。

首先检查示例中的 `cubemastercli.exclusive_template: false`。原版 cube-bench 不输出实例 ID，而 `false` 只收集候选，所以即使创建成功 100 次，组件阶段仍可能为空。只有确认整个运行期间没有其他任务使用相同模板创建实例，才可将该项设为 `true`；它不是模板锁。`--check` 会提前提示该限制，但不会验证远端独占状态。未配置 CLI 时也会提前说明原版二进制无法提供阶段归属。

| 原因码 | 重点检查 |
| --- | --- |
| `inventory_template_exclusivity_not_asserted` | 核实测试窗口的模板独占条件，再修改配置并重新采集。 |
| `inventory_candidate_count_mismatch` | CLI 与 CubeAPI 是否连接同一部署、模板是否一致，以及实例提前删除或其他同模板任务；报告显示实际候选数与预期数。 |
| `inventory_before_invalid` / `inventory_after_invalid` | `inventory-evidence/before.json` / `after.json` 中的 `errors`，以及对应 `.stderr`；可能是连接失败、CLI 版本/输出格式不匹配、节点响应异常。 |
| `benchmark_validation_blocks_attribution` | `benchmark-inputs/runner-validation.json` 的 `problems` 和原始 command.log；先解决压测请求或结果校验失败。 |

修改配置不会改变旧采集的证据，也不要从日志随意补 ID 或取消校验来填满报告。已有完整采集可用新版 `profiler.py analyze` 重新生成诊断，无需再压测；如果旧采集本身缺少可靠归属，则仍需修正配置或部署后重新采集。

## 修改配置与提前检查

修改仓库根目录的 `capture100.local.json` 即可供后续每轮使用。已有配置时，以下参数只覆盖本轮二进制，不修改配置文件：

```sh
python3 capture_100.py --benchmark-binary /path/to/another/cube-bench
```

仅检查本地配置、依赖、可执行文件路径和可读日志，不构建、不访问部署、不执行压测，也不执行 CLI 查询：

```sh
python3 capture_100.py --check
```

本地检查不会验证 API 或 CubeMaster 可达性、CLI 实际运行兼容性、凭据有效性或模板资源。使用另一份配置：

```sh
python3 capture_100.py --config /path/to/capture100.local.json
```

`--output-root /path/to/runs` 可修改结果根目录。需要交互编辑时可显式使用 `--configure`，配合 `--check` 仅配置并检查；交互流程不询问密钥，请在配置文件中填写 `api_key` 或设置环境变量。

配置、日志和产物可能含环境信息，分享前自行检查。API key 不要写进命令参数、URL 或提交到仓库。

默认日志位置相对于 `log_root`：

| 组件 | 相对路径 |
| --- | --- |
| Cubelet | `Cubelet/Cubelet-req.log`、`Cubelet/Cubelet-stat.log` |
| Shim | `CubeShim/cube-shim-req.log`、`CubeShim/cube-shim-stat.log` |
| CubeMaster | `CubeMaster/cubemaster-req.log`、`CubeMaster/cubemaster-stat.log` |
| VMM | `CubeVmm/vmm.log` |
| API | `CubeAPI/` 目录中的最近 API 日志 |

如果部署的日志布局不同，在配置 JSON 中增加 `logs` 映射即可覆盖单个路径，例如 `"logs": {"shim_stat": "/path/to/shim-stat.log"}`。支持的名称见[高级采集说明](../scripts/README.md#采集日志与-metrics)。至少需要一份可读组件日志，缺失的其他日志会标明缺口。

## 可选：源码构建增强输出

如需客户端结果明确导出正式与预热实例 ID，可选择源码构建增强模式；仅获取 CLI 实例集合不必启用。旧配置中的 `"source": "/path/to/CubeSandbox"` 仍受支持；配置使用 `source` 或 `benchmark_binary` 二选一。仅源码模式需要 v0.7.1 源码及满足其 `go.mod` 要求的 Go。工具复制源码到独立目录，补充 `sandbox_id` 与 `warmup_raw` 导出，再构建并运行，不修改原源码；构建时可能下载依赖。该模式保留 `benchmark/build-info.json`、源码副本和构建产物。预编译模式保留 `binary-info.json`，不构建，也不要求源码。

## 覆盖范围

采集只读取运行节点的本地日志，不通过 SSH 自动访问其他节点。多节点部署时，报告只覆盖实际采集到的组件与实例；缺少远端日志的阶段不会补零。日志缺失、轮转或不支持的格式会限制分析，完成运行不代表每个阶段都有数据。

metrics URL 留空时不发起 metrics 请求；填写时快照在独立预热完成后采集，仍可能包括预热引发的延迟异步工作或同一服务上的其他请求，不能自动当作正式 100 次创建的专属指标。没有启用可选观测补丁时，无法生成相应的精细子阶段数据。

本入口适用于单节点的固定正式 `c100 n100 w0` 示例，独立预热次数可配置。需要其他负载、手动日志映射或自定义执行流程时，使用[高级采集器](../scripts/README.md#采集日志与-metrics)；已有抓取数据可随时用[离线分析入口](QUICKSTART.md)重新生成报告。
