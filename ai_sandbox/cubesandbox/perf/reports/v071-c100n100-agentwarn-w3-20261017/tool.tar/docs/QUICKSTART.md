# 离线分析快速上手

所有命令从仓库根目录运行。需要 Python 3.9+、Node.js 18+，无需在分析端安装 CubeSandbox 或官方压测二进制。

**还没有采集数据？** 先复制并填写 `examples/capture100.config.json` 到仓库根目录的 `capture100.local.json`，再在 Linux 目标节点运行 `python3 capture_100.py`，即可完成采集和报告生成：先在独立进程中串行预热（配置 `warmup`，默认 3 次、0 禁用），成功后开始正式采集，再以 `c100 n100 w0` 执行正式 100 次创建。详见[一键采集说明](CAPTURE100.md)。以下介绍已有数据的离线分析。

## 1. 检查分析端并运行样例

```sh
python3 profiler.py doctor
python3 profiler.py analyze examples/synthetic-capture --output /tmp/cubesandbox-example
```

`doctor`仅检查本地运行时。输出目录必须尚不存在，也不能位于输入目录内；参与分析的输入文件不接受符号链接。样例是合成数据，不具有真实性能含义。默认保留`unknown_phase`，不按事件先后猜测预热与正式请求。

## 2. 准备自己的输入

输入目录保留相对结构：

```text
capture/
  capture-manifest.json
  owned-sandbox-ids.json
  evidence/
    cubelet_stat-delta.log
    shim_stat-delta.log
    ...其他可用日志和 metrics...
  startup-latency/
    prewarmup.json           # 可选：独立预热元数据
    prewarmup.raw.json       # 可选：独立预热原始结果，与正式工作负载分开
    benchmark.raw.json       # 可选客户端原始结果
    benchmark.summary.json  # 可选摘要
```

`capture-manifest.json`声明本次工作负载：`concurrency`与`requests`为正整数，`warmup`为非负整数。日志路径、状态和采集缺口保留在`logs`内；采集器生成的 manifest 可直接使用。`capture_100.py` 的独立预热不计入此 manifest 的 `warmup`；正式 manifest 与正式 raw 均为 `warmup: 0`，独立预热信息放在 `startup-latency/prewarmup.json`。客户端 raw 的`config`须与上述配置一致，包括并发、正式请求数、预热数；如声明 mode，也须一致。字段细节可参考 [合成样例](../examples/synthetic-capture/capture-manifest.json)及 [解析器](../scripts/analyze.mjs)。

归属文件使用三个数组，ID 不重复：

```json
{
  "formal": [],
  "warmup": [],
  "unknown_phase": ["example-sandbox-a", "example-sandbox-b"]
}
```

ID 清单决定哪些实例属于本次分析。清单与实际日志不符、缺少记录或有重复调用时，应保留这些异常；不能为了凑齐请求数量填入或删除实例。采集日志需使用当前支持的 CubeSandbox 格式，不是任意文本均能分析。

## 3. 分析与可选分组声明

```sh
python3 profiler.py analyze /path/to/capture --output /path/to/new-analysis
```

入口在临时副本中运行底层分析器，不改写原输入。默认将所有可用 owned ID 归为`unknown_phase`，即使原归属文件写有 formal/warmup，也不会自动把这些标签当成已经验证的实验事实。

若你已独立核对请求归属，可显式提供分组 JSON：

```sh
python3 profiler.py analyze /path/to/capture \
  --phase-map /path/to/phase-map.json \
  --output /path/to/new-declared-analysis
```

该文件同样必须有`formal`、`warmup`、`unknown_phase`三个数组，各组无交集，合并后与原 owned ID 集合一致。正式/预热计数不能超过 manifest 声明的请求数/预热数。部分未知实例可以继续放在`unknown_phase`。

`capture_100.py` 配合 CLI 的自动归属也遵循证据边界：独立预热结束后的基线、用户明确声明模板独占、前后快照校验通过、正式 raw 为成功的 100 次 `w0` 请求且新增恰好 100 个运行实例时，入口才可将差集声明为正式群体。群体归属不提供客户端 `seq` 到实例 ID 的逐条映射；缺少条件时继续保留未知或候选状态。

工具只检查声明的结构、集合及计数，不验证标签背后的实验过程。成功状态为 **`declared`（用户声明）**，不是自动验真的`classified`；默认无声明为`unverified`。终端与`phase-classification.json`保留这个区别。不要把声明映射描述成工具已经证明的正式请求分布。

## 4. 查看输出

| 文件 | 用途 |
| --- | --- |
| `report.html`、`REPORT.md` | 报告入口：整轮耗时、请求时延分布、阶段汇总与数据限制 |
| `run-summary.json` | 正式时间窗口及独立预热的数值、状态、来源，以及工作负载和请求统计；时间单位 ms |
| `benchmark-inputs/` | 已提供客户端 raw/summary 的原始字节副本，以及独立的 `prewarmup.json`/`prewarmup.raw.json`（如有），便于复核 |
| `analysis.json`、`stage-latency.csv` | 分阶段统计、覆盖、状态及同实例残差；主要耗时单位为 ms |
| `instances.jsonl` | 逐实例 CreateContainer 明细 |
| `timeline.html`、`timeline.json` | 可离线打开的部分时间轴；无边界的 duration 仅列数值 |
| `phase-classification.json` | 分组策略、声明检查和限制，不是服务身份验真 |
| `network-details.json/csv` | 网络细分，单位 ns；缺请求日志时 JSON 为 unavailable，不产生 CSV |
| `precision.json/csv`、`precision-timeline.html` | 有 perftrace 时的细分与独立时钟；缺少埋点不虚构子阶段 |
| `analysis-manifest.json` | 本次输入校验值、输出与执行状态 |

先用浏览器打开 `report.html`，或用 Markdown 阅读器查看 `REPORT.md`。HTML 无需联网或启动服务；进一步分析可读取 JSON/CSV。

HTML 的“先看关系，再看耗时”将正式、预热、unknown_phase 分开展示。默认展开有观测的正式组；点击父阶段查看子阶段，绿色虚线表示并行且等待汇合，紫色虚线框表示后台异步。`sandbox-start` 包含 `sandbox-create`，Master probe 传播值及派生残差放在独立折叠区；每行显示自己的样本覆盖，不补零、不合并不同群体。完整原始阶段表仍可展开查看 P50、最大值和全部记录统计。关系图依据 v0.7.1 默认工作流，布局尺寸不表示实测耗时；自定义部署顺序需另外核对。

已有 capture 可直接用上面的离线分析命令生成到新的输出目录，无需重新压测。

### 整轮耗时与 warmup

报告分别列出正式计时窗口；有独立预热元数据时另列预热耗时，不把它们混为一谈：

| 窗口 | 证据与含义 |
| --- | --- |
| 正式测试整轮耗时 | 官方 cube-bench raw 的 `summary.total_time_s`，或独立摘要中的 `total_time_s`；输入单位秒，报告转为 ms |
| 外部命令窗口 | manifest 中 `command.started_at` 到 `command.ended_at`，可能包含初始化、预热和清理 |
| 采集窗口 | manifest 顶层 `started_at` 到 `ended_at`，还包含外围日志与 metrics 采集 |
| 独立预热 | `capture_100.py` 在正式采集之前运行的单独进程；元数据来自 `startup-latency/prewarmup.json`，请求原始结果在本轮 `warmup/benchmark.raw.json` |

v0.7.1 的 cube-bench 先完成 `RunWarmup`，再开始正式计时，计时结束包含正式请求完成、结果收集与进度界面结束。`create-delete` 模式包含请求内删除操作；`create-only` 不包含外部 runner 随后的清理。并发运行的整轮时间不能由单请求耗时求和或取最大值代替。

自定义 runner 可在独立摘要或 raw 的 `summary` 内提供 `benchmark_timing`，例如：

```json
{"benchmark_timing": {"elapsed_ms": 1234.5}}
```

也支持 `elapsed_s`，或同时提供含时区的 `started_at`、`ended_at` 及非空 `clock`（声明两者来自同一个时钟）。通用计时同样应覆盖正式工作负载并排除预热。多个计时证据不一致时标记 `conflict`；无效值标记 `invalid`；没有证据标记 `missing`，不推算整轮时间。外部命令与采集窗口来自墙钟，可能受系统校时影响。

**warmup 是正式测试前的预热操作次数。** 官方 v0.7.1 cube-bench 串行执行这些操作，然后复用 HTTP client 运行正式请求，使连接、缓存等先被使用，但不保证消除全部冷启动开销。例如 `c100 n100 w3` 的 `create-only` 测试是先串行创建 3 次，再以并发上限 100 执行正式 100 次创建；不是预热 3 轮、每轮 100 次。`create-delete` 的一次预热还包含删除。

官方客户端 raw 样本与 `total_time_s` 排除其内置预热；原先单进程 `w3` 的组件日志和 metrics 可能同时包含预热、正式请求以及外围操作。没有可靠 ID 分组时保留 `unknown_phase`，不能删掉最早几条日志来假定排除了预热。配置 `warmup=3` 也不是 3 次预热成功的证明。自定义 runner 需遵循并记录上述边界；采集器的 `--warmup` 仅声明配置，不会自行执行预热。

本工具的一键入口现在先单独运行 `-c 1 -n N -w 0` 作为预热，再开始日志与 metrics 采集并运行正式 `-c 100 -n 100 -w 0`。因此，单独进程 JSON 的 `raw` 是本工具的预热数据，正式 JSON 的 `raw` 才是正式 100 次样本。配置 `warmup: 0` 禁用独立预热；旧配置缺少该字段时默认 3 次。预热失败时停止正式执行，并保留预热日志与校验错误。

独立预热先使用服务端缓存与资源，但不复用正式进程的客户端连接，不能将其视为与旧版同进程 `-w 3` 完全等价的性能实验。正式采集开始后仍可能观察到预热引发的延迟异步工作；阶段统计需结合正式实例集合过滤。旧报告中的 `unknown_phase` 不会因修改配置自动变为正式样本，也不能简单删掉最早三条记录解决。

完整且声明有效的前后 Prometheus 快照会合并分析到`analysis.json.metrics`。快照覆盖整个采集窗口，不能自动称为正式请求的分布。需要单独检查时可运行：

```sh
node scripts/metrics.mjs /path/to/metrics-before.prom /path/to/metrics-after.prom
```

空记录、缺失和声明拒绝都是结果。分析完成不等于实验有效，仍需检查样本集合、版本、日志缺口和运行环境。父子阶段不相加，不同阶段的整体 P95 不相减；具体边界见 [阶段口径](../scripts/STAGES.md)。

## 5. 获取新数据

填写本地配置后运行 `python3 capture_100.py`，按[一键采集说明](CAPTURE100.md)配置环境。入口先运行配置数量的独立预热，成功后采集正式 `c100 n100 w0` 的日志、metrics 与原始结果。原版二进制配合 CLI、模板独占声明及快照校验即可推定正式实例集合，无需修改 cube-bench；不满足条件时保留归属限制。默认最多发起 103 次创建，不自动清理预热或正式实例。

[高级采集说明](../scripts/README.md#采集日志与-metrics)介绍如何显式配置日志、metrics 与外部工作负载。采集器不部署服务、不选择模板、不生成实验归属证明；外部 runner 负责正确运行负载、记录实例生命周期和清理。分析产物不保证已脱敏，分享前需自行检查。
