#!/usr/bin/env python3
"""Offline entry point for the CubeSandbox v0.7.1 startup analyzers."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
INPUTS = (
    "capture-manifest.json", "owned-sandbox-ids.json",
    "startup-latency/benchmark.raw.json", "startup-latency/benchmark.json",
    "startup-latency/benchmark.summary.json",
    "startup-latency/runner-validation.json",
    "startup-latency/prewarmup.json", "startup-latency/prewarmup.raw.json",
    *tuple("evidence/cubemastercli/" + name for name in (
        "before.stdout", "before.stderr", "before.json", "after.stdout", "after.stderr", "after.json", "ownership.json")),
    # Legacy filenames are accepted as input aliases, never workload requirements.
    "startup-latency/c100n100.raw.json", "startup-latency/c100n100.json",
    "startup-latency/c100n100.summary.json",
)
LOGS = ("cubelet_stat", "shim_stat", "shim_req", "master", "master_stat", "cubelet_req")

# Import the existing analyzers. All of their in-place writes happen in a disposable
# snapshot; no collector, remote client, deployment command, or benchmark is invoked.
DRIVER = r'''
import fs from 'node:fs';
import path from 'node:path';
import { createHash } from 'node:crypto';
import { pathToFileURL } from 'node:url';
const [scripts, capture, output, phaseMapFile] = process.argv.slice(1);
const mod = name => import(pathToFileURL(path.join(scripts, name)).href);
const { loadAndClassify } = await mod('classify_phases.mjs');
const { loadProfile, stageCsv } = await mod('analyze.mjs');
const { writeTimeline } = await mod('timeline.mjs');
const { writePrecision } = await mod('precision.mjs');
const { writePrecisionTimeline } = await mod('precision_timeline.mjs');
const { writeNetworkDetails } = await mod('network_details.mjs');
const { buildRunSummary } = await mod('run_summary.mjs');
const { writeReport } = await mod('render_report.mjs');
const write = (name, value) => fs.writeFileSync(path.join(output, name),
  JSON.stringify(value, null, 2) + '\n', {flag: 'wx', mode: 0o600});
const phaseMap = phaseMapFile ? JSON.parse(fs.readFileSync(phaseMapFile, 'utf8')) : undefined;
const classification = loadAndClassify(capture, {phaseMap});
write('phase-classification.json', classification);
if (phaseMapFile && classification.status !== 'declared') {
  throw new Error('Explicit phase map rejected: ' + classification.errors.join(', '));
}
const options = {};
const conflictingOwnershipIds = classification.conflicting_ownership_ids;
const wrapperWarnings = [];
let ownershipDowngraded = false;
if (classification.status === 'declared') {
  options.phaseClassification = path.join(output, 'phase-classification.json');
  wrapperWarnings.push('Phase map is caller-declared, NOT independently verified against benchmark execution.');
} else {
  wrapperWarnings.push('Phase membership is unverified. Component results remain unknown_phase and are NOT a valid formal-only benchmark distribution.');
  const file = path.join(capture, 'owned-sandbox-ids.json');
  if (fs.existsSync(file)) {
    const original = JSON.parse(fs.readFileSync(file, 'utf8'));
    ownershipDowngraded = !!(original?.formal?.length || original?.warmup?.length);
  }
}
if (conflictingOwnershipIds.length) wrapperWarnings.push(
  'Conflicting ownership IDs excluded from every phase: ' + conflictingOwnershipIds.join(', '));
const profile = loadProfile(capture, options);
profile.warnings.push(...wrapperWarnings);
write('analysis.json', profile);
fs.writeFileSync(path.join(output, 'stage-latency.csv'), stageCsv(profile), {flag: 'wx', mode: 0o600});
const details = ['formal', 'warmup', 'unknown_phase'].flatMap(p => profile.phases[p].create_container_detail.details);
fs.writeFileSync(path.join(output, 'instances.jsonl'), details.map(x => JSON.stringify(x)).join('\n') +
  (details.length ? '\n' : ''), {flag: 'wx', mode: 0o600});
writeTimeline(capture, options);
writePrecision(capture, options);
writePrecisionTimeline(path.join(capture, 'precision.json'));
const generated = ['timeline.json', 'timeline.html', 'precision.json', 'precision.csv', 'precision-timeline.html'];
const manifest = JSON.parse(fs.readFileSync(path.join(capture, 'capture-manifest.json'), 'utf8'));
const selectedInput = names => {
  const name = names.find(name => profile.evidence_integrity.inputs?.[name]?.status === 'read');
  return name ? JSON.parse(fs.readFileSync(path.join(capture, name), 'utf8')) : null;
};
const raw = selectedInput(['startup-latency/benchmark.raw.json', 'startup-latency/benchmark.json',
  'startup-latency/c100n100.raw.json', 'startup-latency/c100n100.json']);
const summary = selectedInput(['startup-latency/benchmark.summary.json', 'startup-latency/c100n100.summary.json']);
const runSummary = buildRunSummary({profile, manifest, raw, summary});
runSummary.synthetic = Boolean(manifest.synthetic || raw?.synthetic);
const validationFile = path.join(capture, 'startup-latency/runner-validation.json');
if (fs.existsSync(validationFile)) {
  try {
    const validation = JSON.parse(fs.readFileSync(validationFile, 'utf8'));
    if (!validation || typeof validation !== 'object' || Array.isArray(validation)) throw new Error('invalid validation');
    runSummary.runner_validation = {status: validation.status, capabilities: validation.capabilities ?? null,
      problems: Array.isArray(validation.problems) ? validation.problems.map(String) : []};
    if (validation.inventory) {
      runSummary.inventory = validation.inventory;
      if (Array.isArray(validation.inventory.limitations)) runSummary.warnings.push(...validation.inventory.limitations.map(x => 'CLI inventory: ' + String(x)));
    }
    if (Array.isArray(validation.warnings)) runSummary.warnings.push(...validation.warnings.map(String));
    if (validation.status === 'limited') runSummary.warnings.push(validation.inventory?.accepted && validation.inventory?.phase === 'formal'
      ? '正式窗口 CLI 差集提供实例集合，仍无客户端 seq 到实例 ID 的逐条映射；正式分组基于模板独占声明。'
      : '实例阶段归属或预热证据不完整；保留客户端计时。CLI 识别的混合集合在 unknown_phase 展示，不能当作正式 100 个实例的分布。');
    if (validation.status === 'invalid') runSummary.warnings.push('Runner 结果校验失败；请检查 benchmark-inputs/runner-validation.json，不能把报告生成成功视为压测有效。');
  } catch {
    runSummary.warnings.push('Runner validation input is invalid; result validation is unavailable.');
  }
}
const prewarmupFile = path.join(capture, 'startup-latency/prewarmup.json');
if (fs.existsSync(prewarmupFile)) {
  try {
    const value = JSON.parse(fs.readFileSync(prewarmupFile, 'utf8'));
    if (!value || value.mode !== 'separate_process' || !Number.isInteger(value.count) || value.count < 0
        || !['complete', 'skipped'].includes(value.status) || value.successful !== value.count
        || !Number.isFinite(value.duration_ms) || value.duration_ms < 0
        || (value.count > 0 && (value.status !== 'complete' || value.benchmark_exit_code !== 0))
        || (value.count === 0 && value.status !== 'skipped')) throw new Error('invalid prewarmup');
    if (value.count > 0) {
      const bytes = fs.readFileSync(path.join(capture, 'startup-latency/prewarmup.raw.json'));
      if (createHash('sha256').update(bytes).digest('hex') !== value.raw_sha256) throw new Error('prewarmup digest mismatch');
      const preRaw = JSON.parse(bytes);
      if (preRaw?.config?.concurrency !== 1 || preRaw.config.total !== value.count || preRaw.config.warmup !== 0
          || preRaw.config.mode !== 'create-only' || preRaw.config.template !== manifest.template_id
          || !Array.isArray(preRaw.raw) || preRaw.raw.length !== value.count
          || preRaw.raw.some(row => !row || row.error || !Number.isFinite(row.create_ms) || row.create_ms < 0)
          || preRaw.raw.map(row => row.seq).sort((a,b) => a-b).some((seq,i) => seq !== i+1)) throw new Error('invalid prewarmup samples');
    }
    runSummary.prewarmup = value;
  } catch {
    runSummary.warnings.push('独立预热元数据无效；预热状态未知，正式计时保持独立。');
  }
}
write('run-summary.json', runSummary);
writeReport(output, runSummary, profile);

const networkLog = path.resolve(capture, manifest.logs?.cubelet_req?.delta_path ?? 'evidence/cubelet_req-delta.log');
if (fs.existsSync(networkLog)) {
  writeNetworkDetails(capture, options);
  generated.push('network-details.json', 'network-details.csv');
} else {
  write('network-details.json', {status: 'unavailable', reason: 'Cubelet request log is missing; no network durations inferred.'});
}
for (const name of generated) fs.copyFileSync(path.join(capture, name), path.join(output, name), fs.constants.COPYFILE_EXCL);
console.log(JSON.stringify({classification_status: classification.status,
  ownership_downgraded_to_unknown: ownershipDowngraded,
  conflicting_ownership_ids: conflictingOwnershipIds, warnings: wrapperWarnings,
  owned_instances: Object.fromEntries(Object.entries(profile.phases).map(([k,v]) => [k,v.owned_instance_count]))}));
'''


def doctor():
    """Return machine-readable runtime checks, without network or service access."""
    python_ok = sys.version_info >= (3, 9)
    node = shutil.which("node")
    node_version = None
    if node:
        try:
            result = subprocess.run([node, "--version"], capture_output=True, text=True, timeout=10)
            if result.returncode == 0:
                node_version = result.stdout.strip()
        except (OSError, subprocess.TimeoutExpired):
            pass
    match = re.fullmatch(r"v(\d+)\.\d+\.\d+(?:[-+].*)?", node_version or "")
    node_ok = bool(match and int(match.group(1)) >= 18)
    return {"status": "ok" if python_ok and node_ok else "unavailable",
            "python": {"version": sys.version.split()[0], "minimum": "3.9", "ok": python_ok},
            "node": {"path": node, "version": node_version, "minimum": "18", "ok": node_ok},
            "scope": "Offline runtime only; does not validate a cluster, capture, or benchmark."}


def sha256_file(file):
    digest = hashlib.sha256()
    with file.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def input_files(capture):
    manifest_file = capture / "capture-manifest.json"
    manifest = json.loads(manifest_file.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict):
        raise ValueError("capture-manifest.json must contain an object")
    names = set(INPUTS)
    logs = manifest.get("logs") or {}
    for kind in LOGS:
        names.add((logs.get(kind) or {}).get("delta_path") or "evidence/{}-delta.log".format(kind))
    for kind, info in (manifest.get("metrics") or {}).items():
        if isinstance(info, dict):
            names.add(info.get("path") or "evidence/metrics-{}.prom".format(kind))
    files = []
    for name in sorted(names):
        relative = Path(name)
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError("Input path must stay inside capture: {}".format(name))
        candidate = capture / relative
        if any(part.is_symlink() for part in [candidate] + list(candidate.parents) if part != capture and capture in part.parents):
            raise ValueError("Symlink inputs are unsupported: {}".format(name))
        if candidate.exists():
            if not candidate.is_file():
                raise ValueError("Expected an input file: {}".format(name))
            files.append((relative, candidate))
    return files


def analyze(capture_arg, output_arg, phase_map_arg=None):
    capture = Path(capture_arg).expanduser().resolve()
    output = Path(output_arg).expanduser().absolute()
    if not capture.is_dir():
        raise ValueError("Capture directory does not exist: {}".format(capture))
    output_resolved = output.resolve()
    if output_resolved == capture or capture in output_resolved.parents:
        raise ValueError("Output must be outside the input capture directory")
    if output.exists() or output.is_symlink():
        raise ValueError("Output already exists; choose a new directory: {}".format(output))
    files = input_files(capture)
    phase_map = Path(phase_map_arg).expanduser().absolute() if phase_map_arg else None
    if phase_map and (phase_map.is_symlink() or not phase_map.is_file()):
        raise ValueError("Phase map must be a regular, non-symlink JSON file")
    runtime = doctor()
    if runtime["status"] != "ok":
        raise ValueError("Python 3.9+ and Node.js 18+ are required; run profiler.py doctor")
    # mkdir's exclusive final component prevents accidental overwrites even if another
    # process creates the requested directory after the earlier existence check.
    output.mkdir(parents=True, mode=0o700)
    receipt = {"schema_version": 1, "status": "running", "offline": True,
               "source_capture": str(capture), "inputs": {}, "runtime": runtime,
               "phase_policy": "No automatic phase inference. An explicit map is caller-declared, never independently verified; without a map all unambiguous owned IDs remain unknown_phase."}
    try:
        with tempfile.TemporaryDirectory(prefix="cubesandbox-profiler-") as temporary:
            snapshot = Path(temporary) / "capture"
            snapshot.mkdir()
            benchmark_inputs = output / "benchmark-inputs"
            benchmark_inputs.mkdir(mode=0o700)
            for relative, source in files:
                target = snapshot / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(source, target)
                if relative.parts[0] == "startup-latency":
                    retained = benchmark_inputs / relative.name
                    shutil.copyfile(target, retained)
                    retained.chmod(0o600)
                if relative.parts[:2] == ("evidence", "cubemastercli"):
                    retained = output / "inventory-evidence" / relative.name
                    retained.parent.mkdir(mode=0o700, exist_ok=True)
                    shutil.copyfile(target, retained)
                    retained.chmod(0o600)
                receipt["inputs"][relative.as_posix()] = {"bytes": target.stat().st_size,
                    "sha256": sha256_file(target)}
            extra = []
            if phase_map:
                copied_map = Path(temporary) / "phase-map.input.json"
                shutil.copyfile(phase_map, copied_map)
                receipt["phase_map_input"] = {"path": str(phase_map), "bytes": copied_map.stat().st_size,
                    "sha256": sha256_file(copied_map)}
                extra = [str(copied_map)]
            result = subprocess.run([runtime["node"]["path"], "--input-type=module", "--eval", DRIVER,
                                     str(ROOT / "scripts"), str(snapshot), str(output)] + extra,
                                    capture_output=True, text=True)
            if result.returncode:
                raise ValueError("Analyzer failed (partial output retained): {}".format(result.stderr.strip()))
            receipt.update(json.loads(result.stdout))
        receipt["status"] = "complete"
        for warning in receipt.get("warnings", []):
            print("WARNING: {}".format(warning), file=sys.stderr)
        receipt["outputs"] = sorted(p.relative_to(output).as_posix() for p in output.rglob("*") if p.is_file())
    except Exception as error:
        receipt["status"] = "failed"
        receipt["error"] = str(error)
        raise
    finally:
        with (output / "analysis-manifest.json").open("x", encoding="utf-8") as stream:
            json.dump(receipt, stream, ensure_ascii=False, indent=2)
            stream.write("\n")
    return {"status": "complete", "output": str(output),
            "classification_status": receipt["classification_status"],
            "owned_instances": receipt["owned_instances"]}


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("doctor", help="Check local Python and Node.js; no network access")
    run = commands.add_parser("analyze", help="Analyze a capture offline into a NEW directory")
    run.add_argument("capture")
    run.add_argument("--output", required=True, help="New directory outside the capture; existing paths are refused")
    run.add_argument("--phase-map", help="Explicit JSON phase map; accepted mappings are declared, never independently verified")
    args = parser.parse_args(argv)
    try:
        if args.command == "doctor":
            result = doctor()
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0 if result["status"] == "ok" else 1
        print(json.dumps(analyze(args.capture, args.output, args.phase_map), ensure_ascii=False, indent=2))
        return 0
    except (ValueError, OSError, TypeError, KeyError) as error:
        print("profiler: {}".format(error), file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
