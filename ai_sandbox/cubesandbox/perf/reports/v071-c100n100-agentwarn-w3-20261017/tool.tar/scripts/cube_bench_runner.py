#!/usr/bin/env python3
"""Run a supplied cube-bench binary or build an ID-observable source copy.

No source tree edits or sandbox cleanup. Only the capture entry point should
invoke main(): it performs real requests using the operator's E2B environment.
"""
from collections import Counter
import copy
from datetime import datetime, timezone
import errno
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys

# Also support invocation as a script from an arbitrary working directory.
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from scripts import cubemaster_inventory as inventory

PATCHES = (
    ("runner.go", "\tSeq      int\n\tCreateMs float64", "\tSeq      int\n\tSandboxID string\n\tCreateMs float64"),
    ("runner.go", '\t\tr.Err = fmt.Sprintf("create json decode: %v", err)\n\t\treturn r\n\t}\n\n\t// DELETE', '\t\tr.Err = fmt.Sprintf("create json decode: %v", err)\n\t\treturn r\n\t}\n\tr.SandboxID = cr.SandboxID\n\n\t// DELETE'),
    ("main.go", '\t\t\t"seq":       r.Seq,\n', '\t\t\t"seq":       r.Seq,\n\t\t\t"sandbox_id": r.SandboxID,\n'),
)
PATCHES += (
    ("main.go", "\telapsed float64\n", "\telapsed float64\n\tWarmupResults []IterResult\n"),
    ("runner.go", "\t\tr := benchOne(client, cfg, 0)\n", "\t\tr := benchOne(client, cfg, 0)\n\t\tcfg.WarmupResults = append(cfg.WarmupResults, r)\n"),
    ("main.go", "\tsuccessRate := 0.0\n", """\twarmupRaw := make([]map[string]interface{}, len(cfg.WarmupResults))
\tfor i, r := range cfg.WarmupResults {
\t\tentry := map[string]interface{}{
\t\t\t"seq": r.Seq, "sandbox_id": r.SandboxID,
\t\t\t"create_ms": r.CreateMs, "delete_ms": r.DeleteMs,
\t\t}
\t\tif r.Err != "" {
\t\t\tentry["error"] = r.Err
\t\t}
\t\twarmupRaw[i] = entry
\t}
\tsuccessRate := 0.0
"""),
    ("main.go", '\t\t"raw":    raw,\n', '\t\t"raw":    raw,\n\t\t"warmup_raw": warmupRaw,\n'),
)
PATCH_DESCRIPTION = (
    "Add IterResult.SandboxID, assign the decoded create response ID after successful JSON decode, "
    "export sandbox_id on each raw result, collect completed RunWarmup results in Config.WarmupResults before formal timing begins, and export a separate warmup_raw array. HTTP requests and timing boundaries are unchanged."
)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    with path.open("x", encoding="utf-8") as stream:
        os.chmod(path, 0o600)
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")


def prepare_benchmark(source: Path, destination: Path) -> Path:
    """Copy a root or cube-bench directory, apply exact observation edits, and build.

    destination must not exist. Source files are never modified. Failed builds
    retain build-info.json and the isolated copy for diagnosis.
    """
    source, destination = Path(source).resolve(), Path(destination).absolute()
    if (source / "examples/cube-bench").is_dir():
        source = source / "examples/cube-bench"
    if not (source / "go.mod").is_file():
        raise ValueError("cube_bench_source_missing_go_mod")
    if destination.exists() or destination.is_symlink():
        raise ValueError("benchmark_destination_already_exists")
    if source == destination or source in destination.parents:
        raise ValueError("benchmark_destination_inside_source")
    files = sorted([*source.glob("*.go"), source / "go.mod", source / "go.sum"])
    if any(not p.is_file() or p.is_symlink() for p in files):
        raise ValueError("benchmark_source_file_missing_or_symlink")
    contents = {p.name: p.read_bytes() for p in files}
    patched = {name: data.decode("utf-8") for name, data in contents.items() if name in {"runner.go", "main.go"}}
    for name, old, new in PATCHES:
        if name not in patched or patched[name].count(old) != 1:
            raise ValueError("unsupported_cube_bench_patch_anchor:" + name)
        patched[name] = patched[name].replace(old, new, 1)
    # Reject a previously instrumented source instead of silently double-patching.
    if "SandboxID" in contents["runner.go"].decode().split("type IterResult struct {", 1)[1].split("}", 1)[0]:
        raise ValueError("cube_bench_already_instrumented")
    destination.mkdir(parents=True, mode=0o700)
    for name, data in contents.items():
        target = destination / name
        target.write_bytes(data)
        target.chmod(0o600)
    for name, value in patched.items():
        (destination / name).write_text(value, encoding="utf-8")
    info = {
        "schema_version": 1,
        "source_files": {name: hashlib.sha256(data).hexdigest() for name, data in sorted(contents.items())},
        "patch": PATCH_DESCRIPTION,
        "patched_files": {name: digest(destination / name) for name in sorted(patched)},
        "build_command": ["go", "build", "-buildvcs=false", "-o", "cube-bench", "."],
        "build_status": "started",
    }
    binary = destination / "cube-bench"
    try:
        subprocess.run(info["build_command"], cwd=destination, check=True, env={**os.environ, "GOWORK": "off"})
        if not binary.is_file() or binary.is_symlink():
            raise ValueError("benchmark_build_did_not_produce_binary")
        info.update(build_status="succeeded", binary_sha256=digest(binary))
    except BaseException:
        info["build_status"] = "failed"
        raise
    finally:
        write_json(destination / "build-info.json", info)
    return binary


def validate_results(value, template, expected_warmup=3):
    """Keep absent optional observation fields distinct from corrupt evidence.

    Stock cube-bench has neither sandbox_id nor warmup_raw. Its formal results
    remain useful, but cannot establish instance ownership or warmup outcomes.
    """
    owned = {"formal": [], "warmup": [], "unknown_phase": []}
    problems, warnings, rows = [], [], []
    config = value.get("config") if isinstance(value, dict) else None
    expected = {"concurrency": 100, "total": 100, "warmup": expected_warmup, "mode": "create-only", "template": template}
    config_ok = isinstance(config, dict) and all(type(config.get(k)) is type(v) and config.get(k) == v for k, v in expected.items())
    if not config_ok:
        problems.append("raw_config_mismatch")
    groups = {}
    warmup_present = isinstance(value, dict) and "warmup_raw" in value
    for phase, field, count in (("formal", "raw", 100), ("warmup", "warmup_raw", expected_warmup)):
        if phase == "warmup" and not warmup_present:
            if expected_warmup:
                warnings.append("warmup_raw_absent: warmup outcomes and instance IDs are unavailable")
            groups[phase] = []
            continue
        samples = value.get(field) if isinstance(value, dict) else None
        if not isinstance(samples, list):
            problems.append(field + "_samples_missing_or_invalid")
            samples = []
        if len(samples) != count:
            problems.append(field + "_sample_count_not_" + str(count))
        groups[phase] = samples
    seq_counts = Counter(r.get("seq") for r in groups["formal"] if isinstance(r, dict) and type(r.get("seq")) is int)
    id_counts = Counter(r.get("sandbox_id") for group in groups.values() for r in group if isinstance(r, dict) and isinstance(r.get("sandbox_id"), str))
    missing_ids = Counter()
    for source_phase, raw in groups.items():
        for index, row in enumerate(raw):
            issues = []
            if not isinstance(row, dict):
                rows.append({"source_phase": source_phase, "index": index, "problems": ["sample_not_object"]})
                continue
            seq, sid = row.get("seq"), row.get("sandbox_id")
            id_present = "sandbox_id" in row
            valid_id = isinstance(sid, str) and re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:-]{0,127}", sid) is not None
            valid_seq = type(seq) is int and (1 <= seq <= 100 if source_phase == "formal" else seq == 0)
            if not valid_seq:
                issues.append("invalid_seq")
            elif source_phase == "formal" and seq_counts[seq] != 1:
                issues.append("duplicate_seq")
            if not id_present:
                missing_ids[source_phase] += 1
            elif not valid_id:
                issues.append("invalid_sandbox_id")
            elif id_counts[sid] != 1:
                issues.append("duplicate_sandbox_id")
            latency = row.get("create_ms")
            if type(latency) not in (int, float) or latency < 0 or (type(latency) is float and not math.isfinite(latency)):
                issues.append("invalid_create_latency")
            if row.get("error"):
                issues.append("benchmark_sample_failed")
            phase = source_phase if config_ok and not issues else "unknown_phase"
            if valid_id and sid not in owned[phase]:
                owned[phase].append(sid)
            rows.append({"source_phase": source_phase, "index": index, "seq": seq, "sandbox_id": sid,
                         "phase": phase if valid_id else None, "problems": issues})
    for phase, count in missing_ids.items():
        warnings.append(f"{phase}_sandbox_ids_absent: {count} samples cannot be attributed to server instances")
    if any(r["problems"] for r in rows):
        problems.append("raw_sample_validation_failed")
    if set(seq_counts) != set(range(1, 101)):
        problems.append("formal_sequence_incomplete")
    formal_ok = config_ok and len(groups["formal"]) == 100 and set(seq_counts) == set(range(1, 101)) and not any(r["problems"] for r in rows if r["source_phase"] == "formal")
    warmup_ok = config_ok and (isinstance(value.get("warmup_raw"), list) if warmup_present else expected_warmup == 0) and len(groups["warmup"]) == expected_warmup and not any(r["problems"] for r in rows if r["source_phase"] == "warmup")
    capabilities = {
        "formal_results": formal_ok,
        "formal_instance_ids": formal_ok and len(owned["formal"]) == 100,
        "warmup_results": warmup_ok,
        "warmup_instance_ids": warmup_ok and len(owned["warmup"]) == expected_warmup,
        "client_sample_mapping": formal_ok and len(owned["formal"]) == 100,
    }
    capabilities["phase_attribution"] = capabilities["formal_instance_ids"] and capabilities["warmup_instance_ids"]
    limitations = []
    if not capabilities["phase_attribution"]:
        limitations.append("Only valid explicitly reported IDs establish declared phase ownership; missing IDs are never inferred from logs or timing.")
    if not warmup_present and expected_warmup:
        limitations.append(f"Configured warmup={expected_warmup} does not prove warmup outcomes; the binary did not export warmup_raw.")
    return owned, {"status": "invalid" if problems else "limited" if warnings else "valid",
                   "problems": problems, "warnings": warnings, "limitations": limitations,
                   "capabilities": capabilities, "rows": rows,
                   "ownership_basis": "declared_from_benchmark_raw_ids_not_independently_verified"}


def main():
    environment = os.environ
    required = ["CUBE_CAPTURE_DIR", "CUBE_CAPTURE_TEMPLATE_ID", "CUBE_CAPTURE_BENCHMARK_BINARY", "CUBE_CAPTURE_OWNED_IDS", "E2B_API_URL", "E2B_API_KEY"]
    if any(not environment.get(key) for key in required):
        print("Missing required runner environment: " + ", ".join(key for key in required if not environment.get(key)), file=sys.stderr)
        return 2
    warmup_text = environment.get("CUBE_CAPTURE_WARMUP", "3")
    if not re.fullmatch(r"(?:0|[1-9][0-9]{0,5})", warmup_text):
        print("Invalid CUBE_CAPTURE_WARMUP: expected a nonnegative integer", file=sys.stderr)
        return 2
    expected_warmup = int(warmup_text)
    capture = Path(environment["CUBE_CAPTURE_DIR"]).absolute()
    output = capture / "startup-latency/benchmark.raw.json"
    ownership = Path(environment["CUBE_CAPTURE_OWNED_IDS"]).absolute()
    validation_path = output.parent / "runner-validation.json"
    if any(path.exists() or path.is_symlink() for path in (output, ownership, validation_path)):
        print("Runner outputs must not already exist", file=sys.stderr)
        return 2
    output.parent.mkdir(parents=True, exist_ok=True, mode=0o700)
    template = environment["CUBE_CAPTURE_TEMPLATE_ID"]
    command = [environment["CUBE_CAPTURE_BENCHMARK_BINARY"], "-c", "100", "-n", "100", "-w", str(expected_warmup), "-m", "create-only", "-no-tui", "-t", template, "-o", str(output)]
    code = 2
    owned = {"formal": [], "warmup": [], "unknown_phase": []}
    validation = {"status": "invalid", "problems": ["benchmark_did_not_finish"]}
    launch_error = None
    raw = None
    inventory_options = None
    inventory_before = None
    inventory_failure = None
    benchmark_attempted = False
    inventory_directory = capture / "evidence/cubemastercli"
    def diagnostic(message):
        # Never echo arguments/environment. Error responses may repeat the API key.
        safe = str(message).replace(environment["E2B_API_KEY"], "[REDACTED]")
        print(" ".join(safe.splitlines()), file=sys.stderr, flush=True)

    started = datetime.now(timezone.utc).isoformat()
    diagnostic(f"Preparing cube-bench: c100 n100 w{expected_warmup}, mode=create-only")
    try:
        if environment.get("CUBE_CAPTURE_CUBEMASTERCLI"):
            inventory_options = json.loads(environment["CUBE_CAPTURE_CUBEMASTERCLI"])
            inventory.validate_options(inventory_options)
            diagnostic("Collecting cubemastercli baseline before starting cube-bench")
            inventory_before = inventory.snapshot(inventory_options, inventory_directory, "before")
            if inventory_before["status"] != "ok":
                inventory_failure = "cubemastercli_before_failed"
                diagnostic("cubemastercli baseline failed; cube-bench was not started. Inspect " + str(inventory_directory / "before.stderr"))
        if inventory_failure is None:
            benchmark_attempted = True
            diagnostic(f"Starting cube-bench: c100 n100 w{expected_warmup}, mode=create-only, -no-tui")
            diagnostic(f"cube-bench JSON output: {output}")
            code = subprocess.run(command, env=dict(environment)).returncode
    except ValueError:
        inventory_failure = "cubemastercli_config_invalid"
        code = 2
        diagnostic("Invalid cubemastercli configuration; cube-bench was not started")
    except KeyboardInterrupt:
        code = 130
    except OSError as error:
        if not benchmark_attempted:
            inventory_failure = "cubemastercli_before_exception"
            code = 2
            diagnostic(f"cubemastercli baseline could not be saved or read: errno={error.errno}; cube-bench was not started")
        else:
            # Do not use str(error): arbitrary exception text can contain arguments.
            message = os.strerror(error.errno) if error.errno is not None else "Operating system could not execute the binary"
            launch_error = {"type": type(error).__name__, "errno": error.errno, "message": message}
            code = 127 if error.errno == errno.ENOENT else 126
            hint = {
                errno.ENOEXEC: "Check CPU architecture and executable format (use a Linux binary on Linux).",
                errno.ENOENT: "Check the binary path and its required dynamic loader or script interpreter.",
                errno.EACCES: "Check executable permissions and whether the filesystem is mounted noexec.",
            }.get(error.errno, "Check the executable and operating system requirements.")
            diagnostic(f"Cannot start cube-bench binary {command[0]}: errno={error.errno}, {message}. {hint}")
    finally:
        ended = datetime.now(timezone.utc).isoformat()
        benchmark_exit_code = code if benchmark_attempted else None
        diagnostic(f"cube-bench finished: exit_code={code}" if benchmark_attempted else "cube-bench was not started")
        if output.is_file() and not output.is_symlink():
            output.chmod(0o600)
            try:
                raw = json.loads(output.read_text(encoding="utf-8"))
                owned, validation = validate_results(raw, template, expected_warmup=expected_warmup)
            except (OSError, ValueError, UnicodeError):
                validation = {"status": "invalid", "problems": ["benchmark_raw_unreadable_or_invalid_json"]}
        else:
            validation = {"status": "invalid", "problems": ["benchmark_raw_missing"]}
        if inventory_options is not None and inventory_before is not None and benchmark_attempted:
            inventory_added_ids = []
            validation_before_inventory = copy.deepcopy(validation)
            owned_before_inventory = copy.deepcopy(owned)
            try:
                diagnostic("Collecting cubemastercli final inventory")
                after = inventory.snapshot(inventory_options, inventory_directory, "after")
                benchmark_valid = not code and validation.get("status") != "invalid" and validation.get("capabilities", {}).get("formal_results", False)
                formal_only = expected_warmup == 0 and benchmark_valid
                cli_owned, cli_evidence = inventory.infer_ownership(
                    inventory_before, after, template, inventory_options.get("exclusive_template", False),
                    expected_count=100 + expected_warmup, formal_only=formal_only)
                if not benchmark_valid:
                    cli_evidence["accepted"] = False
                    cli_evidence["errors"].append("benchmark_validation_blocks_attribution")
                    cli_owned = {"formal": [], "warmup": [], "unknown_phase": []}
                validation["inventory"] = cli_evidence
                validation.setdefault("capabilities", {})["server_instance_ids"] = bool(cli_owned["formal"] or cli_owned["unknown_phase"])
                if after["status"] != "ok":
                    inventory_failure = "cubemastercli_after_failed"
                    diagnostic("cubemastercli final inventory failed; benchmark data retained. Inspect " + str(inventory_directory / "after.stderr"))
                # Raw IDs remain authoritative for declared phases. Inventory never
                # supplies a raw seq join or guesses the first three as warmup.
                raw_ids = {sid for ids in owned.values() for sid in ids}
                candidates = set(cli_owned["formal"] + cli_owned["unknown_phase"])
                if candidates and raw_ids and not raw_ids.issubset(candidates):
                    validation.setdefault("warnings", []).append("cubemastercli_raw_id_conflict: inventory and benchmark IDs disagree; no inventory IDs added")
                    validation["capabilities"]["server_instance_ids"] = False
                    cli_evidence["accepted"] = False
                    cli_evidence["errors"].append("raw_id_conflict")
                elif candidates:
                    inventory_added_ids = sorted(candidates - raw_ids)
                    inventory_phase = "formal" if formal_only else "unknown_phase"
                    owned[inventory_phase].extend(inventory_added_ids)
                    validation["ownership_basis"] = "benchmark_raw_ids_plus_cli_inventory_under_declared_template_exclusivity"
                    if formal_only:
                        validation["capabilities"]["formal_instance_ids"] = len(owned["formal"]) == 100
                        validation["capabilities"]["phase_attribution"] = validation["capabilities"]["formal_instance_ids"]
                        validation["limitations"] = [item for item in validation.get("limitations", [])
                                                     if not item.startswith("Only valid explicitly reported IDs")]
                        validation["limitations"].append("Formal instance set is inferred from exclusive-template inventory difference with cube-bench warmup=0; client seq mapping requires explicit raw IDs.")
                        message = "100 formal run IDs available under declared template exclusivity and validated cube-bench warmup=0"
                    else:
                        message = f"{len(candidates)} run IDs available under declared template exclusivity; inventory-only IDs remain unknown_phase (warmup + formal), without raw seq mapping"
                    validation.setdefault("warnings", []).append("cubemastercli_instance_ids_collected: " + message)
                    # Avoid claiming that server IDs cannot be found: only the join is absent.
                    validation["warnings"] = [w for w in validation["warnings"] if "_sandbox_ids_absent:" not in w]
                    if not validation.get("capabilities", {}).get("client_sample_mapping"):
                        validation["warnings"].append("client_sample_id_mapping_unavailable: CLI inventory does not map client seq to server IDs")
                else:
                    validation.setdefault("warnings", []).append("cubemastercli_candidates_unverified: inspect evidence/cubemastercli/ownership.json; inventory-only candidates were not attributed to this run")
                if validation.get("status") == "valid" and validation.get("warnings"):
                    validation["status"] = "limited"
                write_json(inventory_directory / "ownership.json", cli_evidence)
            except (OSError, ValueError, subprocess.SubprocessError, KeyboardInterrupt) as error:
                inventory_failure = "cubemastercli_after_exception"
                owned = owned_before_inventory
                validation = validation_before_inventory
                validation.setdefault("capabilities", {})["server_instance_ids"] = False
                validation["inventory"] = {"accepted": False, "errors": [inventory_failure], "exception_type": type(error).__name__}
                if isinstance(error, KeyboardInterrupt) and not code:
                    code = 130
                diagnostic("cubemastercli final collection failed; original cube-bench results and exit code are retained")
        if inventory_failure:
            validation.setdefault("problems", []).insert(0, inventory_failure)
            validation["status"] = "invalid"
            code = code or 2
        validation["benchmark_attempted"] = benchmark_attempted
        if launch_error is not None:
            validation["launch_error"] = launch_error
            validation["problems"].insert(0, "benchmark_execution_failed")
        elif benchmark_exit_code:
            validation["problems"].insert(0, "benchmark_exit_nonzero")
        if code:
            validation["status"] = "invalid"
        validation.setdefault("warnings", [])
        validation.setdefault("limitations", [])
        validation.setdefault("capabilities", {name: False for name in (
            "formal_results", "formal_instance_ids", "warmup_results", "warmup_instance_ids", "phase_attribution", "client_sample_mapping")})
        validation.update(benchmark_exit_code=benchmark_exit_code, command_started_at=started, command_ended_at=ended,
                          cleanup="not_performed; inspect ownership IDs before any manual cleanup")
        write_json(ownership, owned)
        write_json(validation_path, validation)
    if validation["status"] == "invalid":
        details = Counter(issue for row in validation.get("rows", []) for issue in row["problems"])
        issues = "; ".join(validation["problems"])
        if details:
            issues += "; " + ", ".join(f"{issue}={count}" for issue, count in sorted(details.items()))
        diagnostic("Benchmark validation failed: " + issues)
        if isinstance(raw, dict):
            examples = 0
            for field in ("raw", "warmup_raw"):
                samples = raw.get(field)
                if not isinstance(samples, list):
                    continue
                for index, row in enumerate(samples):
                    if isinstance(row, dict) and row.get("error") and examples < 3:
                        # Redact before truncation so a long response cannot reveal a key prefix.
                        error = str(row["error"]).replace(environment["E2B_API_KEY"], "[REDACTED]")
                        diagnostic(f"{field}[{index}] error: {error[:500]}")
                        examples += 1
        diagnostic(f"Validation details: {validation_path}")
    if code:
        return code if code > 0 else 128 - code
    if validation["status"] == "limited":
        print("Benchmark completed with limited observation: " + "; ".join(validation["warnings"]), file=sys.stderr)
    return 0 if validation["status"] in {"valid", "limited"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
