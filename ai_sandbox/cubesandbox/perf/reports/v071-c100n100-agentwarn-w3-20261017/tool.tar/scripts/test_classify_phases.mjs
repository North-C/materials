import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { classifyPhases, loadAndClassify } from './classify_phases.mjs';
import { loadProfile } from './analyze.mjs';

const fixture = () => ({manifest: {concurrency: 2, requests: 4, warmup: 1},
  ownership: {formal: [], warmup: [], unknown_phase: ['one', 'two', 'three']}});
const map = () => ({formal: ['two', 'three'], warmup: ['one'], unknown_phase: []});

test('default never infers phase from counts or timing and preserves input', () => {
  const input = fixture(), original = structuredClone(input);
  const result = classifyPhases(input);
  assert.equal(result.status, 'unverified');
  assert.deepEqual(result.ownership, input.ownership);
  assert.deepEqual(input, original);
  assert.equal(result.raw_seq_to_sandbox_mapping, 'unavailable');
});
test('explicit map remains declared, including partial successful populations', () => {
  const input = {...fixture(), phaseMap: map()};
  const result = classifyPhases(input);
  assert.equal(result.status, 'declared');
  assert.deepEqual(result.ownership, input.phaseMap);
  assert.match(result.limitations[0], /not independently verified/);
});
for (const [name, change] of [
  ['foreign id', x => x.phaseMap.formal.push('foreign')],
  ['missing owned id', x => x.phaseMap.formal.pop()],
  ['duplicate within phase', x => x.phaseMap.formal.push('two')],
  ['overlapping phases', x => x.phaseMap.warmup.push('two')],
  ['missing phase array', x => delete x.phaseMap.unknown_phase],
  ['whitespace id', x => x.phaseMap.formal[0] = ' two '],
  ['too many warmups', x => x.manifest.warmup = 0],
  ['invalid workload', x => x.manifest.requests = -1],
]) test(`invalid declaration stays unknown: ${name}`, () => {
  const input = {...fixture(), phaseMap: map()}; change(input);
  const result = classifyPhases(input);
  assert.equal(result.status, 'unverified');
  assert.ok(result.errors.length);
  assert.deepEqual(result.ownership.formal, []);
});
test('existing formal ownership alone does not establish a phase', () => {
  const input = fixture(); input.ownership = map();
  assert.equal(classifyPhases(input).status, 'unverified');
  assert.deepEqual(classifyPhases(input).ownership.formal, []);
});
test('conflicting original IDs are excluded and cannot be rescued by a map', () => {
  const input = fixture(); input.ownership.formal = ['one'];
  const result = classifyPhases(input);
  assert.deepEqual(result.conflicting_ownership_ids, ['one']);
  assert.deepEqual(result.ownership.unknown_phase, ['two', 'three']);
  input.phaseMap = map();
  assert.equal(classifyPhases(input).status, 'unverified');
});
test('missing inputs never establish declared membership', () => {
  assert.equal(classifyPhases({}).status, 'unverified');
  assert.deepEqual(classifyPhases({}).ownership.unknown_phase, []);
});
test('file declaration is bound to current ownership and manifest bytes', () => {
  const root = fs.mkdtempSync(path.join(os.tmpdir(), 'phase-declaration-'));
  try {
    const input = fixture();
    const save = (name, value) => fs.writeFileSync(path.join(root, name), JSON.stringify(value));
    save('capture-manifest.json', input.manifest); save('owned-sandbox-ids.json', input.ownership);
    assert.equal(loadProfile(root).phases.formal.owned_instance_count, 0);
    const declaration = loadAndClassify(root, {phaseMap: map()});
    save('declaration.json', declaration);
    const options = {phaseClassification: path.join(root, 'declaration.json')};
    const profile = loadProfile(root, options);
    assert.equal(profile.phase_attribution_status, 'declared');
    assert.equal(profile.phases.formal.owned_instance_count, 2);
    input.manifest.requests = 5; save('capture-manifest.json', input.manifest);
    assert.throws(() => loadProfile(root, options), /stale/);
  } finally { fs.rmSync(root, {recursive: true, force: true}); }
});
