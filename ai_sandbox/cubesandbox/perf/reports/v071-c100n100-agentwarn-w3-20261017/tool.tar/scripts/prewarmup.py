"""Run serial server warmup before opening any formal capture window."""
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time


def write_private(path, value):
    with path.open("x", encoding="utf-8") as stream:
        os.chmod(path, 0o600)
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write("\n")


def validate_warmup(raw, count, template):
    problems = []
    expected = {"concurrency": 1, "total": count, "warmup": 0,
                "mode": "create-only", "template": template}
    config = raw.get("config") if isinstance(raw, dict) else None
    if not isinstance(config, dict) or any(type(config.get(k)) is not type(v) or config[k] != v
                                           for k, v in expected.items()):
        problems.append("warmup_config_mismatch")
    rows = raw.get("raw") if isinstance(raw, dict) else None
    if not isinstance(rows, list):
        return 0, problems + ["warmup_raw_missing"]
    seqs, successful = [], 0
    for row in rows:
        if not isinstance(row, dict):
            problems.append("warmup_invalid_sample")
            continue
        seq = row.get("seq")
        if type(seq) is int:
            seqs.append(seq)
        latency = row.get("create_ms")
        try:
            valid = type(latency) in (int, float) and latency >= 0 and math.isfinite(latency)
        except OverflowError:
            valid = False
        if row.get("error") or not valid:
            problems.append("warmup_sample_failed_or_invalid")
        else:
            successful += 1
    if len(rows) != count or sorted(seqs) != list(range(1, count + 1)):
        problems.append("warmup_sample_count_or_sequence_mismatch")
    if "warmup_raw" in raw and raw["warmup_raw"] != []:
        problems.append("warmup_unexpected_internal_warmup_samples")
    return successful, sorted(set(problems))


def run_warmup(binary, template, count, directory, environment):
    """Preserve stdout/errors and raw JSON; any failure stops the formal run.

    Uses the operator's binary with c1/n<count>/w0. These rows belong to a
    separate warmup process, never the formal benchmark's raw or timing.
    """
    if type(count) is not int or count < 0:
        raise ValueError("warmup 必须是非负整数。")
    directory = Path(directory)
    directory.mkdir(mode=0o700)
    raw_path = directory / "benchmark.raw.json"
    log_path = directory / "command.log"
    started = datetime.now(timezone.utc).isoformat()
    clock_start = time.monotonic()
    record = {"schema_version": 1, "mode": "separate_process", "count": count,
              "status": "skipped" if count == 0 else "failed", "successful": 0,
              "benchmark_exit_code": None, "started_at": started, "problems": [],
              "binary_sha256": hashlib.sha256(Path(binary).read_bytes()).hexdigest(),
              "capture_scope": "outside_formal_capture", "cleanup": "not_performed",
              "client_connection_reused": False}
    code = 0
    if count:
        command = [str(binary), "-c", "1", "-n", str(count), "-w", "0", "-m", "create-only",
                   "-no-tui", "-t", template, "-o", str(raw_path)]
        print(f"独立预热：串行 {count} 次；JSON：{raw_path}；日志：{log_path}", flush=True)
        secret = environment.get("E2B_API_KEY", "")
        def redact(value):
            return value.replace(secret, "[REDACTED]") if secret else value
        child = None
        with log_path.open("x", encoding="utf-8") as log:
            os.chmod(log_path, 0o600)
            def emit(message):
                message = redact(message)
                log.write(message)
                log.flush()
                print(message, end="", flush=True)
            try:
                child = subprocess.Popen(command, env=dict(environment), stdout=subprocess.PIPE,
                                         stderr=subprocess.STDOUT, text=True, encoding="utf-8", errors="replace")
                for line in child.stdout:
                    emit(line)
                child.stdout.close()
                code = child.wait()
                record["benchmark_exit_code"] = code
            except KeyboardInterrupt:
                if child is not None:
                    child.terminate()
                    try:
                        child.wait(timeout=5)
                    except subprocess.TimeoutExpired:
                        child.kill()
                        child.wait()
                    if child.stdout:
                        child.stdout.close()
                    record["benchmark_exit_code"] = child.returncode
                code = 130
                record["problems"].append("warmup_interrupted")
                emit("预热已中断，正式测试未启动。\n")
            except OSError as error:
                code = 126
                record["problems"].append("warmup_execution_failed")
                emit(f"无法执行预热 cube-bench：errno={error.errno}，{error.strerror}；请检查路径、架构和执行权限。\n")
            emit(f"预热 cube-bench 退出码：{record['benchmark_exit_code']}\n")
            if code:
                record["problems"].append("warmup_exit_nonzero")
            try:
                if raw_path.is_symlink():
                    raise ValueError("warmup_raw_symlink")
                raw_path.chmod(0o600)
                data = raw_path.read_bytes()
                raw = json.loads(data)
                record["raw_sha256"] = hashlib.sha256(data).hexdigest()
                record["successful"], problems = validate_warmup(raw, count, template)
                record["problems"].extend(problems)
                if isinstance(raw, dict) and isinstance(raw.get("raw"), list):
                    for row in [r for r in raw["raw"] if isinstance(r, dict) and r.get("error")][:3]:
                        emit("预热请求错误：" + redact(str(row["error"]))[:500] + "\n")
            except (OSError, ValueError, UnicodeError):
                record["problems"].append("warmup_raw_unreadable_or_invalid")
            if record["problems"]:
                code = code or 2
                emit("预热未通过，正式测试与链路采集未启动：" + "; ".join(record["problems"]) + "\n")
            else:
                record["status"] = "complete"
                emit("预热完成；随后建立正式日志、metrics 与实例清单基线。\n")
    record.update(ended_at=datetime.now(timezone.utc).isoformat(),
                  duration_ms=(time.monotonic() - clock_start) * 1000)
    if count == 0:
        record["duration_ms"] = 0
    write_private(directory / "warmup-manifest.json", record)
    return (code if code >= 0 else 128 - code), record
