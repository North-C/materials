// Whole-run timing is evidence from the runner, never sum/max of request latency.
// Supported runner inputs:
//   Cube-bench v0.7.1: report.summary.total_time_s (seconds), or the summary object.
//   Generic: summary.benchmark_timing.{elapsed_ms,elapsed_s}, or
//            {started_at,ended_at,clock}; clock declares both timestamps share
//            the same runner clock. Timestamps require explicit UTC/offset.
// Collector wall-clock windows: manifest.command.{started_at,ended_at} and
// manifest.{started_at,ended_at}. These windows never fill benchmark timing.
const object = value => value && typeof value === "object" && !Array.isArray(value) ? value : null;
const own = (value, key) => value && Object.hasOwn(value, key);
const number = value => (typeof value === "number" || (typeof value === "string" && value.trim() !== ""))
  && Number.isFinite(Number(value)) && Number(value) >= 0 ? Number(value) : null;
const timestamp = value => {
  if (typeof value !== "string") return null;
  const match = value.match(/^(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})(?:\.(\d+))?(Z|[+-]\d{2}:\d{2})$/);
  if (!match) return null;
  // Date.parse normalizes impossible dates such as February 30; reject them.
  const datePart = match[1].slice(0, 10);
  const calendar = new Date(`${datePart}T00:00:00Z`);
  if (!Number.isFinite(calendar.getTime()) || calendar.toISOString().slice(0, 10) !== datePart) return null;
  const base = Date.parse(`${match[1]}${match[3]}`);
  return Number.isFinite(base) ? base + Number(`0.${match[2] ?? "0"}`) * 1000 : null;
};
const SCOPES = {
  benchmark: "Runner's measured formal workload, excluding warmup under the cube-bench contract. Includes scheduling and result collection; create-delete mode also includes deletion. Generic producers must use this same scope.",
  command: "Collector's external-command wall-clock window; may include warmup, setup, cleanup and console draining. Not the formal benchmark duration.",
  capture: "Collector's entire wall-clock capture window, including surrounding log/metrics collection. Not the formal benchmark duration.",
};
function timing(name, candidates, invalid, warnings) {
  const source = [...new Set([...candidates.map(item => item.source), ...invalid])];
  if (invalid.length) {
    warnings.push(`${name} timing contains invalid or incomplete evidence: ${invalid.join(", ")}.`);
    return { duration_ms: null, status: "invalid", source, scope: SCOPES[name] };
  }
  if (!candidates.length) return { duration_ms: null, status: "missing", source, scope: SCOPES[name] };
  const value = candidates[0].duration_ms;
  // Permit only floating-point conversion noise, not rounded contradictory data.
  const tolerance = Math.max(1e-6, Math.abs(value) * Number.EPSILON * 8);
  if (candidates.some(item => Math.abs(item.duration_ms - value) > tolerance)) {
    warnings.push(`${name} timing sources disagree: ${candidates.map(item => `${item.source}=${item.duration_ms} ms`).join(", ")}.`);
    return { duration_ms: null, status: "conflict", source, scope: SCOPES[name] };
  }
  return { duration_ms: value, status: "available", source, scope: SCOPES[name] };
}
function addDuration(input, key, multiplier, path, candidates, invalid) {
  if (!own(input, key)) return;
  const value = number(input[key]);
  if (value === null || !Number.isFinite(value * multiplier)) invalid.push(`${path}.${key}`);
  else candidates.push({ source: `${path}.${key}`, duration_ms: value * multiplier });
}
function addWindow(input, path, candidates, invalid, requireClock = false) {
  if (!own(input, "started_at") && !own(input, "ended_at")) return;
  const source = `${path}.started_at/ended_at`;
  const start = timestamp(input?.started_at), end = timestamp(input?.ended_at);
  if (start === null || end === null || end < start || (requireClock &&
      (typeof input.clock !== "string" || !input.clock.trim()))) invalid.push(source);
  else candidates.push({ source, duration_ms: end - start });
}
export function buildRunSummary({ profile = {}, manifest = {}, raw = null, summary = null } = {}) {
  profile = object(profile) ?? {};
  manifest = object(manifest) ?? {};
  const warnings = [];
  const summaries = [];
  if (object(raw?.summary)) summaries.push(["raw.summary", raw.summary]);
  if (object(summary?.summary)) summaries.push(["summary.summary", summary.summary]);
  else if (object(summary)) summaries.push(["summary", summary]);
  const candidates = [], invalid = [];
  for (const [path, value] of summaries) {
    addDuration(value, "total_time_s", 1000, path, candidates, invalid);
    if (own(value, "benchmark_timing")) {
      const generic = object(value.benchmark_timing), genericPath = `${path}.benchmark_timing`;
      if (!generic) invalid.push(genericPath);
      else {
        if (!["elapsed_ms", "elapsed_s", "started_at", "ended_at"].some(key => own(generic, key))) invalid.push(genericPath);
        addDuration(generic, "elapsed_ms", 1, genericPath, candidates, invalid);
        addDuration(generic, "elapsed_s", 1000, genericPath, candidates, invalid);
        addWindow(generic, genericPath, candidates, invalid, true);
      }
    }
  }
  const durations = { benchmark: timing("benchmark", candidates, invalid, warnings) };
  for (const [name, input, path] of [["command", manifest.command, "manifest.command"], ["capture", manifest, "manifest"]]) {
    const pairs = [], errors = [];
    addWindow(input, path, pairs, errors);
    durations[name] = timing(name, pairs, errors, warnings);
  }
  if (durations.benchmark.status === "missing") warnings.push("Formal benchmark duration is unavailable: supply runner total_time_s or benchmark_timing; request latency and collector windows cannot substitute for it.");
  if ([durations.command, durations.capture].some(item => item.status === "available")) warnings.push("Command/capture timestamps use collector wall time and can be affected by clock adjustments; they are not monotonic runner timing.");
  const configs = [["manifest", manifest], ["raw.config", object(raw?.config)], ["summary.config", object(summary?.config)]];
  const workload = {};
  for (const field of ["concurrency", "requests", "warmup"]) {
    const values = [];
    let invalidWorkload = false;
    for (const [path, config] of configs) {
      const keys = field === "requests" && path !== "manifest" ? ["total", "requests", "iterations"] : [field];
      for (const key of keys) {
        if (!own(config, key)) continue;
        const n = number(config[key]);
        if (!Number.isInteger(n) || n < (field === "warmup" ? 0 : 1)) {
          warnings.push(`Invalid workload field ${path}.${key}.`);
          invalidWorkload = true;
        } else values.push({ value: n, source: `${path}.${key}` });
      }
    }
    const conflict = values.some(item => item.value !== values[0]?.value);
    if (conflict) warnings.push(`Conflicting workload ${field}: ${values.map(item => `${item.source}=${item.value}`).join(", ")}.`);
    workload[field] = invalidWorkload || conflict ? null : values[0]?.value ?? null;
  }
  const rows = Array.isArray(raw) ? raw : Array.isArray(raw?.raw) ? raw.raw : null;
  const validRows = rows?.filter(row => object(row)) ?? [];
  const successful = validRows.filter(row => !row.error && !row.err && !row.Err);
  if (rows && validRows.length !== rows.length) warnings.push("Raw benchmark contains malformed rows; they count as observed but cannot be classified as successful or failed.");
  const requests = {
    observed: rows ? rows.length : null,
    successful: rows ? successful.length : null,
    errors: rows ? validRows.length - successful.length : null,
    valid_latency: rows ? successful.filter(row => number(row.create_ms) !== null).length : null,
  };
  for (const [path, value] of summaries) {
    for (const field of ["successful", "errors"]) {
      if (!own(value, field)) continue;
      const count = number(value[field]);
      if (!Number.isInteger(count)) warnings.push(`Invalid ${path}.${field}; no request count inferred.`);
      else if (requests[field] !== null && requests[field] !== count) warnings.push(`${path}.${field}=${count} differs from raw ${field}=${requests[field]}; raw counts retained.`);
    }
  }
  return {
    schema_version: 1, durations, workload, requests,
    create_latency_ms: profile.benchmark?.create ?? null,
    warmup: {
      configured: workload.warmup,
      definition: "Warmup is a configured number of serial benchOne iterations before formal timing. It uses the selected mode: create-only creates sandboxes; create-delete also deletes them. The HTTP client is reused by the formal workload.",
      runner_scope: "Official cube-bench excludes warmup from summary.total_time_s and exported raw samples; generic producers must document the same boundary. A configured count is not proof that warmup succeeded.",
      component_scope: "Server logs may contain both warmup and formal instances. Without an explicit ID-to-phase mapping, retain unknown_phase; never remove the first N log records or infer phase from timestamp order.",
    },
    warnings,
    limitations: [
      "Whole-run duration measures concurrent workload completion, not a sum or maximum of individual request latencies.",
      "Timing fields and generic clock declarations are producer-supplied evidence; they do not independently certify workload execution or success.",
      "Request counts describe supplied raw rows; missing raw input remains unknown even when a summary reports totals.",
      "create_latency_ms is the existing profile.benchmark.create distribution of valid successful samples, not whole-run timing.",
    ],
  };
}
