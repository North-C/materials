import importlib.util
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location('cubemaster_inventory', Path(__file__).with_name('cubemaster_inventory.py'))
inv = importlib.util.module_from_spec(spec)
spec.loader.exec_module(inv)


def sample(sid='sandbox-1', template='tpl-test', namespace=''):
    return dict(zip(inv.COLUMNS, (sid, 'running', 'local', '-', '-', 'host-test',
                                  '2026-01-02 03:04:05', '-', template, namespace,
                                  '127.0.0.1', '{"note":"value with spaces"}')))


def table(rows=(), scanned=1, total=1, count=None):
    values = [list(inv.COLUMNS)] + [[r[k] for k in inv.COLUMNS] for r in rows]
    widths = [max(len(row[i]) for row in values) + 4 for i in range(len(inv.COLUMNS))]
    lines = [''.join(cell.ljust(width) for cell, width in zip(row[:-1], widths[:-1])) + row[-1] for row in values]
    return f'NODE_SCOPE    all\nNODES_SCANNED    {scanned}/{total}\nSANDBOX_COUNT    {len(rows) if count is None else count}\n\n' + '\n'.join(lines) + '\n'


class ParserTests(unittest.TestCase):
    def test_dates_empty_namespace_and_json_spaces(self):
        result = inv.parse_output(table([sample()]))
        self.assertEqual(result['status'], 'ok')
        self.assertEqual(result['rows'][0]['namespace'], '')
        self.assertEqual(result['rows'][0]['create_at'], '2026-01-02 03:04:05')
        self.assertEqual(result['rows'][0]['labels'], {'note': 'value with spaces'})

    def test_long_variable_columns_and_unicode(self):
        first = sample('sandbox-' + 'x' * 100, namespace='名称')
        first['labels'] = 'null'
        second = sample('sandbox-2', '', 'other-namespace')
        result = inv.parse_output(table([first, second]))
        self.assertEqual(result['status'], 'ok')
        self.assertEqual(result['rows'][0]['namespace'], '名称')
        self.assertIsNone(result['rows'][0]['labels'])
        self.assertEqual(result['rows'][1]['template_id'], '')

    def test_empty_inventory(self):
        result = inv.parse_output(table(scanned=0, total=0))
        self.assertEqual(result['status'], 'ok')
        self.assertEqual(result['rows'], [])

    def test_reject_missing_summary(self):
        self.assertEqual(inv.parse_output('\n'.join(table([sample()]).splitlines()[4:]) + '\n')['status'], 'error')

    def test_reject_bad_scan_count_and_row_count(self):
        for text in (table([sample()], scanned=1, total=2), table([sample()], scanned=0, total=0),
                     table([sample()], count=2), table([sample(), sample()])):
            with self.subTest(text=text):
                self.assertEqual(inv.parse_output(text)['status'], 'error')

    def test_reject_truncated_output_and_unexpected_text(self):
        text = table([sample()])
        for altered in (text[:-1], text[:-20] + '\n', text + 'error: failed\n', 'error: failed\n' + text,
                        text.replace('NODE_SCOPE    all', 'NODE_SCOPE    1-1'),
                        text.replace('sandbox_id', 'identifier'), text.replace('running', 'nonsense')):
            self.assertEqual(inv.parse_output(altered)['status'], 'error')

    def test_reject_corrupt_fields(self):
        for field, value in (('sandbox_id', 'bad id'), ('create_at', '2026-99-01 00:00:00'),
                             ('labels', '{bad'), ('labels', '["not-an-object"]'), ('host_id', ''),
                             ('backend', 'two words'), ('template_id', 'bad id')):
            row = sample()
            row[field] = value
            with self.subTest(field=field, value=value):
                self.assertEqual(inv.parse_output(table([row]))['status'], 'error')

    def test_invalid_utf8_and_control_characters(self):
        for text in (b'\xff\n', table().replace('NODE_SCOPE', '\x1bNODE_SCOPE'), table().replace('    ', '\t', 1)):
            self.assertEqual(inv.parse_output(text)['status'], 'error')


class SnapshotTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.binary = self.root / 'synthetic-cli'
        self.options = {'binary': str(self.binary), 'address': '127.0.0.1', 'port': 8089}
        self.make_binary('import sys\nsys.stdout.write(' + repr(table([sample()])) + ')\n')

    def make_binary(self, body):
        import sys
        self.binary.write_text('#!' + sys.executable + '\n' + body)
        self.binary.chmod(0o700)

    def test_snapshot_argv_and_permissions(self):
        self.make_binary('import sys\nassert sys.argv[1:] == ' + repr(['--address', '127.0.0.1', '--port', '8089', '--timeout', '15s', 'list', '--all', '--wide']) + '\nsys.stdout.write(' + repr(table([sample()])) + ')\n')
        result = inv.snapshot(self.options, self.root / 'evidence', 'before')
        self.assertEqual(result['status'], 'ok')
        for key in ('stdout_path', 'stderr_path', 'evidence_path'):
            self.assertEqual(Path(result[key]).stat().st_mode & 0o777, 0o600)
        self.assertEqual(Path(result['stdout_path']).read_text(), table([sample()]))
        self.assertEqual(json.loads(Path(result['evidence_path']).read_text()), result)

    def test_stderr_nonzero_and_no_raw_diagnostics(self):
        self.make_binary('import sys\nsys.stdout.write(' + repr(table()) + ')\nsys.stderr.write("secret-test-error")\nsys.exit(2)\n')
        result = inv.snapshot(self.options, self.root / 'evidence', 'before')
        self.assertEqual(result['status'], 'error')
        self.assertIn('inventory_exit_code_2', result['errors'])
        self.assertIn('inventory_stderr_present', result['errors'])
        self.assertNotIn('secret-test-error', json.dumps(result))
        self.assertEqual(Path(result['stderr_path']).read_text(), 'secret-test-error')

    def test_stderr_rejected_even_exit_zero(self):
        self.make_binary('import sys\nsys.stdout.write(' + repr(table()) + ')\nsys.stderr.write("warning")\n')
        self.assertEqual(inv.snapshot(self.options, self.root, 'warn')['status'], 'error')

    def test_timeout_bounded_and_evidence_retained(self):
        self.make_binary('import time\nprint("partial", flush=True)\ntime.sleep(10)\n')
        with patch.object(inv, 'PROCESS_TIMEOUT_SECONDS', 0.15):
            result = inv.snapshot(self.options, self.root, 'slow')
        self.assertIn('inventory_process_timeout', result['errors'])
        self.assertTrue(Path(result['evidence_path']).is_file())

    def test_output_limit(self):
        self.make_binary('import sys\nsys.stdout.write("x"*100000)\n')
        with patch.object(inv, 'MAX_OUTPUT_BYTES', 1024):
            result = inv.snapshot(self.options, self.root, 'large')
        self.assertIn('inventory_output_limit_exceeded', result['errors'])
        self.assertLessEqual(Path(result['stdout_path']).stat().st_size + Path(result['stderr_path']).stat().st_size, 1024)

    def test_no_api_key_in_child_environment(self):
        self.make_binary('import os,sys\nassert "E2B_API_KEY" not in os.environ\nsys.stdout.write(' + repr(table()) + ')\n')
        with patch.dict(os.environ, {'E2B_API_KEY': 'synthetic-secret'}):
            result = inv.snapshot(self.options, self.root, 'environment')
        self.assertEqual(result['status'], 'ok')

    def test_refuse_existing_evidence_and_bad_label(self):
        inv.snapshot(self.options, self.root, 'existing')
        with self.assertRaises(FileExistsError):
            inv.snapshot(self.options, self.root, 'existing')
        with self.assertRaises(ValueError):
            inv.snapshot(self.options, self.root, '../unsafe')

    def test_exec_failure_is_visible(self):
        self.binary.write_text('invalid executable format')
        result = inv.snapshot(self.options, self.root, 'bad-executable')
        self.assertEqual(result['status'], 'error')
        self.assertTrue(any(x.startswith('inventory_exec_error_errno_') for x in result['errors']))

    def test_format_validation_does_not_require_binary_to_exist(self):
        value = inv.validate_options({**self.options, 'binary': '/does/not/exist'})
        self.assertEqual(value['binary'], '/does/not/exist')
        with self.assertRaises(ValueError):
            inv.snapshot(value, self.root, 'missing')

    def test_validate_options(self):
        self.assertFalse(inv.validate_options(self.options)['exclusive_template'])
        for key, value in (('port', True), ('port', '8089'), ('port', 0), ('port', 65536),
                           ('address', 'http://localhost'), ('address', 'localhost --delete'),
                           ('exclusive_template', 'true'), ('binary', 'command-from-path'),
                           ('unknown', 'option')):
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                inv.validate_options({**self.options, key: value})
        self.assertEqual(inv.validate_options({**self.options, 'address': '::1'})['address'], '::1')


class OwnershipTests(unittest.TestCase):
    def setUp(self):
        self.before = inv.parse_output(table())
        self.after = inv.parse_output(table([sample(f'sandbox-{i}') for i in range(103)]))

    def infer(self, **kwargs):
        return inv.infer_ownership(kwargs.get('before', self.before), kwargs.get('after', self.after),
                                   kwargs.get('template_id', 'tpl-test'), kwargs.get('exclusive', True),
                                   kwargs.get('expected_count', 103), formal_only=kwargs.get('formal_only', False))

    def test_exclusive_difference_only_unknown_phase(self):
        owned, evidence = self.infer()
        self.assertEqual(len(owned['unknown_phase']), 103)
        self.assertEqual(owned['formal'], [])
        self.assertEqual(owned['warmup'], [])
        self.assertTrue(evidence['accepted'])
        self.assertFalse(evidence['client_sample_mapping'])

    def test_formal_only_accepts_baseline_warmup_and_new_100(self):
        before = inv.parse_output(table([sample(f'sandbox-{i}') for i in range(3)]))
        owned, evidence = self.infer(before=before, expected_count=100, formal_only=True)
        self.assertEqual(set(owned['formal']), {f'sandbox-{i}' for i in range(3, 103)})
        self.assertEqual(owned['unknown_phase'], [])
        self.assertEqual(evidence['phase'], 'formal')
        self.assertFalse(evidence['client_sample_mapping'])
        self.assertNotIn('warmup_and_formal_not_separated', evidence['limitations'])

    def test_formal_only_guards_fail_closed(self):
        baseline = inv.parse_output(table([sample(f'sandbox-{i}') for i in range(3)]))
        for changes in ({'exclusive': False}, {'expected_count': 103},
                        {'before': inv.parse_output(table([sample('missing')]))},
                        {'after': inv.parse_output(table([sample(f'sandbox-{i}') for i in range(102)]))},
                        {'formal_only': 'true'},
                        {'before': inv.parse_output(table([sample('sandbox-0', 'other'), sample('sandbox-1'), sample('sandbox-2')]))}):
            with self.subTest(changes=changes):
                options = {'before': baseline, 'expected_count': 100, 'formal_only': True, **changes}
                owned, evidence = self.infer(**options)
                self.assertFalse(any(owned.values()))
                self.assertFalse(evidence['accepted'])

    def test_default_shared_mode_retains_candidates_not_ownership(self):
        owned, evidence = self.infer(exclusive=False)
        self.assertFalse(any(owned.values()))
        self.assertEqual(len(evidence['candidate_ids']), 103)
        self.assertFalse(evidence['accepted'])

    def test_nonempty_before_rejected(self):
        owned, evidence = self.infer(before=inv.parse_output(table([sample('previous')])) )
        self.assertFalse(any(owned.values()))
        self.assertIn('inventory_template_not_empty_before', evidence['errors'])

    def test_wrong_count_invalid_snapshot_bad_arguments(self):
        for kwargs in ({'expected_count': 100}, {'after': {'status': 'error', 'rows': []}},
                       {'template_id': ''}, {'exclusive': 'true'}, {'expected_count': True}):
            with self.subTest(kwargs=kwargs):
                owned, evidence = self.infer(**kwargs)
                self.assertFalse(any(owned.values()))
                self.assertFalse(evidence['accepted'])

    def test_other_template_not_inferred_and_preexisting_id_not_reassigned(self):
        before = inv.parse_output(table([sample('old', 'other')]))
        after = inv.parse_output(table([sample('old', 'tpl-test')] + [sample(f'sandbox-{i}') for i in range(103)]))
        owned, evidence = self.infer(before=before, after=after)
        self.assertFalse(evidence['accepted'])
        self.assertIn('inventory_existing_instance_changed_template', evidence['errors'])
        self.assertNotIn('old', owned['unknown_phase'])

    def test_nonrunning_target_rejected(self):
        self.after['rows'][0]['status'] = 'paused'
        self.assertIn('inventory_target_not_all_running', self.infer()[1]['errors'])

    def test_disappeared_instance_or_node_count_change_rejected(self):
        before = inv.parse_output(table([sample('other', 'other')]))
        self.assertFalse(self.infer(before=before)[1]['accepted'])
        before = inv.parse_output(table(scanned=2, total=2))
        self.assertIn('inventory_node_count_changed', self.infer(before=before)[1]['errors'])


if __name__ == '__main__':
    unittest.main()
