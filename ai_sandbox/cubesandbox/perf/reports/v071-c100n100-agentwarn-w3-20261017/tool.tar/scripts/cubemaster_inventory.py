"""Read-only v0.7.1 cubemastercli inventory and conservative ownership evidence.

A template-exclusive before/after difference can identify run instances, but
cannot identify client sample order. A validated warmup=0 invocation can identify
the formal instance set; mixed warmup/formal invocations remain unknown_phase.
Raw CLI output is private evidence; diagnostics never echo its contents.
"""
from datetime import datetime, timezone
import ipaddress
import json
import os
from pathlib import Path
import re
import selectors
import signal
import subprocess
import time

MAX_OUTPUT_BYTES = 16 * 1024 * 1024
PROCESS_TIMEOUT_SECONDS = 30
COLUMNS = ('sandbox_id', 'status', 'backend', 'remote', 'pause_snap', 'host_id',
           'create_at', 'pause_at', 'template_id', 'namespace', 'host_ip', 'labels')
IDENTIFIER = re.compile(r'[A-Za-z0-9][A-Za-z0-9._:-]{0,127}')


def validate_options(options):
    """Return normalized options; reject malformed values before any subprocess."""
    if not isinstance(options, dict):
        raise ValueError('cubemastercli_options_not_object')
    if set(options) - {'binary', 'address', 'port', 'exclusive_template'}:
        raise ValueError('cubemastercli_unknown_option')
    binary = options.get('binary')
    if not isinstance(binary, str) or not binary or '\x00' in binary:
        raise ValueError('cubemastercli_binary_invalid')
    if '/' not in binary:
        raise ValueError('cubemastercli_binary_must_be_path')
    resolved = Path(binary).expanduser().resolve()
    address = options.get('address', '127.0.0.1')
    if not isinstance(address, str) or not address:
        raise ValueError('cubemastercli_address_invalid')
    try:
        ipaddress.ip_address(address)
    except ValueError:
        if len(address) > 253 or any(not re.fullmatch(r'[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?', s)
                                     for s in address.split('.')):
            raise ValueError('cubemastercli_address_invalid') from None
    port = options.get('port', 8089)
    if type(port) is not int or not 1 <= port <= 65535:
        raise ValueError('cubemastercli_port_invalid')
    exclusive = options.get('exclusive_template', False)
    if type(exclusive) is not bool:
        raise ValueError('cubemastercli_exclusive_template_not_boolean')
    return {'binary': str(Path(resolved).resolve()), 'address': address,
            'port': port, 'exclusive_template': exclusive}


def parse_output(stdout):
    """Parse tabwriter column positions, preserving empty cells and date spaces."""
    result = {'status': 'error', 'rows': [], 'errors': [], 'summary': None}
    def fail(code):
        result['errors'].append(code)
        return result
    try:
        text = stdout.decode('utf-8') if isinstance(stdout, bytes) else stdout
    except UnicodeDecodeError:
        return fail('inventory_invalid_utf8')
    if not isinstance(text, str) or not text.endswith('\n'):
        return fail('inventory_incomplete_output')
    if any(ord(char) < 32 and char != '\n' for char in text):
        return fail('inventory_unexpected_control_character')
    lines = text.splitlines()
    if len(lines) < 5:
        return fail('inventory_summary_or_header_missing')
    patterns = (r'NODE_SCOPE +all *', r'NODES_SCANNED +(\d{1,9})/(\d{1,9}) *', r'SANDBOX_COUNT +(\d{1,9}) *')
    matches = [re.fullmatch(pattern, line) for pattern, line in zip(patterns, lines[:3])]
    if not all(matches) or lines[3].strip():
        return fail('inventory_summary_invalid')
    scanned, total = map(int, matches[1].groups())
    count = int(matches[2].group(1))
    result['summary'] = {'node_scope': 'all', 'nodes_scanned': scanned,
                         'nodes_total': total, 'sandbox_count': count, 'reported_scan_complete': scanned == total}
    if scanned != total or (count > 0 and scanned == 0):
        return fail('inventory_node_scan_incomplete')
    header = lines[4]
    tokens = list(re.finditer(r'\S+', header))
    if tuple(match.group() for match in tokens) != COLUMNS or tokens[0].start() != 0:
        return fail('inventory_wide_header_invalid')
    starts = [match.start() for match in tokens]
    seen = set()
    for line in lines[5:]:
        if len(line) <= starts[-1]:
            return fail('inventory_row_truncated')
        row = {}
        for i, name in enumerate(COLUMNS):
            end = starts[i + 1] if i + 1 < len(starts) else len(line)
            cell = line[starts[i]:end]
            if i + 1 < len(starts) and not cell.endswith(' '):
                return fail('inventory_column_alignment_invalid')
            row[name] = cell.strip()
        sid = row['sandbox_id']
        if not IDENTIFIER.fullmatch(sid) or not row['host_id']:
            return fail('inventory_row_identifier_invalid')
        if sid in seen:
            return fail('inventory_duplicate_sandbox_id')
        seen.add(sid)
        if not re.fullmatch(r'(?:created|running|exited|unknown|pausing|paused)(?:\([a-z_]+\))?', row['status']):
            return fail('inventory_status_invalid')
        if any(not row[name] or re.search(r'\s', row[name]) for name in ('backend', 'remote', 'pause_snap', 'host_id')):
            return fail('inventory_row_invalid')
        for name in ('create_at', 'pause_at'):
            if row[name] != '-':
                try:
                    datetime.strptime(row[name], '%Y-%m-%d %H:%M:%S')
                except ValueError:
                    return fail('inventory_timestamp_invalid')
        if row['template_id'] and not IDENTIFIER.fullmatch(row['template_id']):
            return fail('inventory_template_id_invalid')
        try:
            row['labels'] = json.loads(row['labels'])
        except (ValueError, TypeError, RecursionError):
            return fail('inventory_labels_invalid')
        if row['labels'] is not None and not isinstance(row['labels'], dict):
            return fail('inventory_labels_invalid')
        result['rows'].append(row)
    if len(result['rows']) != count:
        return fail('inventory_row_count_mismatch')
    result['status'] = 'ok'
    return result


def _private_file(path):
    return os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), 'wb')


def snapshot(options, directory, label):
    """Run only list --all --wide, retaining bounded stdout/stderr and JSON."""
    options = validate_options(options)
    if not isinstance(label, str) or not re.fullmatch(r'[A-Za-z0-9_-]{1,64}', label):
        raise ValueError('inventory_label_invalid')
    if not Path(options['binary']).is_file() or not os.access(options['binary'], os.X_OK):
        raise ValueError('cubemastercli_binary_not_executable')
    directory = Path(directory).resolve()
    directory.mkdir(parents=True, exist_ok=True, mode=0o700)
    paths = {name: str(directory / (label + suffix)) for name, suffix in
             (('stdout_path', '.stdout'), ('stderr_path', '.stderr'), ('evidence_path', '.json'))}
    argv = [options['binary'], '--address', options['address'], '--port', str(options['port']),
            '--timeout', '15s', 'list', '--all', '--wide']
    started = datetime.now(timezone.utc).isoformat()
    errors, output, size, code = [], bytearray(), 0, None
    # API credentials are irrelevant to this CLI and must not be inherited.
    env = {k: v for k, v in os.environ.items() if not any(part in k.upper() for part in ('API_KEY', 'TOKEN', 'SECRET', 'PASSWORD'))}
    with _private_file(paths['stdout_path']) as out, _private_file(paths['stderr_path']) as err:
        process = None
        try:
            process = subprocess.Popen(argv, stdin=subprocess.DEVNULL, stdout=subprocess.PIPE,
                                       stderr=subprocess.PIPE, env=env, start_new_session=True)
            deadline = time.monotonic() + PROCESS_TIMEOUT_SECONDS
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ, (out, True))
                selector.register(process.stderr, selectors.EVENT_READ, (err, False))
                while selector.get_map():
                    remaining = deadline - time.monotonic()
                    if remaining <= 0:
                        errors.append('inventory_process_timeout')
                        break
                    for key, _ in selector.select(min(remaining, 0.1)):
                        data = os.read(key.fileobj.fileno(), 65536)
                        if not data:
                            selector.unregister(key.fileobj)
                            continue
                        keep = data[:max(0, MAX_OUTPUT_BYTES - size)]
                        stream, is_stdout = key.data
                        stream.write(keep)
                        stream.flush()
                        if is_stdout:
                            output.extend(keep)
                        size += len(data)
                        if size > MAX_OUTPUT_BYTES:
                            errors.append('inventory_output_limit_exceeded')
                            break
                    if errors:
                        break
            if errors:
                os.killpg(process.pid, signal.SIGKILL)
            try:
                code = process.wait(timeout=max(0.01, deadline - time.monotonic()))
            except subprocess.TimeoutExpired:
                errors.append('inventory_process_timeout')
                os.killpg(process.pid, signal.SIGKILL)
                code = process.wait(timeout=5)
        except OSError as exc:
            errors.append('inventory_exec_error_errno_' + str(exc.errno))
        finally:
            if process is not None:
                if process.poll() is None:
                    os.killpg(process.pid, signal.SIGKILL)
                    process.wait(timeout=5)
                process.stdout.close()
                process.stderr.close()
    if code != 0 and code is not None:
        errors.append('inventory_exit_code_' + str(code))
    # A successful CLI normally emits no stderr; do not accept partial results
    # accompanied by warnings/errors whose meaning cannot be proven here.
    if Path(paths['stderr_path']).stat().st_size:
        errors.append('inventory_stderr_present')
    result = parse_output(bytes(output))
    result['errors'] = errors + result['errors']
    if result['errors']:
        result['status'] = 'error'
    result['limitations'] = ['healthy_nodes_inventory_only', 'node_query_failures_may_be_omitted_despite_complete_reported_scan']
    result.update(paths, argv=argv, exit_code=code, started_at=started,
                  finished_at=datetime.now(timezone.utc).isoformat(), output_bytes=size)
    with _private_file(paths['evidence_path']) as stream:
        stream.write((json.dumps(result, ensure_ascii=False, indent=2) + '\n').encode())
    return result


def infer_ownership(before, after, template_id, exclusive_template, expected_count=103, formal_only=False):
    """Infer an exclusive run set, never a per-client mapping.

    formal_only is a caller assertion requiring successful benchmark validation
    with warmup=0. Its baseline may contain the separately completed warmup.
    """
    ownership = {'formal': [], 'warmup': [], 'unknown_phase': []}
    evidence = {'source': 'cubemastercli_before_after', 'candidate_ids': [],
                'accepted': False, 'errors': [], 'phase': 'formal' if formal_only is True else 'unknown_phase',
                'expected_count': expected_count, 'exclusive_template': exclusive_template,
                'client_sample_mapping': False}
    if not isinstance(template_id, str) or not IDENTIFIER.fullmatch(template_id):
        evidence['errors'].append('inventory_template_id_invalid')
    if type(exclusive_template) is not bool:
        evidence['errors'].append('inventory_exclusive_template_not_boolean')
    if type(formal_only) is not bool:
        evidence['errors'].append('inventory_formal_only_not_boolean')
    if formal_only is True and expected_count != 100:
        evidence['errors'].append('inventory_formal_count_not_100')
    if type(expected_count) is not int or expected_count <= 0:
        evidence['errors'].append('inventory_expected_count_invalid')
    for name, snap in (('before', before), ('after', after)):
        if not isinstance(snap, dict) or snap.get('status') != 'ok' or snap.get('errors') or not isinstance(snap.get('rows'), list):
            evidence['errors'].append('inventory_' + name + '_invalid')
    if evidence['errors']:
        return ownership, evidence
    before_ids = {row['sandbox_id'] for row in before['rows']}
    after_ids = {row['sandbox_id'] for row in after['rows']}
    if not before_ids.issubset(after_ids):
        evidence['errors'].append('inventory_previous_instances_disappeared')
    after_by_id = {row['sandbox_id']: row for row in after['rows']}
    if any(any(row.get(field) != after_by_id[row['sandbox_id']].get(field)
                   for field in ('template_id', 'host_id'))
           for row in before['rows'] if row['sandbox_id'] in after_by_id):
        evidence['errors'].append('inventory_previous_instance_identity_changed')
    for field in ('nodes_scanned', 'nodes_total'):
        if before.get('summary', {}).get(field) != after.get('summary', {}).get(field):
            evidence['errors'].append('inventory_node_count_changed')
            break
    before_target = {row['sandbox_id'] for row in before['rows'] if row['template_id'] == template_id}
    after_target = {row['sandbox_id'] for row in after['rows'] if row['template_id'] == template_id}
    evidence['candidate_ids'] = sorted(after_target - before_ids)
    evidence['before_template_count'] = len(before_target)
    if any(row['status'] != 'running' for row in after['rows'] if row['template_id'] == template_id):
        evidence['errors'].append('inventory_target_not_all_running')
    if after_target & before_ids - before_target:
        evidence['errors'].append('inventory_existing_instance_changed_template')
    if not exclusive_template:
        evidence['errors'].append('inventory_template_exclusivity_not_asserted')
    if before_target and not formal_only:
        evidence['errors'].append('inventory_template_not_empty_before')
    if len(evidence['candidate_ids']) != expected_count:
        evidence['errors'].append('inventory_candidate_count_mismatch')
    if not evidence['errors']:
        evidence['accepted'] = True
        evidence['limitations'] = ['operator_asserted_template_exclusivity',
                                  'healthy_nodes_inventory_only', 'node_query_failures_may_be_omitted_despite_complete_reported_scan',
                                  'ownership_inferred_not_independently_verified',
                                  'client_samples_not_mapped_to_instances']
        if formal_only:
            evidence['limitations'].append('formal_only_requires_validated_warmup_zero_benchmark')
        else:
            evidence['limitations'].append('warmup_and_formal_not_separated')
        ownership[evidence['phase']] = evidence['candidate_ids'].copy()
    return ownership, evidence
