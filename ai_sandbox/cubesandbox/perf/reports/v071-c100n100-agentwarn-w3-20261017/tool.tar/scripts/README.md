# 脚本说明

本目录包含 CubeSandbox v0.7.1 Template 启动分析器、采集器与可选观测补丁。固定 100 并发采集推荐直接在 Linux 目标节点运行 `python3 capture_100.py`，详见[一键采集说明](../docs/CAPTURE100.md)。已有数据使用[离线入口](../docs/QUICKSTART.md)；计时语义见[阶段口径与整体关系图](STAGES.md#各阶段整体关系)。

## 文件

| 文件 | 作用 |
| --- | --- |
| `capture.py` | 在外部工作负载前后采集显式配置的日志增量、metrics 和可选 Linux 宿主采样；保留截断、轮转、超限等缺口 |
| `classify_phases.mjs` | 管理未知归属或显式用户分组声明，不从固定数量或日志顺序自动推断 formal/warmup |
| `analyze.mjs` | 阶段统计、覆盖率、结果状态、实例明细与同实例残差 |
| `run_summary.mjs` / `render_report.mjs` | 整轮计时证据、请求分布，以及 HTML/Markdown 报告 |
| `metrics.mjs` | Prometheus 前后差分、重置检测和 histogram 桶分位估计 |
| `timeline.mjs` | 有明确边界证据的局部时间轴，支持离线 HTML |
| `network_details.mjs` | 解析网络 Go duration，保留 ns 单位、覆盖与零值语义 |
| `precision.mjs` / `precision_timeline.mjs` | 可选精细计时数据与分时钟时间轴，回填 duration 仅列数值 |
| `observation.patch` | 面向固定 v0.7.1 源码的可选观测补丁，默认关闭，需自行构建部署 |

## 采集日志与 metrics

本节是自定义负载和日志映射的高级入口。根目录的 `capture_100.py` 已将独立预热、正式 `c100 n100 w0 create-only`、日志增量、可选 metrics、实例归属和自动分析串在一起，先复制并填写 `examples/capture100.config.json` 到仓库根目录的 `capture100.local.json`，之后直接运行 `python3 capture_100.py` 即可复用，不再询问参数。配置字段说明见[一键采集说明](../docs/CAPTURE100.md#开始采集)。

先用独立 cube-bench 进程串行预热（配置 `warmup`，默认 3、0 禁用），成功后才开始日志与 metrics 采集、获取 CLI 基线，再以并发上限 100 执行正式 100 次创建。正式整轮计时排除独立预热；不同进程不复用客户端连接，不与原单进程 `-w 3` 视为相同实验。默认直接使用用户提供的二进制，在本地配置中填写 `benchmark_binary` 路径及 API、模板、密钥和日志等字段即可，无需 Go 或源码；`--benchmark-binary` 可覆盖本轮程序路径。工具记录二进制哈希，无需用户填写。

普通官方 v0.7.1 二进制缺少实例 ID，但结合 `cubemastercli` 在独立预热后的基线、模板独占声明及严格快照校验，可将正式窗口新增的 100 个实例推定为 formal 群体；客户端 seq 与实例 ID 仍不能逐条对应。不满足条件时保留未知归属。独立预热结果另外保存，不要求二进制支持 `warmup_raw`。配置中的 `source` 构建模式继续支持，仅该模式需要 Go，会在源码副本中补充导出并构建，不修改原源码。默认最多发起 103 次创建；配置 `warmup: N` 时为 `100 + N` 次，预热和正式实例均不自动清理。

底层采集器运行在 Linux 目标节点，要求有权读取所选日志、执行所选命令；可选宿主采样依赖`/proc`。底层入口没有默认机器地址、部署目录、metrics 端点、二进制哈希或压测规模。

先查看当前参数：

```sh
python3 scripts/capture.py --help
```

下面是**需按你的环境替换的配置示例**，其中路径、模板、哈希及工作负载命令都是占位值：

```sh
python3 scripts/capture.py \
  --output /path/to/new-capture \
  --benchmark-binary /path/to/cube-bench \
  --benchmark-sha256 YOUR_VERIFIED_64_HEX_SHA256 \
  --concurrency 16 --requests 32 --warmup 2 \
  --template-id YOUR_TEMPLATE_ID \
  --log cubelet_req=/path/to/cubelet-request.log \
  --log cubelet_stat=/path/to/cubelet-stat.log \
  --log shim_req=/path/to/shim-request.log \
  --log shim_stat=/path/to/shim-stat.log \
  --log master=/path/to/master-request.log \
  --owned-ids /path/to/new-capture/ownership-input.json \
  -- python3 /path/to/your-benchmark-runner.py
```

输出目录必须不存在，父目录须已创建。`--log`可重复使用，支持`cubelet_req`、`cubelet_stat`、`shim_req`、`shim_stat`、`vmm`、`master`、`master_stat`、`api`；也可显式用`--api-log-dir`选择目录中的最近 API 日志。只提供实际可读的日志，保留缺少阶段的限制。

可选 `--stream-output` 实时向终端 stderr 转发外部命令输出（遮蔽当前已知 API key），原始输出仍保存到私有的 `evidence/command.log`。根目录快捷入口默认开启；低层采集器默认关闭。

可选`--metrics-url`指定 HTTP(S) Prometheus 端点；省略时不发起 metrics HTTP 请求。`--sample-host`开启宿主采样。`--preflight-only`只检查二进制及日志起始状态，不执行外部命令或访问 metrics，但仍需用新的输出目录。二进制 SHA-256 由使用者独立确认，工具检查文件是否一致，不证明被测服务版本。

### 外部 runner 的职责

`--`之后的命令由使用者提供，不会自动转换成固定 cube-bench 命令。采集器传入这些环境变量：

- `CUBE_CAPTURE_DIR`：本轮输出目录。
- `CUBE_CAPTURE_TEMPLATE_ID`：显式配置的模板 ID。
- `CUBE_CAPTURE_BENCHMARK_BINARY`：已检查哈希的压测二进制路径。
- `CUBE_CAPTURE_OWNED_IDS`：传入`--owned-ids`时，对应的归属输出路径。

runner 应按配置的并发、请求数与预热数执行工作负载，将客户端原始结果保存到`$CUBE_CAPTURE_DIR/startup-latency/benchmark.raw.json`，可选摘要保存为`benchmark.summary.json`，并生成或更新归属输入文件。归属文件使用`formal`、`warmup`、`unknown_phase`三个 ID 数组；源文件不能与归一化输出`owned-sandbox-ids.json`重名。归属缺失、过期或格式错误都会被记录。

runner 应保留官方 `summary.total_time_s` 或提供明确的 `benchmark_timing`，否则报告的整轮耗时为 missing。完整输入约定见[整轮耗时与 warmup](../docs/QUICKSTART.md#整轮耗时与-warmup)。采集器的并发、请求数和预热数参数仅记录配置，不会替 runner 执行这些操作。

采集器不验证 runner 实际调用了指定二进制，不替代服务身份检查、静默窗口、模板资源验证或清理。runner 负责实例生命周期、错误处理和必要清理；不得清理无法证明属于本轮的实例。离线分析默认将 owned ID 归为 unknown，只有显式`--phase-map`才采用用户声明分组，详见[快速上手](../docs/QUICKSTART.md#3-分析与可选分组声明)。

## 分析与验证

```sh
python3 profiler.py analyze /path/to/capture --output /path/to/new-analysis
```

根入口把底层分析器的文件写入限制在临时副本中，原输入不变。直接运行底层 Node 脚本可能向输入目录写派生文件，应先制作副本；通常使用根入口即可。

离线测试不连接部署，也不将合成数据当作实测结果：

```sh
python3 -m unittest discover -s scripts -p 'test_*.py' -q
node --test scripts/test_*.mjs
```

## 可选精细观测

`observation.patch`针对 [v0.7.1 固定源码](https://github.com/TencentCloud/CubeSandbox/tree/31d911e430fdf8a8879bd062b8e78066c1a8e89d)，通过`CUBE_PERF_TRACE=1`开启，默认关闭。应用前核对源码，构建部署由使用者负责；必须核实实际进程使用的二进制和环境，不能仅凭磁盘文件名认定生效。

Cubelet span 与 Shim 计时按独立时钟展示，duration_backfill 没有精确起止；累计点仅在同一次调用内唯一且递增时做差。即使丢弃计数为零，也需检查完整覆盖和源日志缺口。对照观测开关开销时，应使用同一套重编译二进制并重复实验。本仓库不附真实观测版性能结果。
