# v0.7.1 Template 启动阶段口径

源码基准为 `v0.7.1`，commit `31d911e430fdf8a8879bd062b8e78066c1a8e89d`。本文以该 tag 的启动源码为准；修改版本需要重新核对计时边界。所有链接固定到上述 commit，避免后续主分支移动。

这些数据可以给出启动调用树、主要耗时分布和部分真实时间窗口，不能拼成各段互斥、总和恰好等于客户端延迟的完整瀑布图。尤其要区分持续时间、累计时间、并行子任务、传播副本和派生残差。

## 各阶段整体关系

### 简版：启动阶段一眼看懂

```text
阶段 / 覆盖关系           | 大致先后 →（非耗时比例）
API create_ms            |[=========================================================================]
Master cube-e2e          |  [=====================================================================]
cubebox-service          |     [==========================================================]
  prepare groups         |      [==========]
  cgroup                 |                   [====]
  cubebox                |                          [===================================]
    sandbox-start        |                             [===================]
      sandbox-create     |                             [===============]
        CreatePodSandbox |                              [=============]
          VM / Agent     |                               [===]
          ResetVm        |                                    [=]
          Guest create   |                                       [===]
    sandbox-probe        |                                                   [====]
Master post              |                                                                  [====]
```

从上到下看包含关系，从左到右看大致先后。`sandbox-start` 与 `sandbox-create` 同起点，前者结束更晚；probe 在 start 之后。**条长不代表实测耗时，父子项不能重复相加，也不能跨进程直接相减。**

- `prepare groups`：两组依次推进，组内并行并等待；network、storage 等位于第二组。
- `VM / Agent`：VMM 启动、VM 恢复和 Agent 连接；随后是 `ResetVm`、Guest sandbox/container 创建。
- `Master post`：Redis 与 spec 持久化并行，等待完成后返回。异步日志、事件转发和部分 cgroup 更新未画入主链。

图中省略了部分准备和收尾；`cubebox` 包含 probe 后的状态保存、宿主限额等工作。准确计时边界仍以下文定义为准。

### 完整版：阶段包含、并行与异步关系

下图用嵌套方框概括**单容器、Template 恢复启动**的主要阶段。外框包含内框；同层按先上后下、同排从左到右的阅读顺序展示主要阶段。并行任务在框内标注，异步工作单列在底部。**框的大小不表示时延**，也不表示各阶段已经对齐到同一时钟。

![v0.7.1 Template 启动阶段整体关系](diagrams/template-startup-stages.svg)

[放大查看 SVG](diagrams/template-startup-stages.svg)

重点看三层关系：Master 等待 Cubelet 完成，再等待并行后处理；Cubelet 在准备工作各组完成后，依次进入 cgroup 与 cubebox；cubebox 中的 `sandbox-start` 包含 `sandbox-create`，后者又包含 Shim 的 `CreatePodSandbox`。**父子阶段不可重复相加，组内并行阶段也不能相加作为该组壁钟耗时。** 各框还包含未展开的准备、锁等待和收尾，详细边界见下表。

| 关系 | 应如何理解 |
| --- | --- |
| Master 入队调度 → Cubelet → 后处理 | handler 即使通过worker异步执行，请求仍在`Wait()`等待结果；不是请求提前成功返回 |
| workflow 并行组 | `[createid, appsnapshot]`内并行；下一组`images/volume/storage/network/netfile/store`内并行。各组等待完成后才进入`cgroup`、`cubebox` |
| storage内部并行 | 卷准备与restore memory预取并行，等待完成后保存metadata；仍包含于`storage`窗口 |
| Master后处理并行 | Redis映射写入与sandbox spec持久化并行，调用端等待两项结束；不是返回后再异步落库 |
| `sandbox-start` ⊃ `sandbox-create` | 同一个`taskStart`起点；NewTask返回只结束create窗口，随后注册Wait、调用Start并更新状态才结束start窗口。这里的Wait是注册退出通知，不阻塞直到容器退出 |
| `sandbox-create` ⊃ Shim `CreatePodSandbox` | NewTask还包括containerd、Shim启动/IPC等外围工作；不能把NewTask与Shim父阶段相加 |
| Shim父阶段与VM/Guest子阶段 | `CreatePodSandbox`包含LaunchVmm、restore准备、RestoreVm、Agent连接、ResetVm、CreateSandbox、CreateContainer及其他工作；`start vm start → agent ready`窗口结束在ResetVm之前 |
| cgroup同步与异步工作 | workflow `cgroup`准备资源组和归属；后续`cubebox`还设置宿主限额（`cube-inner-cgroup`），并按配置异步加入Shim PID、更新VM CPU资源。不能把全部cgroup操作塞进同一个指标 |
| 统计与事件支线 | Cubelet `reportTrace`、Master `dealMetric`及事件后台转发不等待完成；日志落盘时间不是业务阶段结束时间 |
| probe传播与派生残差 | Master probe是Cubelet probe的传播值；`cubebox-service-inner`、`cubebox-inner`等是公式派生值，不是图上额外执行节点，不重复累计 |

原版 v0.7.1 的 `ResetVm` 采用**串行路径**：时间 RPC → RNG 生成 → reseed RPC。修改版本可能改变这些关系，应依据实际源码核对，不混用计时口径。

实际工作流须核对部署配置。本页下方列出各计时边界和固定版本源码；异步cgroup操作另见[发起位置](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/cube_container_create.go#L454)、[CPU更新goroutine](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/cube_container_create.go#L1267)，事件入队见[tx_event](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/service/task_srv.rs#L314)。

## 客户端与 Master

| 指标/事件 | 精确边界与解释 | 源码 |
| --- | --- | --- |
| `benchmark.create` / `create_ms` | `time.Now()` 在构造 HTTP 请求之前；在 `client.Do(req)` 返回后计时。通常截止收到响应头，不包含后续 `ReadAll`、JSON 解码。失败判定发生在这些后续步骤，所以成功样本仍要求响应体处理成功。 | [cube-bench HTTP计时](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/examples/cube-bench/runner.go#L25) |
| CubeAPI | handler 调用 service；service 构造 Master 请求并等待响应。成功日志有 sandbox/template ID，但普通请求日志并不能独立建立所有入口到出口的精确成对窗口。 | [API handler](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeAPI/src/handlers/sandboxes.rs#L178)、[API→Master](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeAPI/src/services/sandboxes.rs#L276) |
| Master `cube-e2e`（response `ext_info`） | 从 `CreateSandbox` 内设置 `startTime` 到成功返回 defer 中 `setProbeInfo`；包含调度、Cubelet RPC、Master 后处理。不覆盖 CubeAPI 前处理、HTTP 网络和响应传输。毫秒取整。 | [Master请求起点/日志](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeMaster/pkg/service/sandbox/sandbox_run.go#L105)、[response计时和probe传播](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeMaster/pkg/service/sandbox/sandbox_run.go#L701) |
| Master stat `cube-e2e` | 从同一 `startTime` 到 `Wait()` 后设置的 `endTime`；比 response ext_info 的结束稍早，二者不能假定完全相等。stat 由 goroutine 异步输出。 | [Master结束点](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeMaster/pkg/service/sandbox/sandbox_run.go#L151)、[Master stat定义](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeMaster/pkg/service/sandbox/sandbox_run.go#L510) |
| Master `cubemaster-inner` | `endTime-startTime` 减最后一次 Cubelet RPC 的持续时间；这是残差，重试时还混有之前尝试等成本。 | [Master stat定义](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeMaster/pkg/service/sandbox/sandbox_run.go#L510) |
| Master `cubemaster-inner-handle` | `endTime-cubeletEndTime`；反映最后一次 Cubelet 返回后的处理窗口。 | [Master stat定义](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeMaster/pkg/service/sandbox/sandbox_run.go#L510) |
| Master `cubemaster-post-redis` / `cubemaster-post-spec` | 分别测 Redis 代理映射写入和 MySQL sandbox spec 持久化；两个任务并行，不能相加作为后处理壁钟耗时。只有操作实际执行时才输出。 | [并行后处理](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeMaster/pkg/service/sandbox/sandbox_run.go#L328)、[Master stat定义](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeMaster/pkg/service/sandbox/sandbox_run.go#L510) |
| Master schedule / buffer handle | `startHandleTime-startTime`；包含进入调度处理前的窗口，不等价于纯队列等待。 | [Master stat定义](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeMaster/pkg/service/sandbox/sandbox_run.go#L510) |

## Cubelet：并行工作流与累计计时

默认 create 工作流为：`[createid, appsnapshot] → [images, volume, storage, network, netfile, cube-sandbox-store] → [cgroup] → [cubebox]`。方括号内并行，组之间等待完成后再推进；须核对实际部署配置，不能只凭源码默认值认定现场设置。定义见 [默认workflow](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/config/config.toml#L177)；每个 action 计时见 [workflow action计时](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/plugins/workflow/engine.go#L476)。

| 指标 | 精确边界与解释 | 源码 |
| --- | --- | --- |
| `cubebox-service` | 从参数检查、默认值设置之后的 `start` 到 service 返回的 defer；不含更早的 cross-node prepare、pause package 展开及参数检查。是工作流外层窗口。 | [service计时起点](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/service.go#L250)、[service结束及异步输出](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/service.go#L312) |
| `network` / `storage` / `cubebox` 等 | 各 workflow action 的 `Create()` 调用持续时间。network 与 storage 处在并行组；不能顺序堆叠。 | [workflow action计时](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/plugins/workflow/engine.go#L476) |
| `storage` 内部 | `prepareRequestVolumes` 与 `prefetchRestoreMemoryVolURL` 并行，等待后写 backend metadata。Template rootfs 克隆及恢复内存路径准备不是简单串行和；没有全部独立起止日志。 | [storage并行准备](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/storage/local.go#L831) |
| `create-sandbox-metadata` | `containerd.NewContainer` 元数据创建，不是 VM 创建。 | [metadata创建](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/cube_container_create.go#L1324) |
| `sandbox-create` | 从 `taskStart` 到 `c.NewTask` 返回，包含 Shim 创建任务。错误提前返回可能没有此阶段 metric。 | [NewTask计时](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/cube_container_create.go#L1353) |
| `sandbox-start` | **同一个** `taskStart` 到后续 `Wait`、`Start`、状态更新完成。包含 `sandbox-create`，不是 Start RPC 独立耗时。 | [NewTask计时](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/cube_container_create.go#L1353)、[累计start](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/cube_container_create.go#L1375) |
| `sandbox-probe` | `doProbe` 全函数窗口；在 runContainer 完成之后执行，可能包含多种就绪检查。没有配置的部分不可擅自解释为真实探测操作。 | [probe调用位置](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/cube_container_create.go#L428)、[probe计时](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/probe.go#L82) |
| `cubebox-service-inner` | `service - 所有probe - images - volume`；没有减 storage/network，并且被减项可能并行，不是纯 Cubelet overhead。 | [派生指标公式](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/service.go#L446) |
| `cubebox-inner` | `cubebox - 所有sandbox/container前缀metric之和`；其中累计 start/create 会重复扣除，因此可能为负，也不能当独立阶段。 | [派生指标公式](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/service.go#L446) |
| Master `sandbox-probe` / `all-probe` | 前者传播 Cubelet 数值；后者累加所有名称含 `-probe` 的值，不能再次与 Cubelet probe 相加。多容器并行时这个和也不是独立壁钟窗口。 | [response计时和probe传播](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeMaster/pkg/service/sandbox/sandbox_run.go#L701) |

子阶段命名由容器索引生成：索引 `0` 变为 `sandbox`，其余变为 `container-索引`，见 [metric命名](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/plugins/workflow/metric.go#L27)。单容器 Template 可以用 Sandbox ID 关联；多容器时还需保留 Container ID 和调用身份。

## Shim、VMM 与 Guest

| 指标/日志 | 精确边界与解释 | 源码 |
| --- | --- | --- |
| `CreatePodSandbox` | Shim TaskService create 请求外层，包括 load spec、sandbox lock、初始化、VM 恢复、Agent 连接、Guest sandbox/container 创建及事件发送。后续非首次 container 调用用 `CreatePodContainer`。 | [Shim create全链路](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/service/task_srv.rs#L328) |
| `LaunchVmm` | 主要覆盖 `VmmInstance::new`；配置转换在 timer 之前。 | [LaunchVmm](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/hypervisor/cube_hypervisor.rs#L88) |
| `RestoreVm` | CH mutex 获取之后，发送 `VmRestore` 到收到返回。**不含**上层 snapshot metadata 校验、配置构造等；也不能等同于“VM 启动到应用可用”。 | [RestoreVm](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/hypervisor/cube_hypervisor.rs#L173)、[restore准备](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/sandbox/sb.rs#L923) |
| `start vm start → agent is ready` | 同 Shim 请求日志时钟的较大窗口，覆盖 launch、restore/boot 和 Agent 连接；其中子段已经包含在窗口内。Template restore 成功走 app snapshot 分支时跳过普通 vsock ready 等待。 | [VM启动](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/sandbox/sb.rs#L866)、[Agent ready](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/sandbox/sb.rs#L472) |
| `ResetVm` | Guest 时间重置和 RNG reseed 两个 RPC；client lock 在 timer 之前。 | [ResetVm](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/sandbox/sb.rs#L438) |
| `CreateSandbox` | storages/DNS 准备完成后开始计时，覆盖请求构造、client lock 和 Guest CreateSandbox RPC。 | [CreateSandbox](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/sandbox/sb.rs#L495) |
| `CreateContainer` | 包括可选 passfd、storages/spec/custom files 准备、client lock、Guest RPC 和本地状态设置。 | [CreateContainer](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/container/mod.rs#L573) |
| `load spec finish at` / `start sandbox finish at` / `start container finish at` | 都以同一次 create 请求的 `Instant` 为起点，是累计值。只有同实例同调用内做差才可得到相邻边界间隔。 | [Shim create全链路](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/service/task_srv.rs#L328) |
| Guest recv → restore branch | 从 `[cube-strace]recv create container` 到 `create container by restore`，仅包括复制/转换 OCI 与选择 restore 分支。 | [Guest restore路径](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/agent/src/rpc.rs#L152) |

Guest restore 分支标记之后，还有锁等待、查找恢复进程、日志 reader 重置、可选 IO 重连、`start_exec_process` 等操作（[Guest restore路径](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/agent/src/rpc.rs#L152)）。因此 `Shim CreateContainer - Guest recv→restore branch` 只能叫“未细分残差”，不能直接命名为 Guest exec、挂载或进程启动耗时。普通创建分支的 add devices/storage/bundle/init/start 五段日志不能套用于 Template restore。

## 日志和 metrics 的准确性边界

- Cubelet 成功阶段短于 **5 ms** 不输出 stat；失败阶段不受此抑制条件限制（[stat抑制与输出](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/service.go#L497)）。缺失不是零，也不能一概证明 `<5 ms`，还可能是路径未执行、失败早退、日志关闭或采集缺口。部分深层 helper 还有 1 ms 记录门槛（[1ms helper门槛](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/storage/image_volume.go#L25)）。
- Cubelet 把已记录的 duration 在请求末尾通过异步 goroutine 集中输出。因此 stat 的时间戳是输出时间，不是子阶段结束时间，**不能 `timestamp-CostTime` 还原各阶段开始时间**（[service结束及异步输出](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/service.go#L312)、[stat抑制与输出](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/cubebox/service.go#L497)）。
- Shim `StatItem` 没有时间戳；`CostTime` 是 `Instant.elapsed().as_millis()` 整数毫秒，成功/失败为 `Ok`/`Err`。队列 `try_send` 失败被忽略，可丢记录（[Shim stat输出](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/log/mod.rs#L394)、[Shim计时器](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeShim/shim/src/log/stat_defer.rs#L75)）。只能用明确 request marker 构造可验证时间窗口，不能凭 stat 文件行序定时。
- Go stat `CostTime` 是毫秒、保留微秒量级；response ext_info 和 Shim stat 则为整数毫秒。不同精度应分别保留（[Go stat开关与单位](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/pkgs/CubeLog/metric.go#L189)）。
- Host 与 Guest 时钟不可直接相减。Guest 会在 ResetVm 中主动设置时间；转发的 Guest 日志还存在异步传输。Guest 子段只使用其内嵌 `ts` 相减，并核对同实例、同调用、非负。跨进程 duration 对比也不是自动得到新的实测区间。
- `/v1/metrics` 是 Prometheus 聚合端点；scheduler/resource 有各自独立路径（[metrics端点](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/Cubelet/services/server/server.go#L250)）。快照差值用于资源压力、计数及覆盖检查；不能为缺失的逐 sandbox 启动 span 补造精确时间轴。累计 histogram 如存在，其桶差值也仅是区间聚合分布，需要检查进程重启、counter reset、并发背景任务及样本群体。
- Master stat 受 `EnableLogMetric` 开关影响（[Go stat开关与单位](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/pkgs/CubeLog/metric.go#L189)）。现场无该文件/未开启时，post-redis/spec 等就是不可观测，不能从 response 推导出假精确值。保留采集缺口即可，不能为了完成报表假设零耗时。
- 不同覆盖率或不同调用集的分位数不能相减；同一实例有多次同名 stage 时也不能静默取第一条。应分别展示覆盖实例数、记录数、失败数、重复记录和缺失数。

## 请求归属与样本分组

并发数、正式请求数和预热次数是工作负载参数，不是阶段解析器的固定常量。各阶段需按实际 Sandbox ID 关联；官方客户端原始结果没有逐条 Sandbox ID 映射时，不得把某条客户端延迟强行配对到某个实例。

Master 请求与响应可通过请求 ID 关联：请求 marker 为 `CreateSandbox:{JSON}`，成功响应为 `CreateSandbox_rsp:{JSON}`，失败响应为 `CreateSandbox_rsp fail:`。请求 JSON 使用 `requestID`，响应使用 `RequestID`，外层日志为 `RequestId`。成功响应包含 `sandbox_id`、`ret`、`ext_info`，成功码为 200（[请求与日志](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeMaster/pkg/service/sandbox/sandbox_run.go#L105)、[响应字段](https://github.com/TencentCloud/CubeSandbox/blob/31d911e430fdf8a8879bd062b8e78066c1a8e89d/CubeMaster/pkg/service/sandbox/util.go#L1081)）。

只有工作负载边界、请求归属和运行环境证据足够时，才能证明某个组件样本属于正式请求或预热。不能按响应完成顺序、日志文件行序或“最早的几个实例”直接分组；并发执行、外部请求、失败与重试都会破坏这种假设。未知归属保留 `unknown_phase`，不补标签，不以样本数量恰好一致代替归属证明。当前入口采取的分组策略见 [快速上手](../docs/QUICKSTART.md)。
