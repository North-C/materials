import test from 'node:test';
import assert from 'node:assert/strict';
import {renderStageView} from './stage_view.mjs';
import {renderReport} from './render_report.mjs';

const value = (avg = 12, observed = 100) => ({stats: {count: observed, avg, p50: 10, p95: 20, max: 30},
  coverage: {observed_instances: observed, owned_instances: 100}});

test('nested windows and parallel preparation retain statistics without adding them', () => {
  const profile = {phases: {formal: {owned_instance_count: 100, cubelet_stages: {
    'sandbox-start': value(200), 'sandbox-create': value(150), network: value(30, 67),
  }, shim_stages: {CreatePodSandbox: value(100)}}}};
  const before = structuredClone(profile);
  const output = renderStageView(profile);
  assert.match(output, /data-stage="cubelet.sandbox-start" open>[\s\S]*data-stage="cubelet.sandbox-create" open>[\s\S]*data-stage="shim.CreatePodSandbox"/);
  assert.match(output, /组内并行，全部结束再继续/);
  assert.match(output, /不求和/);
  assert.match(output, /67\/100/);
  assert.match(output, /统计仅针对已观测样本；缺失不是 0/);
  assert.match(output, /绿色虚线：并行且等待；紫色虚线：后台异步/);
  assert.match(output, /Guest 创建 RPC 会等待返回/);
  assert.deepEqual(profile, before);
});

test('derived and propagated metrics sit outside the main execution tree', () => {
  const output = renderStageView({phases: {formal: {owned_instance_count: 100,
    cubelet_stages: {'cubebox-service-inner': value(), 'cubebox-inner': value()},
    cubemaster_stages: {'sandbox-probe': value(), 'all-probe': value()},
  }}});
  const separate = output.indexOf('传播值与派生值 · 不作为额外执行阶段');
  for (const id of ['cubelet.cubebox-service-inner', 'cubelet.cubebox-inner', 'master.sandbox-probe', 'master.all-probe']) {
    assert.ok(output.indexOf(`data-stage="${id}"`) > separate, id);
  }
  assert.match(output, /减所有 probe、images 与 volume/);
  assert.match(output, /累计窗口重复扣除，可能为负/);
});

test('unknown population stays separate and new stage names are escaped and retained', () => {
  const output = renderStageView({phases: {
    formal: {owned_instance_count: 100, cubelet_stages: {cubebox: value()}},
    unknown_phase: {owned_instance_count: 100, cubelet_stages: {'custom<img src=x>': value(98)}},
  }});
  assert.match(output, /class="stage-phase" open><summary>正式实例 · formal/);
  assert.match(output, /class="stage-phase"><summary>归属阶段未确认的实例 · unknown_phase/);
  assert.match(output, /其他观测 · 包含关系未定义/);
  assert.match(output, /custom&lt;img src=x&gt;/);
  assert.doesNotMatch(output, /<img/);
  const unknownOnly = renderStageView({phases: {unknown_phase: {owned_instance_count: 100,
    cubelet_stages: {network: value()}}}});
  assert.match(unknownOnly, /class="stage-phase" open><summary>归属阶段未确认的实例/);
});

test('no observations do not create a fake diagram with zero timings', () => {
  assert.equal(renderStageView({phases: {formal: {owned_instance_count: 100,
    cubelet_stages: {cubebox: {stats: null}}}}}), '');
});

test('HTML leads with relationship view and keeps full table available without scripts', () => {
  const out = renderReport({}, {phases: {formal: {owned_instance_count: 100,
    cubelet_stages: {cubebox: value()}}}});
  assert.ok(out.html.indexOf('id="stage-relations"') < out.html.indexOf('<h2>单次启动时延'));
  assert.match(out.html, /<details class="raw-stages"><summary>完整原始阶段表/);
  assert.match(out.html, /<td>formal<\/td><td>Cubelet.cubebox/);
  assert.doesNotMatch(out.html, /<script|<link|<iframe/);
  assert.match(out.html, /focus-visible/);
});
