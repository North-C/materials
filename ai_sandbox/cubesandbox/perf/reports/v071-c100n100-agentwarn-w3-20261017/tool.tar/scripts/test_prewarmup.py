"""Prewarmup evidence must reject failures before the formal capture starts."""
import unittest

from scripts.prewarmup import validate_warmup


class PrewarmupEvidenceTest(unittest.TestCase):
    def evidence(self):
        return {"config": {"concurrency": 1, "total": 2, "warmup": 0,
                           "mode": "create-only", "template": "synthetic-template"},
                "raw": [{"seq": 1, "create_ms": 2}, {"seq": 2, "create_ms": 3}]}

    def test_failed_request_and_duplicate_sequence_are_not_successful_warmup(self):
        value = self.evidence()
        value["raw"][1].update(seq=1, error="synthetic failure")
        successful, problems = validate_warmup(value, 2, "synthetic-template")
        self.assertEqual(successful, 1)
        self.assertIn("warmup_sample_failed_or_invalid", problems)
        self.assertIn("warmup_sample_count_or_sequence_mismatch", problems)

    def test_enormous_latency_is_rejected_without_overflow(self):
        value = self.evidence()
        value["raw"][0]["create_ms"] = 10 ** 1000
        successful, problems = validate_warmup(value, 2, "synthetic-template")
        self.assertEqual(successful, 1)
        self.assertIn("warmup_sample_failed_or_invalid", problems)

    def test_unexpected_internal_warmup_is_rejected(self):
        value = self.evidence()
        value["warmup_raw"] = [{"seq": 0, "create_ms": 5}]
        self.assertIn("warmup_unexpected_internal_warmup_samples",
                      validate_warmup(value, 2, "synthetic-template")[1])


if __name__ == "__main__":
    unittest.main()
