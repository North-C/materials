#!/usr/bin/env node
// Validate explicit phase declarations. Timing/order alone never proves membership.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { pathToFileURL } from 'node:url';

const PHASES = ['formal', 'warmup', 'unknown_phase'];
const validId = x => typeof x === 'string' && x.trim() && x === x.trim();

export function normalizeOwned(ownership) {
  const warnings = [], sets = PHASES.map(phase => {
    if (!Array.isArray(ownership?.[phase])) {
      warnings.push(`Ownership phase ${phase} missing/invalid; treated as empty.`);
      return new Set();
    }
    const values = ownership[phase];
    if (values.some(x => !validId(x))) warnings.push(`Invalid ID in ownership phase ${phase} ignored.`);
    return new Set(values.filter(validId));
  });
  const all = [...new Set(sets.flatMap(ids => [...ids]))];
  const conflicts = all.filter(id => sets.filter(ids => ids.has(id)).length > 1);
  return { ids: all.filter(id => !conflicts.includes(id)), conflicts, warnings };
}

export function classifyPhases(input = {}) {
  const { ids, conflicts, warnings } = normalizeOwned(input.ownership);
  const errors = [...(input.inputErrors ?? [])], checks = {};
  const unknown = {formal: [], warmup: [], unknown_phase: ids};
  const map = input.phaseMap;
  if (map !== undefined && map !== null) {
    const check = (name, value) => { checks[name] = Boolean(value); if (!value) errors.push(name); };
    check('mapping_has_all_phase_arrays', map && typeof map === 'object' && !Array.isArray(map) &&
      PHASES.every(p => Array.isArray(map[p])));
    const proposed = PHASES.flatMap(p => Array.isArray(map?.[p]) ? map[p] : []);
    check('mapping_ids_valid_and_unique', proposed.every(validId) && new Set(proposed).size === proposed.length);
    check('mapping_matches_unambiguous_owned_ids', proposed.length === ids.length && proposed.every(id => ids.includes(id)));
    const manifest = input.manifest ?? {};
    for (const [phase, field, minimum] of [['formal', 'requests', 1], ['warmup', 'warmup', 0]]) {
      const expected = manifest[field];
      check(`manifest_${field}_valid`, Number.isInteger(expected) && expected >= minimum);
      check(`${phase}_does_not_exceed_planned_count`, Array.isArray(map?.[phase]) &&
        Number.isInteger(expected) && map[phase].length <= expected);
    }
  }
  const declared = map !== undefined && map !== null && errors.length === 0;
  return {schema_version: 2, status: declared ? 'declared' : 'unverified',
    method: declared ? 'Explicit caller-supplied phase map; structural checks only' : 'No accepted phase map; all unambiguous owned IDs remain unknown',
    raw_seq_to_sandbox_mapping: 'unavailable', checks, errors: [...new Set(errors)],
    ownership: declared ? Object.fromEntries(PHASES.map(p => [p, [...map[p]]])) : unknown,
    conflicting_ownership_ids: conflicts, warnings,
    evidence: {files: input.fileEvidence ?? {}},
    limitations: ['Declared phases are supplied by the caller, not independently verified against a runner or server.',
      'A structural match does not prove run ownership, warmup boundaries, workload success, or raw-sequence-to-sandbox mapping.',
      'Conflicting original phase membership is excluded from every phase; it is never rescued by a declaration.',
      'No source ownership file is modified.']};
}

export function loadAndClassify(directory, options = {}) {
  const root = path.resolve(directory), fileEvidence = {}, inputErrors = [];
  const read = name => {
    const file = path.join(root, name);
    try {
      const bytes = fs.readFileSync(file);
      fileEvidence[name] = {bytes: bytes.length, sha256: crypto.createHash('sha256').update(bytes).digest('hex')};
      return JSON.parse(bytes.toString('utf8'));
    } catch { inputErrors.push(`unreadable_or_invalid:${name}`); return null; }
  };
  return classifyPhases({manifest: read('capture-manifest.json'), ownership: read('owned-sandbox-ids.json'),
    phaseMap: options.phaseMap, fileEvidence, inputErrors});
}

if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  const args = process.argv.slice(2);
  if (!(args.length === 1 || (args.length === 3 && args[1] === '--phase-map'))) {
    console.error('Usage: node classify_phases.mjs CAPTURE_DIRECTORY [--phase-map FILE]'); process.exit(2);
  }
  try {
    const phaseMap = args[2] ? JSON.parse(fs.readFileSync(args[2], 'utf8')) : undefined;
    const result = loadAndClassify(args[0], {phaseMap});
    const output = path.join(args[0], 'phase-classification.json');
    fs.writeFileSync(output, JSON.stringify(result, null, 2) + '\n', {flag: 'wx', mode: 0o600});
    console.log(JSON.stringify({status: result.status, output, errors: result.errors}));
    console.error(result.status === 'declared' ? 'WARNING: Phase map is declared, not independently verified.' : 'WARNING: Phase membership is unverified; results remain unknown_phase.');
    process.exitCode = args[2] && result.status !== 'declared' ? 2 : 0;
  } catch (error) { console.error(error.message); process.exitCode = 2; }
}
