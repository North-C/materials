import fs from 'node:fs';
import path from 'node:path';
import { renderStageView, stageViewCSS } from './stage_view.mjs';

const ownershipHints = JSON.parse(fs.readFileSync(new URL('./ownership_diagnostics.json', import.meta.url), 'utf8'));

const html = value => String(value ?? '未提供').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const md = value => String(value ?? '未提供').replace(/\|/g, '\\|').replace(/[\r\n]+/g, ' ');
const number = value => typeof value === 'number' && Number.isFinite(value) ? Number(value.toFixed(6)).toString() : '未提供';
const duration = item => item?.status === 'available' ? `${number(item.duration_ms)} ms` : `未提供（${item?.status ?? 'missing'}）`;

export function renderReport(run, profile) {
  const timingNames = {benchmark: '正式测试整轮耗时', command: '外部命令窗口', capture: '采集窗口'};
  const timingRows = Object.entries(timingNames).map(([key, label]) => {
    const value = run.durations?.[key];
    return [label, duration(value), Array.isArray(value?.source) ? value.source.join(', ') : value?.source ?? '无', value?.scope ?? ''];
  });
  const prewarmup = run.prewarmup?.mode === 'separate_process' ? run.prewarmup : null;
  if (prewarmup) timingRows.push(['独立预热命令耗时',
    typeof prewarmup.duration_ms === 'number' && Number.isFinite(prewarmup.duration_ms) && prewarmup.duration_ms >= 0
      ? `${number(prewarmup.duration_ms)} ms` : '未提供',
    'prewarmup.duration_ms', '正式采集之前的独立进程；不计入正式测试整轮耗时']);
  const latency = run.create_latency_ms ?? {};
  const latencyRows = ['count', 'avg', 'p50', 'p95', 'max'].map((key, i) =>
    [['有效样本数', '平均值 (ms)', 'P50 (ms)', 'P95 (ms)', '最大值 (ms)'][i], number(latency[key])]);
  const workload = run.workload ?? {};
  const overview = `${run.synthetic ? "合成样例数据，仅用于演示，不是实测结果。 " : ""}并发 ${workload.concurrency ?? '未知'}；正式计划请求 ${workload.requests ?? '未知'}；正式进程内置预热 ${workload.warmup ?? '未知'}。${prewarmup ? ` 独立预热计划 ${prewarmup.count ?? '未知'} 次，成功 ${prewarmup.successful ?? '未知'} 次，状态 ${prewarmup.status ?? '未知'}。` : ''}${run.runner_validation?.status === 'limited' ? ' 数据范围受限（limited）：客户端计时可用，组件阶段仅覆盖有可靠实例 ID 的样本；缺失归属时无法生成按实例的阶段统计。' : ''}${run.runner_validation?.status === 'invalid' ? ' Runner 结果校验失败（invalid），请查看数据限制。' : ''}`;
  const stageRows = [];
  for (const [phase, group] of Object.entries(profile.phases ?? {})) {
    for (const [source, field] of [['Cubelet', 'cubelet_stages'], ['Shim', 'shim_stages'], ['Master response', 'cubemaster_stages'], ['Master stat', 'cubemaster_trace_stages']]) {
      for (const [stage, value] of Object.entries(group[field] ?? {})) {
        if (!value.stats) continue;
        const c = value.coverage ?? {};
        stageRows.push([phase, `${source}.${stage}`, `${c.observed_instances ?? '?'}/${c.owned_instances ?? '?'}`,
          number(value.stats.count), number(value.stats.avg), number(value.stats.p50), number(value.stats.p95), number(value.stats.max)]);
      }
    }
  }
  const phaseRows = Object.entries(profile.phases ?? {}).map(([phase, group]) => {
    const observed = stageRows.filter(row => row[0] === phase).length;
    return [phase, number(group.owned_instance_count), observed,
      phase === 'unknown_phase' ? '实例已归属本轮，但正式/预热阶段未确认；保留观测，不用于正式分布' :
      phase === 'formal' ? '正式集合；归属证据及限制见下文' : '预热集合'];
  });
  const stageNote = stageRows.length
    ? `共展示 ${stageRows.length} 个分组阶段的观测统计；unknown_phase 中有观测的阶段同样展示，不会因为分组未知而隐藏。未观测阶段与全部覆盖缺口见阶段 CSV 和 analysis.json。`
    : Object.values(profile.phases ?? {}).some(group => group.owned_instance_count > 0)
      ? '本次没有可展示的阶段耗时：已有实例 ID，但日志中没有匹配到有效阶段数值。请检查日志路径、采集窗口、日志缺口与解析结果；未记录的阶段不能按 0 ms 计算。客户端时延仍独立展示。'
      : '本次没有可展示的阶段耗时：缺少可靠的实例 ID 归属，无法将组件日志关联到本轮请求。请检查 CLI 前后清单、模板独占声明和 runner 校验结果；unknown_phase 本身不会隐藏已有观测。客户端时延仍独立展示。';
  const stageView = renderStageView(profile);
  const diagnosticCodes = [...new Set([
    ...(run.runner_validation?.problems ?? []), ...(run.inventory?.errors ?? []),
  ])];
  const diagnosticRows = diagnosticCodes.map(code => [code,
    ownershipHints[code] ?? '查看 benchmark-inputs/runner-validation.json 与 inventory-evidence/ 中的校验记录。']);
  const missingOwnership = !Object.values(profile.phases ?? {}).some(group => group.owned_instance_count > 0);
  if (missingOwnership && !run.inventory && (run.warnings ?? []).some(w => /sandbox(?:es)?_ids_absent/.test(w))) {
    diagnosticRows.push(['sandbox_ids_absent_without_inventory',
      '客户端原始结果未输出 sandbox_id，且没有 CLI 归属结果。配置 cubemastercli，使其连接本轮 CubeAPI 使用的 CubeMaster；确认模板独占后设置 exclusive_template: true。若 runner 校验显示 CLI 查询失败，先修复查询。']);
  }
  const diagnosticSummary = run.inventory ? `CLI 候选 ${run.inventory.candidate_ids?.length ?? 0} 个；预期 ${run.inventory.expected_count ?? '未提供'} 个；归属${run.inventory.accepted ? '已采用' : '未采用'}。` : '';
  const warnings = [...new Set([...(run.warnings ?? []), ...(profile.warnings ?? []), ...(run.limitations ?? [])])];
  const warmup = 'warmup 是正式测量前的预热操作，用于让连接、缓存和资源池预先被使用。官方 cube-bench 串行执行预热，然后开始正式测试；create-only 每次创建，create-delete 每次还包含删除；预热不进入其正式 raw 样本和 summary.total_time_s。自定义 runner 必须明确自己的计时和样本范围。预热不保证消除所有冷启动开销。';
  const prewarmupNote = prewarmup ? `本次采用独立进程预热：计划 ${prewarmup.count ?? '未知'} 次，成功 ${prewarmup.successful ?? '未知'} 次，状态 ${prewarmup.status ?? '未知'}，进程退出码 ${prewarmup.benchmark_exit_code ?? '未提供'}。正式 cube-bench 使用 -w 0。预热进程耗时单独列出，不加入正式整轮耗时；它与原内置 warmup 不同，正式进程不复用预热进程的 HTTP 连接。预热在正式日志采集窗口之前执行；实例归属依赖预热后的 CLI 基线和正式请求后的清单差集。metrics 是全局指标，仍可能包含背景活动或延迟上报。` : '';
  const boundaries = '整轮耗时是正式测试从开始到结束的经过时间，不是单次延迟的总和或最大值。外部命令可能包含预热、初始化、清理；采集窗口还可能包含 metrics 和日志收尾。整轮计时缺失时不使用后两者代替。';
  const inventoryNote = run.inventory ? ` 实例 ID 来源包含 cubemastercli 前后清单：候选 ${run.inventory.candidate_ids?.length ?? 0} 个，${run.inventory.accepted ? run.inventory.phase === 'formal' ? '在用户声明模板独占且正式进程内置预热为 0 的前提下，使用正式命令前后清单差集推定 formal 集合；这是集合级归属，不是逐请求关联。' : '在用户声明模板独占的前提下推定本轮归属；仅有清单证据的实例归入 unknown_phase（可能为预热与正式混合）。' : '未采用清单候选作为本轮实例。'}此方式不提供客户端 seq 到实例的映射，CLI 的节点遍历计数不证明每个节点查询成功。` : '';
  const attribution = `组件分组状态：${profile.phase_attribution_status ?? 'unverified'}。unknown_phase 可能混有预热；declared 仅表示用户声明。阶段样本集合与客户端样本集合不一定相同，父子与并行阶段不能相加。${inventoryNote}`;
  const sources = [ ['完整汇总 JSON','run-summary.json'], ['完整分析 JSON','analysis.json'], ['阶段 CSV','stage-latency.csv'],
    ['实例时间轴','timeline.html'], ['客户端原始输入（未脱敏）','benchmark-inputs/'], ['输入校验清单','analysis-manifest.json'] ];
  if (run.inventory) sources.push(['CLI 实例清单与归属证据（未脱敏）', 'inventory-evidence/']);
  const markdownTable = (headers, rows) => `| ${headers.map(md).join(' | ')} |\n| ${headers.map(() => '---').join(' | ')} |\n${rows.map(r => `| ${r.map(md).join(' | ')} |`).join('\n')}`;
  const htmlTable = (headers, rows) => `<div class="scroll"><table><thead><tr>${headers.map(x => `<th>${html(x)}</th>`).join('')}</tr></thead><tbody>${rows.map(r => `<tr>${r.map(x => `<td>${html(x)}</td>`).join('')}</tr>`).join('')}</tbody></table></div>`;
  const timingHeaders = ['口径', '耗时', '数据来源', '覆盖范围'];
  const phaseHeaders = ['分组', '归属实例数', '有观测的阶段数', '统计口径'];
  const stageHeaders = ['分组', '阶段', '实例覆盖', '样本数', '平均 ms', 'P50 ms', 'P95 ms', '最大 ms'];
  const requestRows = Object.entries(run.requests ?? {}).map(([key, value]) => [key, number(value)]);
  const diagnosticMarkdown = diagnosticRows.length ? `## 实例归属与校验诊断\n\n${diagnosticSummary}\n\n${markdownTable(['原因码', '含义与处理建议'], diagnosticRows)}\n\n详见 [runner 校验记录](benchmark-inputs/runner-validation.json)；CLI 查询详情见 inventory-evidence 中的 before/after.json 与 stderr。\n\n` : '';
  const diagnosticHtml = diagnosticRows.length ? `<section class="note"><h2>实例归属与校验诊断</h2><p>${html(diagnosticSummary)}</p>${htmlTable(['原因码', '含义与处理建议'], diagnosticRows)}<p>详见 <a href="benchmark-inputs/runner-validation.json">runner 校验记录</a>；CLI 查询详情见 inventory-evidence 中的 before/after.json 与 stderr。</p></section>` : '';
  const markdown = `# CubeSandbox 启动分析报告\n\n${overview}\n\n${diagnosticMarkdown}## 整轮耗时\n\n${markdownTable(timingHeaders, timingRows)}\n\n${boundaries}\n\n## 单次启动时延\n\n${markdownTable(['指标', '值'], latencyRows)}\n\n${markdownTable(['请求统计', '值'], requestRows)}\n\n## warmup 与样本口径\n\n${warmup}\n\n${prewarmupNote}\n\n${attribution}\n\n## 已观测阶段\n\n${markdownTable(phaseHeaders, phaseRows)}\n\n${stageNote}\n\n${stageRows.length ? markdownTable(stageHeaders, stageRows) : ''}\n\n查看 [阶段 CSV](stage-latency.csv)、[完整分析 JSON](analysis.json) 和 [runner 原始结果与校验记录](benchmark-inputs/)。\n\n## 数据文件\n\n${sources.map(([label, href]) => `- [${label}](${href})`).join('\n')}\n\nbenchmark-inputs 保留已提供的客户端结果文件原始字节；没有输入时目录为空。原始输入及报告可能包含敏感信息，分享前需检查。\n\n## 数据限制\n\n${warnings.map(w => `- ${md(w)}`).join('\n') || '无新增提示；仍需核对输入数据来源。'}\n`;
  const document = `<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>CubeSandbox 启动分析报告</title><style>body{margin:0;background:#f6f7f9;color:#203040;font:16px/1.65 system-ui,sans-serif}main{max-width:1200px;margin:auto;padding:32px 24px}h1{font-size:30px}h2{margin-top:32px}p{max-width:1050px}.scroll{overflow:auto}table{border-collapse:collapse;background:white;width:100%;font-size:14px}th,td{text-align:left;padding:10px 12px;border:1px solid #dce2e8;vertical-align:top}th{background:#eaf0f5}a{color:#155ba0}li{overflow-wrap:anywhere}.note{padding:16px 20px;background:#edf3f7;border-left:4px solid #7893ac}${stageViewCSS}</style><main><h1>CubeSandbox 启动分析报告</h1><p>${html(overview)}</p>${diagnosticHtml}<h2>整轮耗时</h2>${htmlTable(timingHeaders,timingRows)}<p class="note">${html(boundaries)}</p>${stageView}<h2>单次启动时延</h2>${htmlTable(['指标','值'],latencyRows)}${htmlTable(['请求统计','值'],requestRows)}<h2>warmup 与样本口径</h2><p>${html(warmup)}</p>${prewarmupNote ? `<p class="note">${html(prewarmupNote)}</p>` : ''}<p>${html(attribution)}</p><h2>已观测阶段</h2>${htmlTable(phaseHeaders,phaseRows)}<p class="note">${html(stageNote)}</p>${stageRows.length ? `<details class="raw-stages"><summary>完整原始阶段表 · 含 P50、最大值与全部分组</summary>${htmlTable(stageHeaders,stageRows)}</details>` : ''}<p>查看 <a href="stage-latency.csv">阶段 CSV</a>、<a href="analysis.json">完整分析 JSON</a> 和 <a href="benchmark-inputs/">runner 原始结果与校验记录</a>。</p><h2>数据文件</h2><ul>${sources.map(([label,href])=>`<li><a href="${href}">${html(label)}</a></li>`).join('')}</ul><p>benchmark-inputs 保留客户端结果文件原始字节；没有输入时目录为空。原始输入与报告未自动脱敏。</p><h2>数据限制</h2><ul>${warnings.map(w=>`<li>${html(w)}</li>`).join('')}</ul></main></html>\n`;
  return {markdown, html: document};
}

export function writeReport(output, run, profile) {
  const result = renderReport(run, profile);
  for (const [name, value] of [['REPORT.md', result.markdown], ['report.html', result.html]])
    fs.writeFileSync(path.join(output, name), value, {flag:'wx', mode:0o600});
}
