// Presentation of the v0.7.1 default, single-container Template path.
// Structure follows scripts/STAGES.md, not log order or aggregate percentiles.
const escape = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const fmt = value => typeof value === 'number' && Number.isFinite(value)
  ? value.toLocaleString('en-US', {maximumFractionDigits: 3}) : '未提供';
const fields = {cubelet: 'cubelet_stages', shim: 'shim_stages', master: 'cubemaster_stages', master_trace: 'cubemaster_trace_stages'};
const prefixes = {cubelet: 'Cubelet', shim: 'Shim', master: 'Master response', master_trace: 'Master stat'};
const node = (id, note, children = [], options = {}) => ({id, note, children, ...options});
const group = (title, note, children, options = {}) => ({title, note, children, group: true, ...options});

const tree = node('master.cube-e2e', 'Master 服务端外层窗口；包含调度、Cubelet 调用和返回前处理。', [
  node('cubelet.cubebox-service', 'Cubelet 工作流外层窗口；完成各组准备后进入创建与就绪检查。', [
    group('准备组 1 · 组内并行，全部结束再继续', '默认 workflow：createid 与 appsnapshot 并行；不是两个串行时间片。', [
      node('cubelet.createid', '生成实例标识。'), node('cubelet.appsnapshot', 'Template 快照准备。'),
    ], {kind: 'parallel'}),
    group('准备组 2 · 组内并行，全部结束再继续', 'network / storage / images / volume / netfile / store 并行；不能把各分支相加作为组耗时。', [
      node('cubelet.network', '网络准备；与同组 storage 等并行。'),
      node('cubelet.storage', '存储准备；内部卷准备与恢复内存预取也并行，等待后写 metadata。'),
      ...['images', 'volume', 'netfile', 'cube-sandbox-store'].map(name => node(`cubelet.${name}`, '默认 workflow 第二组的并行任务。')),
    ], {kind: 'parallel'}),
    node('cubelet.cgroup', '准备资源组、分配或复用 cgroup、保存归属；在准备组之后、cubebox 之前。', [], {kind: 'serial'}),
    node('cubelet.cubebox', '创建与就绪外层：包含下面的准备、累计 start 窗口、探针和其他收尾。', [
      group('spec 与 containerd 元数据准备', '先准备 spec，再创建 containerd 元数据；metadata 不等于 VM 创建。', [
        node('cubelet.gen-spec-sandbox', '构建 sandbox 运行规格。'),
        node('cubelet.create-sandbox-metadata', 'containerd.NewContainer 元数据创建。'),
      ]),
      node('cubelet.sandbox-start', '累计窗口：从 taskStart 到 NewTask、Wait 注册、Start 与状态更新结束。', [
        node('cubelet.sandbox-create', '与 sandbox-start 同起点，到 NewTask 返回结束；已包含在 start 内。', [
          node('shim.CreatePodSandbox', 'Shim 外层；还包含各子步骤之间未单独计时的准备与等待。', [
            node('shim.LaunchVmm', '启动 VMM；包含于父窗口。'),
            node('shim.RestoreVm', '恢复 VM；之后仍需等待 Agent 连接。'),
            node('shim.ResetVm', 'Agent 连接之后：时间 RPC、RNG 生成、reseed RPC 串行执行。'),
            node('shim.CreateSandbox', '向 Guest 创建 sandbox 的 RPC，调用端等待返回。'),
            node('shim.CreateContainer', '向 Guest 创建/恢复 container 的 RPC，调用端等待返回；不是后台异步任务。'),
          ], {open: false}),
        ], {kind: 'cumulative', open: true}),
      ], {kind: 'cumulative', open: true}),
      node('cubelet.sandbox-probe', '在 runContainer / sandbox-start 完成之后进行就绪检查。', [], {kind: 'serial'}),
      node('cubelet.cube-inner-cgroup', 'cubebox 内同步设置宿主限额；不同于前面的 workflow cgroup。', [], {kind: 'serial'}),
    ], {open: true}),
  ], {open: true}),
  group('Master 返回前处理 · 并行后等待', 'Cubelet 返回之后，Redis 映射与 spec 持久化并行，完成后才返回；不是后台落库。', [
    node('master_trace.cubemaster-post-redis', 'Redis 代理映射写入。'),
    node('master_trace.cubemaster-post-spec', 'sandbox spec 持久化。'),
  ], {kind: 'parallel'}),
], {open: true});

const derived = [
  node('cubelet.cubebox-service-inner', '派生：cubebox-service 减所有 probe、images 与 volume；不是一个新增执行阶段。', [], {kind: 'derived'}),
  node('cubelet.cubebox-inner', '派生：cubebox 减所有 sandbox/container 前缀指标之和；start/create 等累计窗口重复扣除，可能为负，不是互斥阶段的剩余时间。', [], {kind: 'derived'}),
  node('master.sandbox-probe', '传播副本：来自 Cubelet probe，精度可能不同；不要再加一次。', [], {kind: 'copy'}),
  node('master.all-probe', '聚合：Master 汇总 probe 值；不是另一次就绪探测。', [], {kind: 'derived'}),
  node('master_trace.cubemaster-inner', '派生残差：Master 外层减最后一次 Cubelet RPC；重试时不能解释为纯调度。', [], {kind: 'derived'}),
];
const windows = [
  node('master_trace.cube-e2e', 'Master stat 外层：结束点早于 response ext_info；两份窗口不能相加。'),
  node('master_trace.bufferhandle', '进入处理前的窗口，含请求准备等成本，不等于纯队列等待。'),
  node('master_trace.cubemaster-inner-handle', '最后一次 Cubelet 返回后的处理窗口，覆盖并行后处理。'),
];
const badges = {parallel: '并行 · 等待汇合', serial: '顺序推进', cumulative: '包含 · 累计计时', derived: '公式派生', copy: '传播副本'};

export const stageViewCSS = `
.relation-view{margin:24px 0;color:#1b2d3e}.relation-view h3{font-size:19px;margin:0 0 12px}
.relation-view p{max-width:85ch}.relation-overview{background:#fff;border:1px solid #b9c9d5;padding:18px;margin:16px 0}
.relation-shell{border-left:3px solid #477b9e;padding:10px 12px;background:#f5f9fc;margin:10px 0}
.relation-shell strong{font-size:15px}.relation-chain{display:flex;align-items:center;gap:9px;flex-wrap:wrap;margin-top:10px;font-size:14px}
.relation-step{background:white;border:1px solid #c3cfd8;padding:7px 10px}.relation-step.parallel{border:1px dashed #237b72;color:#185b54}
.relation-async{border:1px dashed #765392;padding:12px 16px;background:#faf7fc;font-size:14px;margin-top:14px}
.relation-async strong{color:#64437f}.relation-legend{display:flex;gap:8px 18px;flex-wrap:wrap;font-size:13px;color:#4e6374}
.stage-phase{border:1px solid #bacbd6;background:#fff;margin:18px 0}.stage-phase>summary{padding:16px;font-size:18px;font-weight:600;background:#edf3f7;cursor:pointer}
.stage-phase>summary small{font-size:13px;font-weight:400;margin-left:10px}.stage-phase-body{padding:16px}
.stage-tree-head,.stage-line{display:grid;grid-template-columns:minmax(0,1fr) 92px 92px 100px;gap:10px;align-items:center}
.stage-tree-head{padding:8px 12px;color:#536a7a;font-size:12px;border-bottom:1px solid #cbd7df}.stage-tree-head span:not(:first-child){text-align:right}
.stage-node{margin:0;border-bottom:1px solid #e3e9ee}.stage-node>summary{list-style:none;cursor:pointer}.stage-node>summary::-webkit-details-marker{display:none}
.stage-line{padding:11px 12px;font-size:14px}.stage-line .stage-name{min-width:0;overflow-wrap:anywhere}
.stage-line code{font-size:13px;font-family:ui-monospace,SFMono-Regular,Consolas,monospace}.stage-title{font-weight:600}
.stage-chevron{display:inline-block;width:16px;font-size:12px;color:#536a7a}.stage-node[open]>summary .stage-chevron{transform:rotate(90deg)}
.stage-badge{font:11px/1.7 system-ui,sans-serif;padding:2px 6px;background:#eaf0f5;color:#285b7e;display:inline-block;margin-left:7px;border-radius:3px}
.stage-badge.parallel{background:#e7f4f0;color:#1b6d60}.stage-badge.derived,.stage-badge.copy{background:#f8f0dd;color:#795515}
.stage-stat{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap}.stage-stat small{font-size:10px;display:block;color:#6b7e8a}
.stage-stat.partial{color:#865d1f}.stage-stat.missing{font-size:12px;color:#71818c}
.stage-children{margin-left:16px;border-left:2px solid #cedce5}.stage-node.parallel>.stage-children{border-left:2px dashed #58a294}
.stage-explanation{margin:0!important;padding:0 12px 10px;font-size:12px;color:#566d7d}.stage-node>summary:hover,.stage-leaf:hover{background:#f2f7fa}
.stage-phase summary:focus-visible,.raw-stages>summary:focus-visible{outline:3px solid #3079a8;outline-offset:2px}
.stage-subsection{margin:16px 0 0}.stage-subsection>summary{padding:10px 12px;cursor:pointer;background:#f3f5f7;font-weight:600;font-size:14px}
.raw-stages{margin:24px 0}.raw-stages>summary{cursor:pointer;font-weight:600;padding:12px;background:#edf1f5}
@media(max-width:700px){.stage-tree-head{display:none}.stage-line{grid-template-columns:repeat(3,minmax(0,1fr));gap:5px}.stage-line .stage-name{grid-column:1/-1}.stage-stat{text-align:left;font-size:13px}.stage-stat::before{content:attr(data-label) ' ';font-size:11px;color:#607483}.stage-children{margin-left:8px}.stage-phase-body{padding:8px}.relation-overview{padding:12px}.stage-phase>summary small{display:block;margin-left:0}}
@media print{.stage-node:not([open])> .stage-children,.stage-node:not([open])> .stage-explanation{display:block}.stage-phase,.relation-overview{break-inside:avoid}}
`;

function valueFor(phase, id) {
  const [source, ...parts] = id.split('.');
  return phase[fields[source]]?.[parts.join('.')];
}
function labelFor(id) {
  const [source, ...parts] = id.split('.');
  return `${prefixes[source] ?? source}.${parts.join('.')}`;
}

function renderPhase(phaseName, phase, opened) {
  const seen = new Set();
  const render = entry => {
    if (entry.id) seen.add(entry.id);
    const value = entry.id ? valueFor(phase, entry.id) : null;
    const stat = value?.stats;
    const coverage = value?.coverage ?? {};
    const children = entry.children ?? [];
    const expandable = children.length > 0;
    const kind = entry.kind ?? (expandable && !entry.group ? 'inside' : '');
    const badge = badges[kind] ?? (kind === 'inside' ? '外层 · 包含子项' : '');
    const title = entry.id ? `<code>${escape(labelFor(entry.id))}</code>` : `<span class="stage-title">${escape(entry.title)}</span>`;
    const cells = entry.group
      ? '<span class="stage-stat missing" data-label="平均">不求和</span><span class="stage-stat missing" data-label="P95">不求和</span><span class="stage-stat missing" data-label="覆盖">逻辑分组</span>'
      : `<span class="stage-stat ${stat ? '' : 'missing'}" data-label="平均">${stat ? fmt(stat.avg) : '未观测'}</span><span class="stage-stat ${stat ? '' : 'missing'}" data-label="P95">${stat ? fmt(stat.p95) : '未观测'}</span><span class="stage-stat ${stat && coverage.observed_instances < coverage.owned_instances ? 'partial' : ''}" data-label="覆盖">${stat ? `${fmt(coverage.observed_instances)}/${fmt(coverage.owned_instances)}` : '—'}${stat ? `<small>${fmt(stat.count)} 条记录</small>` : ''}</span>`;
    const line = `<div class="stage-line"><span class="stage-name">${expandable ? '<span class="stage-chevron" aria-hidden="true">▶</span>' : ''}${title}${badge ? `<span class="stage-badge ${kind}">${escape(badge)}</span>` : ''}</span>${cells}</div>`;
    const note = `<p class="stage-explanation">${escape(entry.note)}${stat && coverage.observed_instances < coverage.owned_instances ? ' 覆盖不完整：统计仅针对已观测样本；缺失不是 0。' : ''}</p>`;
    if (!expandable) return `<div class="stage-node stage-leaf" data-stage="${escape(entry.id)}">${line}${note}</div>`;
    return `<details class="stage-node ${kind}" data-stage="${escape(entry.id ?? '')}"${entry.open ? ' open' : ''}><summary>${line}</summary>${note}<div class="stage-children">${children.map(render).join('')}</div></details>`;
  };
  const main = render(tree);
  const extraWindows = windows.filter(item => valueFor(phase, item.id)?.stats).map(render).join('');
  const separate = derived.filter(item => valueFor(phase, item.id)?.stats).map(render).join('');
  // A new or custom stage remains visible without inventing a parent or order.
  const other = Object.entries(fields).flatMap(([source, field]) => Object.entries(phase[field] ?? {})
    .filter(([name, value]) => value.stats && !seen.has(`${source}.${name}`))
    .map(([name]) => render(node(`${source}.${name}`, '本视图未定义其包含或先后关系；独立列出，不推定所在时间片。')))).join('');
  const label = phaseName === 'formal' ? '正式实例' : phaseName === 'warmup' ? '预热实例' : phaseName === 'unknown_phase' ? '归属阶段未确认的实例' : phaseName;
  return `<details class="stage-phase"${opened ? ' open' : ''}><summary>${escape(label)} · ${escape(phaseName)}<small>${fmt(phase.owned_instance_count)} 个实例${phaseName === 'unknown_phase' ? ' · 可能混有预热，不作为正式分布' : ''}</small></summary><div class="stage-phase-body"><div class="stage-tree-head"><span>包含关系 / 执行顺序 · 点击父节点展开或收起</span><span>平均 ms</span><span>P95 ms</span><span>实例覆盖</span></div>${main}${extraWindows ? `<details class="stage-subsection"><summary>Master 其他计时窗口 · 与主路径交叠</summary>${extraWindows}</details>` : ''}${separate ? `<details class="stage-subsection"><summary>传播值与派生值 · 不作为额外执行阶段</summary>${separate}</details>` : ''}${other ? `<details class="stage-subsection" open><summary>其他观测 · 包含关系未定义</summary>${other}</details>` : ''}</div></details>`;
}

export function renderStageView(profile) {
  const phases = Object.entries(profile.phases ?? {}).filter(([, phase]) =>
    Object.values(fields).some(field => Object.values(phase[field] ?? {}).some(stage => stage.stats)));
  if (!phases.length) return '';
  const defaultPhase = phases.find(([name]) => name === 'formal')?.[0] ?? phases[0][0];
  return `<section id="stage-relations" class="relation-view" aria-label="启动阶段包含、并行与异步关系"><h3>先看关系，再看耗时</h3>
<p>以下是 v0.7.1 默认工作流的单容器 Template 恢复路径。图和缩进表达调用关系，<strong>不是按耗时比例绘制的瀑布图</strong>；部署自定义 workflow 时需重新核对顺序。客户端 create_ms 是外层观测，未建立逐请求映射时不与某个服务端实例强行配对。</p>
<div class="relation-overview"><div class="relation-legend"><span>嵌套框 / 缩进：包含</span><span>→：完成后推进</span><span>∥：并行，等待汇合</span><span>绿色虚线：并行且等待；紫色虚线：后台异步</span></div>
<div class="relation-shell"><strong>Master · cube-e2e</strong><div class="relation-chain"><span>请求准备与调度</span><span aria-hidden="true">→</span><span>等待 Cubelet 完成</span><span aria-hidden="true">→</span><span class="relation-step parallel">Redis ∥ spec · 等待后返回</span></div>
<div class="relation-shell"><strong>Cubelet · cubebox-service</strong><div class="relation-chain"><span class="relation-step parallel">准备组 1 ∥</span><span>→</span><span class="relation-step parallel">准备组 2 ∥<br>network / storage 等</span><span>→</span><span class="relation-step">cgroup</span><span>→</span><span class="relation-step">cubebox</span></div>
<div class="relation-shell"><strong>cubebox · 创建与就绪</strong><div class="relation-chain"><span>spec / 元数据</span><span>→</span><span class="relation-step">sandbox-start ⊃ sandbox-create ⊃ Shim CreatePodSandbox</span><span>→</span><span>sandbox-probe</span><span>→</span><span>同步收尾</span></div></div></div></div>
<div class="relation-async"><strong>异步支线 · 可与主路径或返回响应重叠</strong><br>Cubelet / Master 统计日志输出、Shim 事件与 Guest 日志转发、按配置执行的 Shim PID 入 cgroup / VM CPU 更新。没有独立计时就保持未观测，不把它们追加成串行耗时。Guest 创建 RPC 会等待返回，不属于此支线。</div></div>
<p><strong>阅读规则：</strong>sandbox-start 已包含 sandbox-create；并行分支不能求和；Master probe 是传播值；派生残差单独展示。每行保留自己的样本覆盖，不将平均值或 P95 相减来构造缺失阶段。</p>
${phases.map(([name, phase]) => renderPhase(name, phase, name === defaultPhase)).join('')}</section>`;
}
