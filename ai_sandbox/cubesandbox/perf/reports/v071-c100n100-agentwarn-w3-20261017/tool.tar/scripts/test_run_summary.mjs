import test from "node:test";
import assert from "node:assert/strict";
import { buildRunSummary } from "./run_summary.mjs";

const manifest = () => ({ concurrency: 2, requests: 2, warmup: 3,
  started_at: "2026-01-01T00:00:00Z", ended_at: "2026-01-01T00:00:10Z",
  command: { started_at: "2026-01-01T00:00:01Z", ended_at: "2026-01-01T00:00:08Z" } });
const raw = () => ({ config: { concurrency: 2, total: 2, warmup: 3, mode: "create-only" },
  raw: [{ seq: 1, create_ms: 100 }, { seq: 2, create_ms: 200 }],
  summary: { total_time_s: 0.25, successful: 2, errors: 0 } });
const build = overrides => buildRunSummary({ manifest: manifest(), raw: raw(),
  profile: { benchmark: { create: { count: 2, avg: 150, min: 100, p50: 100, p95: 200, max: 200 } } }, ...overrides });

test("official cube-bench total_time_s is the formal whole run, distinct from command and capture", () => {
  const result = build();
  assert.deepEqual(Object.fromEntries(Object.entries(result.durations).map(([key, value]) => [key, value.duration_ms])),
    { benchmark: 250, command: 7000, capture: 10000 });
  assert.equal(result.durations.benchmark.status, "available");
  assert.deepEqual(result.durations.benchmark.source, ["raw.summary.total_time_s"]);
  assert.deepEqual(result.workload, { concurrency: 2, requests: 2, warmup: 3 });
  assert.deepEqual(result.requests, { observed: 2, successful: 2, errors: 0, valid_latency: 2 });
  assert.equal(result.create_latency_ms.avg, 150);
});

test("warmup count is not added to formal request population or duration", () => {
  const result = build();
  assert.equal(result.warmup.configured, 3);
  assert.match(result.warmup.runner_scope, /excludes warmup/);
  assert.match(result.warmup.component_scope, /unknown_phase/);
  assert.match(result.warmup.definition, /serial/);
  assert.equal(result.requests.observed, 2);
  assert.equal(result.durations.benchmark.duration_ms, 250);
  assert.match(result.durations.benchmark.scope, /create-delete.*deletion/);
});

test("summary-only input preserves run duration while raw counts remain unknown", () => {
  for (const summary of [{ total_time_s: 1.25 }, { summary: { total_time_s: 1.25 } }]) {
    const result = build({ raw: null, summary });
    assert.equal(result.durations.benchmark.duration_ms, 1250);
    assert.equal(result.requests.observed, null);
  }
});

test("missing benchmark timer never falls back to request max/sum or capture windows", () => {
  const report = raw(); delete report.summary;
  const result = build({ raw: report });
  assert.equal(result.durations.benchmark.duration_ms, null);
  assert.equal(result.durations.benchmark.status, "missing");
  assert.equal(result.durations.capture.duration_ms, 10000);
  assert.match(result.warnings.join(" "), /cannot substitute/);
});

test("measured zero is valid in elapsed and timestamp windows", () => {
  const inputManifest = manifest(); inputManifest.ended_at = inputManifest.started_at;
  const result = build({ manifest: inputManifest, raw: null, summary: { total_time_s: 0 } });
  assert.equal(result.durations.benchmark.duration_ms, 0);
  assert.equal(result.durations.capture.duration_ms, 0);
  assert.equal(result.durations.benchmark.status, "available");
});

test("generic elapsed seconds and milliseconds use explicit units", () => {
  const result = build({ raw: null, summary: { benchmark_timing: { elapsed_s: 0.125, elapsed_ms: 125 } } });
  assert.equal(result.durations.benchmark.duration_ms, 125);
  assert.equal(result.durations.benchmark.source.length, 2);
});

test("generic same-clock timestamp interval is accepted with a clock declaration", () => {
  const result = build({ raw: null, summary: { benchmark_timing: {
    started_at: "2026-01-01T00:00:00.001000Z", ended_at: "2026-01-01T08:00:00.126000+08:00", clock: "runner-wall" } } });
  assert.equal(result.durations.benchmark.duration_ms, 125);
});

test("generic timestamp interval without declared same clock is invalid", () => {
  const result = build({ raw: null, summary: { benchmark_timing: {
    started_at: "2026-01-01T00:00:00Z", ended_at: "2026-01-01T00:00:01Z" } } });
  assert.equal(result.durations.benchmark.status, "invalid");
  assert.equal(result.durations.benchmark.duration_ms, null);
});

test("duplicate consistent sources accepted; disagreements are not silently preferred", () => {
  assert.equal(build({ summary: { total_time_s: 0.25 } }).durations.benchmark.status, "available");
  const result = build({ summary: { total_time_s: 0.5 } });
  assert.equal(result.durations.benchmark.status, "conflict");
  assert.equal(result.durations.benchmark.duration_ms, null);
  assert.match(result.warnings.join(" "), /disagree/);
});

test("invalid elapsed values and overflowing conversions never become numbers", () => {
  for (const total_time_s of [null, "", " ", false, true, -1, "bad", Infinity, NaN, {}, [], 1e308]) {
    const result = build({ raw: null, summary: { total_time_s } });
    assert.equal(result.durations.benchmark.status, "invalid", String(total_time_s));
    assert.equal(result.durations.benchmark.duration_ms, null);
  }
});

test("an invalid competing timer blocks otherwise valid data", () => {
  const result = build({ summary: { total_time_s: "bad" } });
  assert.equal(result.durations.benchmark.status, "invalid");
  assert.equal(result.durations.benchmark.duration_ms, null);
});

test("missing, incomplete, reversed and timezone-less collector windows remain unavailable", () => {
  assert.equal(build({ manifest: {} }).durations.capture.status, "missing");
  for (const command of [
    { started_at: "2026-01-01T00:00:00Z" },
    { started_at: "2026-01-01T00:00:01Z", ended_at: "2026-01-01T00:00:00Z" },
    { started_at: "2026-01-01T00:00:00", ended_at: "2026-01-01T00:00:01" },
    { started_at: "2026-02-30T00:00:00Z", ended_at: "2026-03-03T00:00:00Z" },
  ]) {
    const result = build({ manifest: { ...manifest(), command } });
    assert.equal(result.durations.command.status, "invalid");
    assert.equal(result.durations.command.duration_ms, null);
  }
});

test("raw outcome and valid-latency counts remain separate", () => {
  const report = raw(); report.raw = [{ create_ms: 0 }, { create_ms: 10, error: "failed" }, { create_ms: null }, null];
  const result = build({ raw: report });
  assert.deepEqual(result.requests, { observed: 4, successful: 2, errors: 1, valid_latency: 1 });
  assert.match(result.warnings.join(" "), /malformed rows/);
  assert.match(result.warnings.join(" "), /differs from raw/);
  assert.equal(result.create_latency_ms.avg, 150); // Already-computed profile is preserved, not recalculated here.
});

test("empty observed raw sample list is zero, not missing", () => {
  assert.deepEqual(build({ raw: [] }).requests, { observed: 0, successful: 0, errors: 0, valid_latency: 0 });
});

test("conflicting workload fields are unknown with a warning", () => {
  const report = raw(); report.config.warmup = 5;
  const result = build({ raw: report });
  assert.equal(result.workload.warmup, null);
  assert.match(result.warnings.join(" "), /Conflicting workload warmup/);
});

test("invalid workload and generic timer objects warn without crashing", () => {
  const result = build({ manifest: { warmup: -1 }, raw: null, summary: { benchmark_timing: [] } });
  assert.equal(result.workload.warmup, null);
  assert.equal(result.durations.benchmark.status, "invalid");
  assert.match(result.warnings.join(" "), /Invalid workload/);
  assert.equal(buildRunSummary().create_latency_ms, null);
});
