import importlib.util
import errno
import io
import json
import os
from pathlib import Path
import subprocess
import tempfile
import unittest
from unittest.mock import patch

spec = importlib.util.spec_from_file_location("cube_bench_runner", Path(__file__).with_name("cube_bench_runner.py"))
runner = importlib.util.module_from_spec(spec)
spec.loader.exec_module(runner)


def sample():
    return {"config": {"concurrency": 100, "total": 100, "warmup": 3, "mode": "create-only", "template": "synthetic-template"},
            "summary": {"total_time_s": 1},
            "warmup_raw": [{"seq": 0, "sandbox_id": f"synthetic-warmup-{n}", "create_ms": 10} for n in range(3)],
            "raw": [{"seq": n, "sandbox_id": f"synthetic-{n}", "create_ms": 10} for n in range(1, 101)]}


class BuildTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / "source/examples/cube-bench"
        self.source.mkdir(parents=True)
        (self.source / "runner.go").write_text("package main\ntype IterResult struct {\n" + runner.PATCHES[0][1] + "\n}\nfunc example() {\n" + runner.PATCHES[1][1] + "\n}\n")
        (self.source / "main.go").write_text("package main\n" + "".join(old for name, old, new in runner.PATCHES if name == "main.go"))
        with (self.source / "runner.go").open("a") as stream:
            stream.write(runner.PATCHES[4][1])
        (self.source / "go.mod").write_text("module synthetic\n")
        (self.source / "go.sum").write_text("")
        self.destination = self.root / "build"

    def build(self, args, **kwargs):
        self.assertEqual(args, ["go", "build", "-buildvcs=false", "-o", "cube-bench", "."])
        self.assertEqual(kwargs["cwd"], self.destination)
        (self.destination / "cube-bench").write_bytes(b"synthetic binary only")
        return subprocess.CompletedProcess(args, 0)

    def test_isolated_minimal_patch_and_provenance(self):
        before = {p.name: p.read_bytes() for p in self.source.iterdir()}
        with patch.object(runner.subprocess, "run", side_effect=self.build):
            binary = runner.prepare_benchmark(self.source.parent.parent, self.destination)
        self.assertEqual(binary, self.destination / "cube-bench")
        self.assertEqual(before, {p.name: p.read_bytes() for p in self.source.iterdir()})
        for name, old, new in runner.PATCHES:
            self.assertIn(new, (self.destination / name).read_text())
        info = json.loads((self.destination / "build-info.json").read_text())
        self.assertEqual(info["build_status"], "succeeded")
        self.assertEqual(info["binary_sha256"], runner.digest(binary))
        self.assertNotIn(str(self.root), json.dumps(info))

    def test_anchor_mismatch_refuses_before_build(self):
        (self.source / "main.go").write_text("unsupported source")
        with patch.object(runner.subprocess, "run") as run, self.assertRaises(ValueError):
            runner.prepare_benchmark(self.source, self.destination)
        run.assert_not_called()
        self.assertFalse(self.destination.exists())

    def test_existing_destination_refused(self):
        self.destination.mkdir()
        with self.assertRaises(ValueError):
            runner.prepare_benchmark(self.source, self.destination)

    def test_build_failure_retains_provenance(self):
        with patch.object(runner.subprocess, "run", side_effect=subprocess.CalledProcessError(1, ["go"])), self.assertRaises(subprocess.CalledProcessError):
            runner.prepare_benchmark(self.source, self.destination)
        self.assertEqual(json.loads((self.destination / "build-info.json").read_text())["build_status"], "failed")

    def test_symlink_source_file_rejected(self):
        (self.source / "main.go").unlink()
        (self.root / "external.go").write_text(runner.PATCHES[2][1])
        (self.source / "main.go").symlink_to(self.root / "external.go")
        with self.assertRaises(ValueError):
            runner.prepare_benchmark(self.source, self.destination)


class ResultTests(unittest.TestCase):
    def test_valid_complete_formal_results(self):
        owned, report = runner.validate_results(sample(), "synthetic-template")
        self.assertEqual(len(owned["formal"]), 100)
        self.assertEqual(len(owned["warmup"]), 3)
        self.assertEqual(report["status"], "valid")

    def test_zero_warmup_accepts_absent_or_empty_observation(self):
        for present in (False, True):
            raw = sample()
            raw["config"]["warmup"] = 0
            if present:
                raw["warmup_raw"] = []
            else:
                del raw["warmup_raw"]
            owned, report = runner.validate_results(raw, "synthetic-template", expected_warmup=0)
            self.assertEqual(report["status"], "valid")
            self.assertEqual(report["warnings"], [])
            self.assertTrue(report["capabilities"]["phase_attribution"])
            self.assertTrue(report["capabilities"]["client_sample_mapping"])
            self.assertEqual(owned["warmup"], [])

    def test_zero_warmup_rejects_nonempty_or_invalid_observation(self):
        for value in ([{"seq": 0, "sandbox_id": "unexpected", "create_ms": 10}], None, {}):
            raw = sample()
            raw["config"]["warmup"] = 0
            raw["warmup_raw"] = value
            self.assertEqual(runner.validate_results(raw, "synthetic-template", expected_warmup=0)[1]["status"], "invalid")

    def test_missing_failed_duplicate_samples_preserved_as_problems(self):
        raw = sample()
        raw["raw"][0].pop("sandbox_id")
        raw["raw"][1]["error"] = "synthetic create failure"
        raw["raw"][3]["sandbox_id"] = raw["raw"][2]["sandbox_id"]
        owned, report = runner.validate_results(raw, "synthetic-template")
        self.assertEqual(report["status"], "invalid")
        self.assertEqual(owned["unknown_phase"], ["synthetic-2", "synthetic-3"])
        self.assertNotIn("synthetic-1", owned["formal"])
        self.assertEqual(len(report["rows"]), 103)

    def test_config_mismatch_never_promoted_to_formal(self):
        raw = sample()
        raw["config"]["warmup"] = 0
        owned, report = runner.validate_results(raw, "synthetic-template")
        self.assertFalse(owned["formal"])
        self.assertEqual(len(owned["unknown_phase"]), 103)
        self.assertIn("raw_config_mismatch", report["problems"])

    def test_duplicate_seq_rejected(self):
        raw = sample()
        raw["raw"][1]["seq"] = 1
        owned, report = runner.validate_results(raw, "synthetic-template")
        self.assertEqual(owned["unknown_phase"], ["synthetic-1", "synthetic-2"])
        self.assertIn("formal_sequence_incomplete", report["problems"])

    def test_cross_phase_duplicate_never_owned_as_formal_or_warmup(self):
        raw = sample()
        raw["warmup_raw"][0]["sandbox_id"] = "synthetic-1"
        owned, report = runner.validate_results(raw, "synthetic-template")
        self.assertEqual(owned["unknown_phase"], ["synthetic-1"])
        self.assertNotIn("synthetic-1", owned["formal"])
        self.assertNotIn("synthetic-1", owned["warmup"])
        self.assertEqual(report["status"], "invalid")

    def test_failed_and_missing_warmup_ids_retained_as_problems(self):
        raw = sample()
        raw["warmup_raw"][0]["error"] = "synthetic failure"
        raw["warmup_raw"][1].pop("sandbox_id")
        owned, report = runner.validate_results(raw, "synthetic-template")
        self.assertEqual(len(owned["formal"]), 100)
        self.assertEqual(owned["warmup"], ["synthetic-warmup-2"])
        self.assertEqual(owned["unknown_phase"], ["synthetic-warmup-0"])
        self.assertEqual(report["status"], "invalid")

    def test_warmup_missing_is_explicitly_limited(self):
        raw = sample()
        del raw["warmup_raw"]
        owned, report = runner.validate_results(raw, "synthetic-template")
        self.assertEqual(report["status"], "limited")
        self.assertEqual(owned["warmup"], [])
        self.assertTrue(report["warnings"])
        self.assertFalse(report["capabilities"]["warmup_results"])

    def test_stock_binary_retains_client_results_without_guessing_ownership(self):
        raw = sample()
        del raw["warmup_raw"]
        for row in raw["raw"]:
            del row["sandbox_id"]
        before = json.dumps(raw)
        owned, report = runner.validate_results(raw, "synthetic-template")
        self.assertEqual(json.dumps(raw), before)
        self.assertEqual(owned, {"formal": [], "warmup": [], "unknown_phase": []})
        self.assertEqual(report["status"], "limited")
        self.assertEqual(report["problems"], [])
        self.assertTrue(report["capabilities"]["formal_results"])
        self.assertFalse(report["capabilities"]["phase_attribution"])
        self.assertEqual(raw["summary"]["total_time_s"], 1)
        self.assertEqual(len(report["warnings"]), 2)

    def test_partial_ids_retain_only_explicit_reliable_ownership(self):
        raw = sample()
        del raw["raw"][0]["sandbox_id"]
        owned, report = runner.validate_results(raw, "synthetic-template")
        self.assertEqual(report["status"], "limited")
        self.assertEqual(len(owned["formal"]), 99)
        self.assertEqual(owned["unknown_phase"], [])
        self.assertTrue(report["capabilities"]["formal_results"])
        self.assertFalse(report["capabilities"]["formal_instance_ids"])

    def test_explicit_invalid_ids_are_errors_not_optional_absences(self):
        for phase in ("raw", "warmup_raw"):
            for bad_id in (None, "", "bad id", 42, [], {}):
                with self.subTest(phase=phase, bad_id=bad_id):
                    raw = sample()
                    raw[phase][0]["sandbox_id"] = bad_id
                    owned, report = runner.validate_results(raw, "synthetic-template")
                    self.assertEqual(report["status"], "invalid")
                    self.assertIn("raw_sample_validation_failed", report["problems"])

    def test_explicit_invalid_warmup_is_not_downgraded_to_limited(self):
        for value in (None, {}, [], [None], [None] * 3):
            with self.subTest(value=value):
                raw = sample()
                raw["warmup_raw"] = value
                owned, report = runner.validate_results(raw, "synthetic-template")
                self.assertEqual(report["status"], "invalid")

    def test_stock_binary_still_rejects_invalid_formal_results(self):
        for mutation in (lambda raw: raw["raw"].pop(),
                         lambda raw: raw["raw"][0].update(seq=2),
                         lambda raw: raw["raw"][0].update(error="synthetic failure"),
                         lambda raw: raw["config"].update(total=99)):
            raw = sample()
            del raw["warmup_raw"]
            for row in raw["raw"]:
                del row["sandbox_id"]
            mutation(raw)
            owned, report = runner.validate_results(raw, "synthetic-template")
            self.assertEqual(report["status"], "invalid")
            self.assertEqual(owned, {"formal": [], "warmup": [], "unknown_phase": []})

    def test_invalid_latency_rejected_in_both_phases(self):
        for phase in ("raw", "warmup_raw"):
            for latency in (None, True, -1, float("nan"), float("inf"), "10"):
                with self.subTest(phase=phase, latency=latency):
                    raw = sample()
                    raw[phase][0]["create_ms"] = latency
                    owned, report = runner.validate_results(raw, "synthetic-template")
                    self.assertEqual(report["status"], "invalid")

    def test_malformed_raw_rejected(self):
        for value in [None, [], {}, {"raw": [None]}, {"raw": [{"seq": [], "sandbox_id": {}}]}]:
            with self.subTest(value=value):
                owned, report = runner.validate_results(value, "synthetic-template")
                self.assertEqual(report["status"], "invalid")
                self.assertEqual(owned["formal"], [])


class RunnerTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.environment = {"CUBE_CAPTURE_DIR": str(self.root / "capture"), "CUBE_CAPTURE_TEMPLATE_ID": "synthetic-template",
                            "CUBE_CAPTURE_BENCHMARK_BINARY": str(self.root / "synthetic-binary"),
                            "CUBE_CAPTURE_OWNED_IDS": str(self.root / "ownership-input.json"),
                            "E2B_API_URL": "http://example.invalid", "E2B_API_KEY": "synthetic-key"}
        self.envpatch = patch.dict(os.environ, self.environment, clear=True)
        self.envpatch.start()
        self.addCleanup(self.envpatch.stop)

    def run_fake(self, args, **kwargs):
        self.assertEqual(args[1:11], ["-c", "100", "-n", "100", "-w", "3", "-m", "create-only", "-no-tui", "-t"])
        self.assertNotIn("synthetic-key", args)
        Path(args[-1]).write_text(json.dumps(sample()))
        return subprocess.CompletedProcess(args, 0)

    def test_fixed_command_writes_ownership_and_keeps_raw(self):
        with patch.object(runner.subprocess, "run", side_effect=self.run_fake):
            self.assertEqual(runner.main(), 0)
        owned = json.loads((self.root / "ownership-input.json").read_text())
        self.assertEqual(set(owned), {"formal", "warmup", "unknown_phase"})
        self.assertEqual(len(owned["formal"]), 100)
        self.assertTrue((self.root / "capture/startup-latency/benchmark.raw.json").is_file())

    def test_stock_binary_success_returns_zero_and_prints_limits(self):
        def stock(args, **kwargs):
            raw = sample()
            del raw["warmup_raw"]
            for row in raw["raw"]:
                del row["sandbox_id"]
            Path(args[-1]).write_text(json.dumps(raw))
            return subprocess.CompletedProcess(args, 0)
        stderr = io.StringIO()
        with patch.object(runner.subprocess, "run", side_effect=stock), patch.object(runner.sys, "stderr", stderr):
            self.assertEqual(runner.main(), 0)
        self.assertIn("limited observation", stderr.getvalue())
        owned = json.loads((self.root / "ownership-input.json").read_text())
        self.assertEqual(owned, {"formal": [], "warmup": [], "unknown_phase": []})
        validation = json.loads((self.root / "capture/startup-latency/runner-validation.json").read_text())
        self.assertEqual(validation["status"], "limited")

    def inventory_options(self):
        os.environ["CUBE_CAPTURE_CUBEMASTERCLI"] = json.dumps({
            "binary": "/synthetic/cubemastercli", "address": "127.0.0.1",
            "port": 8089, "exclusive_template": True})
        directory = self.root / "capture/evidence/cubemastercli"
        directory.mkdir(parents=True)
        summary = {"node_scope": "all", "nodes_scanned": 1, "nodes_total": 1, "sandbox_count": 0}
        before = {"status": "ok", "errors": [], "rows": [], "summary": summary}
        rows = [{"sandbox_id": r["sandbox_id"], "template_id": "synthetic-template", "status": "running"}
                for field in ("raw", "warmup_raw") for r in sample()[field]]
        after = {"status": "ok", "errors": [], "rows": rows,
                 "summary": {**summary, "sandbox_count": 103}}
        return before, after

    def run_stock(self, args, **kwargs):
        raw = sample()
        del raw["warmup_raw"]
        for row in raw["raw"]:
            del row["sandbox_id"]
        Path(args[-1]).write_text(json.dumps(raw))
        return subprocess.CompletedProcess(args, 0)

    def test_cli_stock_collects_mixed_ids_without_changing_workload_or_raw(self):
        before, after = self.inventory_options()
        with patch.object(runner.inventory, "snapshot", side_effect=[before, after]), \
                patch.object(runner.subprocess, "run", side_effect=self.run_stock) as bench:
            self.assertEqual(runner.main(), 0)
        self.assertEqual(bench.call_count, 1)
        self.assertEqual(bench.call_args.args[0][1:10], ["-c", "100", "-n", "100", "-w", "3", "-m", "create-only", "-no-tui"])
        owned = json.loads((self.root / "ownership-input.json").read_text())
        self.assertEqual(len(owned["unknown_phase"]), 103)
        self.assertEqual(owned["formal"], [])
        raw = json.loads((self.root / "capture/startup-latency/benchmark.raw.json").read_text())
        self.assertNotIn("warmup_raw", raw)
        self.assertNotIn("sandbox_id", raw["raw"][0])
        report = json.loads((self.root / "capture/startup-latency/runner-validation.json").read_text())
        self.assertEqual(report["status"], "limited")
        self.assertTrue(report["capabilities"]["server_instance_ids"])
        self.assertFalse(report["capabilities"]["phase_attribution"])
        self.assertFalse(any("_sandbox_ids_absent:" in x for x in report["warnings"]))

    def setup_formal_inventory(self):
        os.environ["CUBE_CAPTURE_WARMUP"] = "0"
        before, after = self.inventory_options()
        before["rows"] = after["rows"][100:]
        before["summary"] = {**before["summary"], "sandbox_count": 3}
        return before, after

    def run_stock_formal(self, args, **kwargs):
        self.assertEqual(args[1:10], ["-c", "100", "-n", "100", "-w", "0", "-m", "create-only", "-no-tui"])
        raw = sample()
        raw["config"]["warmup"] = 0
        del raw["warmup_raw"]
        for row in raw["raw"]:
            del row["sandbox_id"]
        Path(args[-1]).write_text(json.dumps(raw))
        return subprocess.CompletedProcess(args, 0)

    def test_cli_zero_warmup_uses_only_new_formal_set_with_retained_warmup(self):
        before, after = self.setup_formal_inventory()
        with patch.object(runner.inventory, "snapshot", side_effect=[before, after]), \
                patch.object(runner.subprocess, "run", side_effect=self.run_stock_formal):
            self.assertEqual(runner.main(), 0)
        owned = json.loads((self.root / "ownership-input.json").read_text())
        self.assertEqual(set(owned["formal"]), {f"synthetic-{n}" for n in range(1, 101)})
        self.assertEqual(owned["warmup"], [])
        self.assertEqual(owned["unknown_phase"], [])
        report = json.loads((self.root / "capture/startup-latency/runner-validation.json").read_text())
        self.assertTrue(report["capabilities"]["formal_instance_ids"])
        self.assertTrue(report["capabilities"]["phase_attribution"])
        self.assertFalse(report["capabilities"]["client_sample_mapping"])
        self.assertEqual(report["inventory"]["phase"], "formal")
        self.assertFalse(report["inventory"]["client_sample_mapping"])
        self.assertFalse(any("warmup_raw_absent" in warning for warning in report["warnings"]))
        self.assertTrue(any("client_sample_id_mapping_unavailable" in warning for warning in report["warnings"]))
        self.assertTrue(all(row["phase"] is None for row in report["rows"]))

    def test_cli_zero_warmup_invalid_raw_cannot_be_promoted(self):
        before, after = self.setup_formal_inventory()
        def failed_raw(args, **kwargs):
            result = self.run_stock_formal(args, **kwargs)
            raw = json.loads(Path(args[-1]).read_text())
            raw["raw"][0]["error"] = "synthetic failure"
            Path(args[-1]).write_text(json.dumps(raw))
            return result
        with patch.object(runner.inventory, "snapshot", side_effect=[before, after]), \
                patch.object(runner.subprocess, "run", side_effect=failed_raw):
            self.assertEqual(runner.main(), 2)
        self.assertFalse(any(json.loads((self.root / "ownership-input.json").read_text()).values()))
        report = json.loads((self.root / "capture/startup-latency/runner-validation.json").read_text())
        self.assertFalse(report["inventory"]["accepted"])
        self.assertIn("benchmark_validation_blocks_attribution", report["inventory"]["errors"])
        self.assertFalse(report["capabilities"]["phase_attribution"])

    def test_cli_zero_warmup_nonzero_exit_never_promotes_inventory(self):
        before, after = self.setup_formal_inventory()
        def failed(args, **kwargs):
            self.run_stock_formal(args, **kwargs)
            return subprocess.CompletedProcess(args, 7)
        with patch.object(runner.inventory, "snapshot", side_effect=[before, after]), \
                patch.object(runner.subprocess, "run", side_effect=failed):
            self.assertEqual(runner.main(), 7)
        self.assertFalse(any(json.loads((self.root / "ownership-input.json").read_text()).values()))

    def test_cli_zero_warmup_raw_id_conflict_retains_only_declared_ids(self):
        before, after = self.setup_formal_inventory()
        def conflicting(args, **kwargs):
            self.run_stock_formal(args, **kwargs)
            raw = json.loads(Path(args[-1]).read_text())
            raw["raw"][0]["sandbox_id"] = "not-in-inventory"
            Path(args[-1]).write_text(json.dumps(raw))
            return subprocess.CompletedProcess(args, 0)
        with patch.object(runner.inventory, "snapshot", side_effect=[before, after]), \
                patch.object(runner.subprocess, "run", side_effect=conflicting):
            self.assertEqual(runner.main(), 0)
        owned = json.loads((self.root / "ownership-input.json").read_text())
        self.assertEqual(owned, {"formal": ["not-in-inventory"], "warmup": [], "unknown_phase": []})
        report = json.loads((self.root / "capture/startup-latency/runner-validation.json").read_text())
        self.assertFalse(report["inventory"]["accepted"])
        self.assertFalse(report["capabilities"]["formal_instance_ids"])
        self.assertFalse(report["capabilities"]["phase_attribution"])
        self.assertIn("raw_id_conflict", report["inventory"]["errors"])

    def test_cli_zero_warmup_evidence_failure_rolls_back_formal_capabilities(self):
        before, after = self.setup_formal_inventory()
        write = runner.write_json
        def fail_inventory(path, value):
            if path.name == "ownership.json":
                raise OSError(errno.ENOSPC, "full")
            return write(path, value)
        with patch.object(runner.inventory, "snapshot", side_effect=[before, after]), \
                patch.object(runner.subprocess, "run", side_effect=self.run_stock_formal), \
                patch.object(runner, "write_json", side_effect=fail_inventory):
            self.assertEqual(runner.main(), 2)
        owned = json.loads((self.root / "ownership-input.json").read_text())
        self.assertFalse(any(owned.values()))
        report = json.loads((self.root / "capture/startup-latency/runner-validation.json").read_text())
        self.assertFalse(report["capabilities"]["formal_instance_ids"])
        self.assertFalse(report["capabilities"]["phase_attribution"])
        self.assertFalse(report["inventory"]["accepted"])

    def test_invalid_warmup_environment_never_launches(self):
        for value in ("-1", "false", "1.5", "", "000", "1000000"):
            with self.subTest(value=value), patch.dict(os.environ, {"CUBE_CAPTURE_WARMUP": value}), \
                    patch.object(runner.subprocess, "run") as bench:
                self.assertEqual(runner.main(), 2)
                bench.assert_not_called()

    def test_cli_before_failure_does_not_launch_benchmark(self):
        before, _ = self.inventory_options()
        before.update(status="error", errors=["inventory_process_timeout"])
        with patch.object(runner.inventory, "snapshot", return_value=before), \
                patch.object(runner.subprocess, "run") as bench:
            self.assertEqual(runner.main(), 2)
        bench.assert_not_called()
        report = json.loads((self.root / "capture/startup-latency/runner-validation.json").read_text())
        self.assertFalse(report["benchmark_attempted"])
        self.assertIsNone(report["benchmark_exit_code"])
        self.assertIn("cubemastercli_before_failed", report["problems"])

    def test_cli_after_failure_preserves_benchmark_exit_and_raw(self):
        before, after = self.inventory_options()
        after.update(status="error", errors=["inventory_process_timeout"])
        with patch.object(runner.inventory, "snapshot", side_effect=[before, after]), \
                patch.object(runner.subprocess, "run", side_effect=self.run_stock):
            self.assertEqual(runner.main(), 2)
        report = json.loads((self.root / "capture/startup-latency/runner-validation.json").read_text())
        self.assertEqual(report["benchmark_exit_code"], 0)
        self.assertIn("cubemastercli_after_failed", report["problems"])
        self.assertNotIn("benchmark_exit_nonzero", report["problems"])
        self.assertTrue((self.root / "capture/startup-latency/benchmark.raw.json").is_file())

    def test_cli_after_exception_retains_raw_and_actual_benchmark_exit(self):
        before, _ = self.inventory_options()
        with patch.object(runner.inventory, "snapshot", side_effect=[before, OSError(errno.EIO, "synthetic-key")]), \
                patch.object(runner.subprocess, "run", side_effect=self.run_stock):
            self.assertEqual(runner.main(), 2)
        report = json.loads((self.root / "capture/startup-latency/runner-validation.json").read_text())
        self.assertEqual(report["benchmark_exit_code"], 0)
        self.assertFalse(report["inventory"]["accepted"])
        self.assertIn("cubemastercli_after_exception", report["problems"])
        self.assertNotIn("synthetic-key", json.dumps(report))
        self.assertEqual(json.loads((self.root / "ownership-input.json").read_text())["unknown_phase"], [])

    def test_cli_evidence_write_failure_withdraws_success_claims(self):
        before, after = self.inventory_options()
        write = runner.write_json
        def fail_inventory(path, value):
            if path.name == "ownership.json":
                raise OSError(errno.ENOSPC, "full")
            return write(path, value)
        with patch.object(runner.inventory, "snapshot", side_effect=[before, after]), \
                patch.object(runner.subprocess, "run", side_effect=self.run_stock), \
                patch.object(runner, "write_json", side_effect=fail_inventory):
            self.assertEqual(runner.main(), 2)
        report = json.loads((self.root / "capture/startup-latency/runner-validation.json").read_text())
        self.assertFalse(report["inventory"]["accepted"])
        self.assertNotIn("cubemastercli_instance_ids_collected", json.dumps(report))
        self.assertEqual(report["ownership_basis"], "declared_from_benchmark_raw_ids_not_independently_verified")
        self.assertEqual(json.loads((self.root / "ownership-input.json").read_text())["unknown_phase"], [])

    def test_cli_conflict_does_not_claim_accepted_inventory(self):
        before, after = self.inventory_options()
        after["rows"][0]["sandbox_id"] = "conflicting-id"
        with patch.object(runner.inventory, "snapshot", side_effect=[before, after]), \
                patch.object(runner.subprocess, "run", side_effect=self.run_fake):
            self.assertEqual(runner.main(), 0)
        report = json.loads((self.root / "capture/startup-latency/runner-validation.json").read_text())
        self.assertFalse(report["inventory"]["accepted"])
        self.assertIn("raw_id_conflict", report["inventory"]["errors"])
        evidence = json.loads((self.root / "capture/evidence/cubemastercli/ownership.json").read_text())
        self.assertFalse(evidence["accepted"])

    def test_cli_does_not_promote_candidates_after_failed_benchmark(self):
        before, after = self.inventory_options()
        def failed(args, **kwargs):
            self.run_stock(args, **kwargs)
            return subprocess.CompletedProcess(args, 7)
        with patch.object(runner.inventory, "snapshot", side_effect=[before, after]), \
                patch.object(runner.subprocess, "run", side_effect=failed):
            self.assertEqual(runner.main(), 7)
        owned = json.loads((self.root / "ownership-input.json").read_text())
        self.assertEqual(owned["unknown_phase"], [])

    def test_cli_keeps_explicit_benchmark_phase_ids(self):
        before, after = self.inventory_options()
        with patch.object(runner.inventory, "snapshot", side_effect=[before, after]), \
                patch.object(runner.subprocess, "run", side_effect=self.run_fake):
            self.assertEqual(runner.main(), 0)
        owned = json.loads((self.root / "ownership-input.json").read_text())
        self.assertEqual(len(owned["formal"]), 100)
        self.assertEqual(len(owned["warmup"]), 3)
        self.assertEqual(owned["unknown_phase"], [])

    def test_invalid_explicit_observation_returns_nonzero(self):
        def malformed(args, **kwargs):
            raw = sample()
            raw["warmup_raw"] = None
            Path(args[-1]).write_text(json.dumps(raw))
            return subprocess.CompletedProcess(args, 0)
        with patch.object(runner.subprocess, "run", side_effect=malformed):
            self.assertEqual(runner.main(), 2)

    def test_nonzero_benchmark_exit_preserved_and_ids_saved(self):
        def failure(args, **kwargs):
            self.run_fake(args, **kwargs)
            return subprocess.CompletedProcess(args, 7)
        stderr = io.StringIO()
        with patch.object(runner.subprocess, "run", side_effect=failure), patch.object(runner.sys, "stderr", stderr):
            self.assertEqual(runner.main(), 7)
        self.assertEqual(len(json.loads((self.root / "ownership-input.json").read_text())["formal"]), 100)
        self.assertIn("exit_code=7", stderr.getvalue())
        self.assertIn("benchmark_exit_nonzero", stderr.getvalue())

    def test_zero_exit_missing_raw_is_failure(self):
        stderr = io.StringIO()
        with patch.object(runner.subprocess, "run", return_value=subprocess.CompletedProcess([], 0)), patch.object(runner.sys, "stderr", stderr):
            self.assertEqual(runner.main(), 2)
        self.assertEqual(json.loads((self.root / "ownership-input.json").read_text())["formal"], [])
        self.assertIn("benchmark_raw_missing", stderr.getvalue())

    def test_launch_oserror_retains_errno_and_actionable_diagnostics(self):
        for number, expected_code, hint in ((errno.ENOEXEC, 126, "architecture"),
                                            (errno.ENOENT, 127, "dynamic loader"),
                                            (errno.EACCES, 126, "permissions")):
            with self.subTest(errno=number), tempfile.TemporaryDirectory() as directory:
                os.environ["CUBE_CAPTURE_DIR"] = directory
                os.environ["CUBE_CAPTURE_OWNED_IDS"] = str(Path(directory) / "owned.json")
                stderr = io.StringIO()
                error = OSError(number, "unsafe exception text: synthetic-key")
                with patch.object(runner.subprocess, "run", side_effect=error), patch.object(runner.sys, "stderr", stderr):
                    self.assertEqual(runner.main(), expected_code)
                report = json.loads((Path(directory) / "startup-latency/runner-validation.json").read_text())
                self.assertEqual(report["launch_error"], {"type": type(error).__name__, "errno": number, "message": os.strerror(number)})
                self.assertIn("benchmark_execution_failed", report["problems"])
                self.assertIn("benchmark_raw_missing", report["problems"])
                self.assertIn(hint, stderr.getvalue())
                self.assertIn(self.environment["CUBE_CAPTURE_BENCHMARK_BINARY"], stderr.getvalue())
                self.assertIn(f"errno={number}", stderr.getvalue())
                self.assertNotIn("synthetic-key", stderr.getvalue() + json.dumps(report))

    def test_invalid_samples_print_counts_and_at_most_three_redacted_examples(self):
        def errors(args, **kwargs):
            raw = sample()
            for row in raw["raw"][:5]:
                row["error"] = "HTTP 401 response: synthetic-key"
            raw["raw"][0]["seq"] = 2
            Path(args[-1]).write_text(json.dumps(raw))
            return subprocess.CompletedProcess(args, 0)
        stderr = io.StringIO()
        with patch.object(runner.subprocess, "run", side_effect=errors), patch.object(runner.sys, "stderr", stderr):
            self.assertEqual(runner.main(), 2)
        text = stderr.getvalue()
        self.assertIn("benchmark_sample_failed=5", text)
        self.assertIn("duplicate_seq=2", text)
        self.assertIn("formal_sequence_incomplete", text)
        self.assertEqual(text.count("HTTP 401 response: [REDACTED]"), 3)
        self.assertNotIn("synthetic-key", text)
        self.assertIn("runner-validation.json", text)

    def test_invalid_json_prints_problem(self):
        def invalid(args, **kwargs):
            Path(args[-1]).write_text("{invalid")
            return subprocess.CompletedProcess(args, 0)
        stderr = io.StringIO()
        with patch.object(runner.subprocess, "run", side_effect=invalid), patch.object(runner.sys, "stderr", stderr):
            self.assertEqual(runner.main(), 2)
        self.assertIn("benchmark_raw_unreadable_or_invalid_json", stderr.getvalue())

    def test_keyboard_interrupt_saves_missing_evidence(self):
        with patch.object(runner.subprocess, "run", side_effect=KeyboardInterrupt):
            self.assertEqual(runner.main(), 130)
        self.assertTrue((self.root / "capture/startup-latency/runner-validation.json").is_file())

    def test_missing_env_does_not_launch(self):
        del os.environ["E2B_API_KEY"]
        with patch.object(runner.subprocess, "run") as run:
            self.assertEqual(runner.main(), 2)
        run.assert_not_called()

    def test_existing_raw_is_never_reused(self):
        output = self.root / "capture/startup-latency/benchmark.raw.json"
        output.parent.mkdir(parents=True)
        output.write_text(json.dumps(sample()))
        with patch.object(runner.subprocess, "run") as run:
            self.assertEqual(runner.main(), 2)
        run.assert_not_called()


if __name__ == "__main__":
    unittest.main()
