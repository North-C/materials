import test from 'node:test';
import assert from 'node:assert/strict';
import {renderReport} from './render_report.mjs';

test('report preserves distinct windows and escapes input-derived labels', () => {
  const run={workload:{concurrency:2,requests:2,warmup:0},durations:{
    benchmark:{status:'available',duration_ms:50,source:['raw.summary.total_time_s'],scope:'formal'},
    command:{status:'available',duration_ms:2000,source:[],scope:'command'},
    capture:{status:'available',duration_ms:10000,source:[],scope:'capture'}},create_latency_ms:{count:2,avg:35,p50:30,p95:40,max:40},
    requests:{observed:2,successful:2,errors:0,valid_latency:2},warnings:['<script>alert(1)</script>']};
  const output=renderReport(run,{phases:{},phase_attribution_status:'unverified'});
  assert.match(output.markdown,/正式测试整轮耗时 \| 50 ms/);
  assert.match(output.markdown,/外部命令窗口 \| 2000 ms/);
  assert.match(output.html,/&lt;script&gt;/);
  assert.doesNotMatch(output.html,/<script>/);
  assert.match(output.html,/benchmark-inputs\//);
});

const observedStage = {stats: {count: 2, avg: 12, p50: 10, p95: 14, max: 14},
  coverage: {observed_instances: 2, owned_instances: 3}};

test('unknown-phase observations are displayed with coverage, never promoted to formal', () => {
  const output = renderReport({inventory: {accepted: true, phase: 'unknown_phase', candidate_ids: ['a', 'b', 'c']}}, {
    phase_attribution_status: 'unverified', phases: {
      formal: {owned_instance_count: 0, cubelet_stages: {}},
      unknown_phase: {owned_instance_count: 3, cubelet_stages: {network: observedStage}},
    },
  });
  assert.match(output.markdown, /unknown_phase \| Cubelet.network \| 2\/3 \| 2 \| 12 \| 10 \| 14 \| 14/);
  assert.match(output.html, /<td>unknown_phase<\/td><td>Cubelet.network<\/td><td>2\/3<\/td>/);
  assert.match(output.html, /共展示 1 个/);
  assert.match(output.html, /可能混有预热/);
  assert.doesNotMatch(output.html, /<td>formal<\/td><td>Cubelet.network/);
});

test('separate prewarmup has independent timing and does not change formal results', () => {
  const run = {workload: {concurrency: 100, requests: 100, warmup: 0},
    durations: {benchmark: {status: 'available', duration_ms: 50}},
    requests: {observed: 100, successful: 100},
    prewarmup: {mode: 'separate_process', count: 3, successful: 3, status: 'complete', benchmark_exit_code: 0, duration_ms: 200},
    inventory: {accepted: true, phase: 'formal', candidate_ids: ['formal-1']}};
  const output = renderReport(run, {phases: {formal: {owned_instance_count: 1, shim_stages: {RestoreVm: observedStage}}}});
  assert.match(output.markdown, /正式测试整轮耗时 \| 50 ms/);
  assert.match(output.markdown, /独立预热命令耗时 \| 200 ms/);
  assert.match(output.html, /正式进程内置预热 0/);
  assert.match(output.html, /独立预热计划 3 次，成功 3 次，状态 complete/);
  assert.match(output.html, /不复用预热进程的 HTTP 连接/);
  assert.match(output.html, /metrics 是全局指标/);
  assert.match(output.html, /差集推定 formal 集合/);
  assert.doesNotMatch(output.html, /仅有清单证据的实例归入 unknown_phase/);
  assert.equal(run.durations.benchmark.duration_ms, 50);
  assert.equal(run.requests.observed, 100);
});

test('empty report distinguishes missing ownership from missing stage evidence and links diagnostics', () => {
  const missingIds = renderReport({}, {phases: {unknown_phase: {owned_instance_count: 0}}});
  assert.match(missingIds.html, /缺少可靠的实例 ID 归属/);
  assert.match(missingIds.html, /href="analysis.json"/);
  assert.match(missingIds.markdown, /\[runner 原始结果与校验记录\]\(benchmark-inputs\/\)/);
  const missingLogs = renderReport({}, {phases: {formal: {owned_instance_count: 100,
    cubelet_stages: {network: {stats: null, coverage: {observed_instances: 0, owned_instances: 100}}}}}});
  assert.match(missingLogs.html, /已有实例 ID，但日志中没有匹配到有效阶段数值/);
  assert.match(missingLogs.html, /未记录的阶段不能按 0 ms 计算/);
  assert.doesNotMatch(missingLogs.html, /Cubelet.network/);
});

test('skipped prewarmup is explicit and unavailable duration is never invented', () => {
  const output = renderReport({prewarmup: {mode: 'separate_process', count: 0, successful: 0, status: 'skipped'}}, {});
  assert.match(output.html, /独立预热计划 0 次，成功 0 次，状态 skipped/);
  assert.match(output.markdown, /独立预热命令耗时 \| 未提供/);
});

test('ownership rejection displays candidate mismatch and escapes unknown error codes', () => {
  const run = {inventory: {accepted: false, expected_count: 100, candidate_ids: ['a'],
    errors: ['inventory_candidate_count_mismatch', '<script>invalid</script>']}};
  const output = renderReport(run, {phases: {formal: {owned_instance_count: 0}}});
  assert.match(output.html, /CLI 候选 1 个；预期 100 个；归属未采用/);
  assert.match(output.html, /inventory_candidate_count_mismatch/);
  assert.match(output.html, /不要手工凑够 100 个 ID/);
  assert.match(output.html, /&lt;script&gt;invalid/);
  assert.doesNotMatch(output.html, /<script>/);
});

test('raw IDs absent without inventory explains how to enable CLI evidence', () => {
  const output = renderReport({warnings: ['formal_sandbox_ids_absent: 100 samples']}, {phases: {}});
  assert.match(output.html, /sandbox_ids_absent_without_inventory/);
  assert.match(output.html, /本轮 CubeAPI 使用的 CubeMaster/);
  const known = renderReport({warnings: ['formal_sandbox_ids_absent: 100 samples']}, {
    phases: {unknown_phase: {owned_instance_count: 1, shim_stages: {RestoreVm: observedStage}}}});
  assert.doesNotMatch(known.html, /sandbox_ids_absent_without_inventory/);
});
